# mini-k3: compact-model comparison completed

On 18 October 2026, six development runs selected `attnres5_b12` and nine locked
confirmation runs compared it with ordinary five- and six-layer MiniMind.
All models trained from scratch on a free Tesla T4, with matching token budgets,
FP32 residual states, FP16 linear operations, fused AdamW and the same compiler.

| Three-seed confirmation mean | Baseline6 | Compact AttnRes |
| --- | ---: | ---: |
| Parameters | 13,227,648 | 11,441,152 |
| New-story heldout perplexity | 9.794 | 9.409 |
| Training tokens/second | 119,735 | 134,756 |
| Time to fixed development quality, seconds | 29.11 | 23.56 |

Mean paired changes: **3.93% lower heldout perplexity**, **12.56% higher
training throughput**, and **18.61% less wall time to development NLL <= 2.10**.
The compact model has **13.51% fewer parameters**. The quality/throughput
criterion passed in every confirmation seed (17, 123, 777). Five alternating-order
timing repetitions also favored the winner. The same-depth five-layer ordinary
baseline is faster but has worse heldout quality, so adding AttnRes still has a
cost. Compactness and the depth-mixing technique work together in this result.

This achieves the internally defined faster-and-stronger goal **within this
small-model TinyStories comparison**. It is not a full 64M MiniMind study or a
general-assistant result. The custom WikiText test-prefix check improved in two
seeds and regressed in one; all models have very high perplexity on that domain.
Do not claim consistent superiority across domains or cached decoding speed.

## Read and reproduce

- Report: `output/pdf/Mini_K3_Phase3_Technical_Report_Fazal_Hameed.pdf`.
- Markdown report: `phase3/analysis/PHASE3_REPORT.md`.
- Clean self-contained Colab notebook: `phase3/mini_k3_phase3.ipynb`.
- Exact source, rules and selection: `phase3/models.py`, `runner.py`,
  `PROTOCOL.md`, `OOD_PROTOCOL.md`, `TIMING_PROTOCOL.md`, and `selection.json`.
- Measured evidence: `phase3/analysis/`, `phase3/runs/`,
  `phase3/repeated_timing.json` and `phase3/persistent_model_verification.json`.
- Live notebook: https://colab.research.google.com/drive/1NJODT4RLK_TMQTCbn_lbdLOye45TkFLz
- Drive: https://drive.google.com/drive/u/0/folders/1SGN7N1bAIFEN7EKVthnhx3bmepkPWkqC

## Verified preservation

The 15 new completed model files are backed up under
`My Drive/mini-k3/2026-10-18/phase3/runs/`. After Colab disconnected, all 15 files
were read back from Drive and verified against their SHA-256 certificates.
See `phase3/persistent_model_verification.json`. These exports contain weights,
configuration and results; they omit AdamW/scaler state. The original runtime
expired after training, so its temporary optimizer checkpoints are gone. The
completed model exports can reproduce evaluation, but cannot resume that exact
optimizer trajectory. Full source, sampled-batch recipe, data pins and scores
support training reproduction in a fresh run.

The previous 12 checkpoint backups and earlier reports are retained in Drive.
Local ZIP bundles contain code, logs, reports, charts and certificates; model
and cached-token bytes are not included. The original 200-step pilot had a
residual-precision confound. Phase two controlled precision and measured a
speed cost; phase three retains the control and explicitly changes model depth,
block size and implementation. Compare results within each phase because the
heldout partitions differ.

