"""Build a self-contained Colab notebook from the reviewed local source files."""
import ast
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
UPSTREAM = json.loads((ROOT / 'vendor/upstream.json').read_text())['commit']
remote_files = ['model/model_minimind.py', 'model/tokenizer.json',
                'model/tokenizer_config.json', 'LICENSE']
expected = {name: hashlib.sha256((ROOT / 'vendor' / name).read_bytes()).hexdigest()
            for name in remote_files}
local_files = {name: (ROOT / name).read_text(encoding='utf-8')
               for name in ['attnres.py', 'experiment.py', 'test_experiment.py', 'analyze.py', 'README.md']}
for name, source in local_files.items():
    if name.endswith('.py'):
        ast.parse(source, filename=name)
setup = f'''# Install only the packages this pilot needs; keep Colab's CUDA PyTorch.
import sys, subprocess, os, urllib.request, hashlib
from pathlib import Path
WORK = Path('/content/mini_k3_work')
WORK.mkdir(parents=True, exist_ok=True)
subprocess.check_call([sys.executable, '-m', 'pip', 'install', '-q',
                       'transformers==4.57.6', 'datasets==3.6.0'])
UPSTREAM = {UPSTREAM!r}
EXPECTED = {expected!r}
for name, sha in EXPECTED.items():
    target = WORK / 'vendor' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    data = urllib.request.urlopen(
        f'https://raw.githubusercontent.com/jingyaogong/minimind/{{UPSTREAM}}/{{name}}').read()
    assert hashlib.sha256(data).hexdigest() == sha, 'Upstream file integrity mismatch'
    target.write_bytes(data)
FILES = {local_files!r}
for name, content in FILES.items():
    (WORK / name).write_text(content, encoding='utf-8')
os.environ['PYTHONPATH'] = str(WORK / 'vendor') + os.pathsep + str(WORK)
os.environ['TOKENIZERS_PARALLELISM'] = 'false'
os.environ['HF_HUB_DISABLE_XET'] = '1'
os.environ['USE_TF'] = '0'
os.environ['USE_FLAX'] = '0'
print('Setup complete. Pinned MiniMind:', UPSTREAM)
print('Work directory:', WORK)
'''
hardware = '''import sys, torch
print('Python:', sys.version)
print('PyTorch:', torch.__version__)
print('CUDA available:', torch.cuda.is_available())
assert torch.cuda.is_available(), 'Select Runtime > Change runtime type > T4 GPU'
p = torch.cuda.get_device_properties(0)
print('GPU:', p.name, '| memory GiB:', round(p.total_memory / 2**30, 2))
'''
tests = '''# Random-input correctness checks, not model quality results.
def run(command):
    with subprocess.Popen(command, cwd=WORK, stdout=subprocess.PIPE,
                          stderr=subprocess.STDOUT, text=True, bufsize=1) as process:
        for line in process.stdout:
            print(line, end='', flush=True)
        status = process.wait()
    if status:
        raise RuntimeError(f'Experiment command failed with status {status}')

run([sys.executable, str(WORK / 'test_experiment.py')])
'''
data = '''# Streams a small pinned subset; no Hugging Face login/token is required.
run([sys.executable, str(WORK / 'experiment.py'), 'prepare',
    '--upstream', str(WORK / 'vendor'), '--data', str(WORK / 'data')])
'''
train = '''# First paired pilot: 819,200 predicted training tokens per variant.
# Rerun this unchanged to resume. New settings require a new RUN_NAME.
RUN_NAME = 'pilot001'
run([sys.executable, str(WORK / 'experiment.py'), 'train',
    '--data', str(WORK / 'data'), '--output', str(WORK / 'runs' / RUN_NAME),
    '--size', 'pilot', '--seq', '128', '--batch', '8', '--accum', '4',
    '--steps', '200', '--seeds', '42'])
'''
summary = '''import json, pandas as pd
result_path = WORK / 'runs' / RUN_NAME / 'results.json'
assert result_path.exists(), 'Training has not completed both variants yet.'
results = json.loads(result_path.read_text())
display(pd.DataFrame(results)[['variant', 'seed', 'parameters', 'training_tokens',
    'validation_nll', 'validation_perplexity', 'median_step_tokens_per_second',
    'peak_allocated_gpu_bytes_this_session']])
print('One short run is preliminary. Report actual gains or regressions, then repeat seeds.')
'''
download = '''# Download after every session. /content disappears when the runtime expires.
# No Google Drive mount is needed. Keep the archive on your laptop.
import shutil
from google.colab import files
archive = shutil.make_archive('/content/mini_k3_session', 'zip', WORK)
files.download(archive)
'''
replications = '''# Two new seeds, with reversed model execution order.
run([sys.executable, str(WORK / 'experiment.py'), 'train',
    '--data', str(WORK / 'data'), '--output', str(WORK / 'runs' / 'replications001'),
    '--size', 'pilot', '--seq', '128', '--batch', '8', '--accum', '4',
    '--steps', '200', '--seeds', '17', '123', '--variants', 'attnres', 'baseline'])
'''
analysis = '''run([sys.executable, str(WORK / 'analyze.py')])
bundle = json.loads((WORK / 'analysis' / 'pilot_results.json').read_text())
rows = []
for variant, values in bundle['summary'].items():
    rows.append({'Variant': variant,
        'Mean NLL': round(values['validation_nll']['mean'], 4),
        'Mean perplexity': round(values['validation_perplexity']['mean'], 2),
        'Mean training tokens/s': round(values['median_step_tokens_per_second']['mean'])})
display(pd.DataFrame(rows))
from IPython.display import Image, display
display(Image(filename=str(WORK / 'analysis' / 'learning_curves.png')))
'''
cells = []
def md(text):
    cells.append({'cell_type': 'markdown', 'metadata': {}, 'source': text.splitlines(True)})
def code(text):
    ast.parse(text)
    cells.append({'cell_type': 'code', 'metadata': {}, 'execution_count': None,
                  'outputs': [], 'source': text.splitlines(True)})
md('''# mini-k3: first pilot on free Colab

Start with **Runtime → Change runtime type → T4 GPU**, then run cells in order.
This compares a reduced dense MiniMind baseline with a Kimi K3 Block Attention
Residuals adaptation. No improvement is assumed. This pilot is not a full K3
reproduction or sufficient evidence of general LLM capability.

Sources: [MiniMind](https://github.com/jingyaogong/minimind),
[Kimi K3 §2.2](https://arxiv.org/html/2607.24653v2#S2.SS2),
[TinyStories](https://huggingface.co/datasets/roneneldan/TinyStories).
''')
md('## 1. Confirm the free GPU')
code(hardware)
md('## 2. Install dependencies and materialize the experiment\nPinned source files are checked with SHA-256.')
code(setup)
md('## 3. Run correctness checks\nThese use random tokens; they are separate from the research results.')
code(tests)
md('## 4. Prepare a small dataset\nSeparate official splits; exact-text duplicates removed across selected data. '
   'Two million training tokens and 100,000 validation tokens are cached.')
code(data)
md('## 5. Train the matched pair\nSame data, initialization of shared weights, optimizer, precision and token budget. '
   'Checkpoints every 25 steps. A short single-seed pilot may show no improvement. '
   'Leave this page open during the free session.')
code(train)
md('## 6. Inspect the actual results\nThroughput measures training steps, not cached generation. '
   'Memory is the peak observed in this session. Both limitations matter.')
code(summary)
md('## 7. Repeat two more seeds\nReverse variant order to help assess timing variation.')
code(replications)
md('## 8. Analyze all six completed runs\nThe report labels this a preliminary domain-specific pilot.')
code(analysis)
md('## 9. Save your session to the laptop\nDownload before the runtime expires. To resume in a new runtime, '
   'rerun setup and restore the archive under `/content/mini_k3_work` before training. '
   'Do not send a report claiming success until the results have been reviewed.')
code(download)
recorded_path = ROOT / 'analysis' / 'pilot_results.json'
if recorded_path.exists():
    recorded = json.loads(recorded_path.read_text(encoding='utf-8'))['summary']
    base, changed = recorded['baseline'], recorded['attnres']
    record = f'''## Recorded pilot: 18 October 2026

Six completed runs on a free T4, with seeds 42, 17 and 123 and 819,200 predicted
training tokens per model per seed. Reduced MiniMind: approximately 13.2M parameters.

| Mean over three seeds | Baseline | Block AttnRes |
| --- | ---: | ---: |
| Validation perplexity (lower is better) | {base['validation_perplexity']['mean']:.2f} | {changed['validation_perplexity']['mean']:.2f} |
| Training tokens/second (higher is better) | {base['median_step_tokens_per_second']['mean']:.0f} | {changed['median_step_tokens_per_second']['mean']:.0f} |

Preliminary TinyStories results: lower validation loss in all three seeds, with a
training-speed cost. Speed optimization and broader evaluation remain.
[Original Colab run](https://colab.research.google.com/drive/1NJODT4RLK_TMQTCbn_lbdLOye45TkFLz).
'''
    cells.insert(1, {'cell_type': 'markdown', 'metadata': {}, 'source': record.splitlines(True)})
notebook = {'nbformat': 4, 'nbformat_minor': 5,
    'metadata': {'accelerator': 'GPU', 'colab': {'name': 'mini_k3_free_colab_pilot.ipynb'},
                 'kernelspec': {'name': 'python3', 'display_name': 'Python 3'},
                 'language_info': {'name': 'python'}}, 'cells': cells}
for i, cell in enumerate(cells):
    cell['id'] = f'minik3-{i:02d}'
(ROOT / 'mini_k3_free_colab_pilot.ipynb').write_text(json.dumps(notebook, indent=2), encoding='utf-8')
for name, text in [('colab_setup.py', setup), ('colab_tests.py', tests),
                   ('colab_data.py', data), ('colab_train.py', train),
                   ('colab_results.py', summary), ('colab_download.py', download)]:
    (ROOT / name).write_text(text, encoding='utf-8')
print('Built notebook:', len(cells), 'cells')
