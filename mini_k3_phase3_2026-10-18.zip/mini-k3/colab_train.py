# First paired pilot: 819,200 predicted training tokens per variant.
# Rerun this unchanged to resume. New settings require a new RUN_NAME.
RUN_NAME = 'pilot001'
run([sys.executable, str(WORK / 'experiment.py'), 'train',
    '--data', str(WORK / 'data'), '--output', str(WORK / 'runs' / RUN_NAME),
    '--size', 'pilot', '--seq', '128', '--batch', '8', '--accum', '4',
    '--steps', '200', '--seeds', '42'])
