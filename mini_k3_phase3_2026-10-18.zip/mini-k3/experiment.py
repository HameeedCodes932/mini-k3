"""Resumable matched-budget MiniMind / Block AttnRes pilot. No results are assumed."""
import argparse
import contextlib
import gc
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import statistics
import subprocess
import time

import numpy as np
import torch
import torch.nn.functional as F
from transformers import AutoTokenizer
from model.model_minimind import MiniMindConfig, MiniMindForCausalLM
from attnres import BlockAttnResModel

UPSTREAM = 'f659b55761b754d306bd140573493a6543cafd7f'
DATASET = 'roneneldan/TinyStories'
DATA_REVISION = 'f54c09fd23315a6f9c86f9dc80f725de7d8f9c64'


def dump_json(path, value):
    path = Path(path)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(value, indent=2, allow_nan=False), encoding='utf-8')
    os.replace(temp, path)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def make_config(size, seq):
    sizes = {'tiny': (64, 2, 4, 2), 'pilot': (384, 6, 6, 2),
             'standard': (768, 8, 8, 4)}
    width, depth, heads, kv = sizes[size]
    return MiniMindConfig(hidden_size=width, num_hidden_layers=depth,
                          num_attention_heads=heads, num_key_value_heads=kv,
                          max_position_embeddings=max(seq, 512),
                          dropout=0.0, use_moe=False)


def build_model(size, seq, variant, seed, block_sublayers=4):
    torch.manual_seed(seed)
    config = make_config(size, seq)
    baseline = MiniMindForCausalLM(config)
    if variant == 'baseline':
        return baseline
    # Copy shared weights exactly; only depth mixing is newly initialized.
    backbone = BlockAttnResModel(config, block_sublayers)
    missing, unexpected = backbone.load_state_dict(baseline.model.state_dict(), strict=False)
    assert not unexpected and all(k.startswith('depth_mixers.') for k in missing)
    baseline.model = backbone
    if config.tie_word_embeddings:
        baseline.model.embed_tokens.weight = baseline.lm_head.weight
    return baseline


def prepare_data(root, upstream_dir, train_tokens=2_000_000, val_tokens=100_000):
    """Cache disjoint, exact-text-deduplicated official train/validation prefixes."""
    from datasets import load_dataset
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    manifest_path = root / 'data_manifest.json'
    tokenizer = AutoTokenizer.from_pretrained(str(Path(upstream_dir) / 'model'),
                                               trust_remote_code=False)
    spec = {'dataset': DATASET, 'revision': DATA_REVISION,
            'train_token_cap': train_tokens, 'validation_token_cap': val_tokens,
            'tokenizer_sha256': digest(Path(upstream_dir) / 'model/tokenizer.json'),
            'selection': 'official split prefixes; exact-text dedup; EOS between stories'}
    if manifest_path.exists():
        old = json.loads(manifest_path.read_text())
        if old['spec'] == spec:
            for split in ('train', 'validation'):
                if digest(root / f'{split}.npy') != old['files'][split]['sha256']:
                    raise RuntimeError('Cached token file changed. Use a new data directory.')
            print('Using verified token cache:', root, flush=True)
            return old
        raise RuntimeError('Data configuration changed. Choose a new data directory.')
    seen, files = set(), {}
    for split, cap in [('train', train_tokens), ('validation', val_tokens)]:
        stream = load_dataset(DATASET, revision=DATA_REVISION, split=split, streaming=True)
        tokens, count = [], 0
        for row in stream:
            text = row['text'].strip()
            if not text:
                continue
            h = hashlib.sha256(text.encode('utf-8')).digest()
            if h in seen:
                continue
            seen.add(h)
            tokens.extend(tokenizer.encode(text, add_special_tokens=False))
            tokens.append(tokenizer.eos_token_id)
            count += 1
            if len(tokens) >= cap:
                break
            if count % 500 == 0:
                print(split, count, 'stories,', len(tokens), 'tokens', flush=True)
        if len(tokens) < cap:
            raise RuntimeError(f'Insufficient {split} tokens: {len(tokens)} < {cap}')
        path = root / f'{split}.npy'
        np.save(path, np.asarray(tokens[:cap], dtype=np.int32))
        files[split] = {'tokens': cap, 'accepted_stories': count, 'sha256': digest(path)}
        print(split, files[split], flush=True)
    manifest = {'spec': spec, 'files': files}
    dump_json(manifest_path, manifest)
    return manifest


def token_blocks(path, seq):
    data = np.load(path, allow_pickle=False)
    n = len(data) // (seq + 1)
    if n < 2:
        raise ValueError('Too few data blocks.')
    return torch.from_numpy(data[:n * (seq + 1)].reshape(n, seq + 1).astype(np.int64))


def training_batch(blocks, seed, step, micro, batch, device):
    # Index generation is independent of model RNG, variant, interruptions and order.
    generator = torch.Generator().manual_seed(seed * 1_000_003 + step * 10_007 + micro)
    ids = torch.randint(len(blocks), (batch,), generator=generator)
    packed = blocks[ids].to(device)
    return packed[:, :-1], packed[:, 1:]


def amp_context(device, dtype):
    return torch.autocast('cuda', dtype=dtype) if device == 'cuda' else contextlib.nullcontext()


def next_token_loss(model, x, y):
    logits = model(x, use_cache=False).logits
    return F.cross_entropy(logits.float().reshape(-1, logits.size(-1)), y.reshape(-1))


@torch.no_grad()
def evaluate(model, blocks, batch, device, dtype, max_blocks):
    model.eval()
    total, tokens = 0.0, 0
    for start in range(0, min(len(blocks), max_blocks), batch):
        packed = blocks[start:min(start + batch, max_blocks)].to(device)
        x, y = packed[:, :-1], packed[:, 1:]
        with amp_context(device, dtype):
            loss = next_token_loss(model, x, y)
        total += loss.item() * y.numel()
        tokens += y.numel()
    model.train()
    nll = total / tokens
    return {'validation_nll': nll, 'validation_perplexity': math.exp(nll),
            'validation_tokens': tokens}


def synchronize(device):
    if device == 'cuda':
        torch.cuda.synchronize()


def environment(device):
    import transformers
    return {'python': platform.python_version(), 'torch': str(torch.__version__),
            'transformers': transformers.__version__, 'cuda': torch.version.cuda,
            'device': device,
            'gpu': torch.cuda.get_device_name(0) if device == 'cuda' else None,
            'gpu_memory_bytes': torch.cuda.get_device_properties(0).total_memory
                if device == 'cuda' else None}


def run_variant(args, variant, seed):
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    if device == 'cpu' and args.size != 'tiny':
        raise RuntimeError('GPU unavailable. Use --size tiny only for a CPU smoke test.')
    torch.set_num_threads(min(4, os.cpu_count() or 1))
    dtype = torch.bfloat16 if device == 'cuda' and torch.cuda.is_bf16_supported() else torch.float16
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    train = token_blocks(Path(args.data) / 'train.npy', args.seq)
    val = token_blocks(Path(args.data) / 'validation.npy', args.seq)
    run_dir = Path(args.output) / f'{variant}_seed{seed}'
    run_dir.mkdir(parents=True, exist_ok=True)
    spec = {k: getattr(args, k) for k in ('size', 'seq', 'batch', 'accum', 'steps',
        'lr', 'eval_every', 'eval_blocks', 'block_sublayers', 'save_every')}
    spec.update(seed=seed, variant=variant, upstream_commit=UPSTREAM,
                data_manifest_sha256=digest(Path(args.data) / 'data_manifest.json'),
                experiment_sha256=digest(__file__), attnres_sha256=digest(Path(__file__).with_name('attnres.py')),
                environment=environment(device))
    metadata = run_dir / 'config.json'
    if metadata.exists() and json.loads(metadata.read_text()) != spec:
        raise RuntimeError('Run configuration/environment changed. Choose a new output folder.')
    dump_json(metadata, spec)
    model = build_model(args.size, args.seq, variant, seed, args.block_sublayers).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, betas=(0.9, 0.95), weight_decay=0.1)
    scaler = torch.amp.GradScaler('cuda', init_scale=1024.0,
                                 enabled=device == 'cuda' and dtype == torch.float16)
    checkpoint = run_dir / 'latest.pt'
    history, timing, start = [], [], 0
    if checkpoint.exists():
        saved = torch.load(checkpoint, map_location='cpu', weights_only=True)
        if saved['spec'] != spec:
            raise RuntimeError('Checkpoint does not match this experiment.')
        model.load_state_dict(saved['model'])
        optimizer.load_state_dict(saved['optimizer'])
        scaler.load_state_dict(saved['scaler'])
        history, timing, start = saved['history'], saved['timing'], saved['step']
        torch.set_rng_state(saved['cpu_rng'])
        if device == 'cuda':
            torch.cuda.set_rng_state_all(saved['cuda_rng'])
        print('Resumed', variant, 'at optimizer step', start, flush=True)
    else:
        torch.manual_seed(seed + 1)
        history.append({'step': 0, **evaluate(model, val, args.batch, device, dtype, args.eval_blocks)})
    if device == 'cuda':
        torch.cuda.reset_peak_memory_stats()

    def save(step):
        state = {'spec': spec, 'model': model.state_dict(), 'optimizer': optimizer.state_dict(),
            'scaler': scaler.state_dict(), 'step': step, 'history': history, 'timing': timing,
            'cpu_rng': torch.get_rng_state(),
            'cuda_rng': torch.cuda.get_rng_state_all() if device == 'cuda' else []}
        temp = checkpoint.with_suffix('.pt.tmp')
        torch.save(state, temp)
        os.replace(temp, checkpoint)
        dump_json(run_dir / 'history.json', history)
        dump_json(run_dir / 'timing.json', timing)

    print(variant, 'parameters:', sum(p.numel() for p in model.parameters()), flush=True)
    model.train()
    for step in range(start, args.steps):
        # Both variants receive the same warmup/cosine learning rate and token stream.
        warmup = max(1, args.steps // 20)
        progress = max(0, step - warmup) / max(1, args.steps - warmup)
        lr = args.lr * min(1.0, (step + 1) / warmup) * (0.1 + 0.9 * (1 + math.cos(math.pi * progress)) / 2)
        for group in optimizer.param_groups:
            group['lr'] = lr
        optimizer.zero_grad(set_to_none=True)
        synchronize(device)
        began, losses = time.perf_counter(), []
        for micro in range(args.accum):
            x, y = training_batch(train, seed, step, micro, args.batch, device)
            with amp_context(device, dtype):
                loss = next_token_loss(model, x, y)
            if not torch.isfinite(loss):
                raise FloatingPointError('Non-finite loss. Last checkpoint retained.')
            losses.append(loss.detach())
            scaler.scale(loss / args.accum).backward()
        scaler.unscale_(optimizer)
        grad_norm = torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        if not torch.isfinite(grad_norm):
            # No silently skipped FP16 updates: stop so paired token budgets stay equal.
            raise FloatingPointError('Non-finite gradient. Reduce LR or adjust precision in a new paired run.')
        scaler.step(optimizer)
        scaler.update()
        synchronize(device)
        elapsed = time.perf_counter() - began
        timing.append({'step': step + 1, 'seconds': elapsed,
                       'tokens': args.batch * args.seq * args.accum})
        if (step + 1) % 10 == 0 or step == start:
            print(variant, seed, f'{step+1}/{args.steps}',
                  'train_nll', round(torch.stack(losses).mean().item(), 4),
                  'tokens/s', round(args.batch * args.seq * args.accum / elapsed), flush=True)
        if (step + 1) % args.eval_every == 0 or step + 1 == args.steps:
            row = {'step': step + 1, **evaluate(model, val, args.batch, device, dtype, args.eval_blocks)}
            history.append(row)
            print('EVAL', variant, row, flush=True)
        if (step + 1) % args.save_every == 0 or step + 1 == args.steps:
            save(step + 1)
    measured = [r for r in timing if r['step'] > 2]
    result = {'variant': variant, 'seed': seed, 'completed_steps': args.steps,
              'parameters': sum(p.numel() for p in model.parameters()),
              'training_tokens': args.steps * args.batch * args.seq * args.accum,
              'median_step_tokens_per_second': statistics.median(r['tokens'] / r['seconds'] for r in measured)
                  if measured else None,
              'training_step_seconds': sum(r['seconds'] for r in timing),
              'peak_allocated_gpu_bytes_this_session': torch.cuda.max_memory_allocated() if device == 'cuda' else None,
              'resume_step_this_session': start,
              'environment': environment(device), **history[-1]}
    dump_json(run_dir / 'result.json', result)
    print('RESULT', json.dumps(result), flush=True)
    del model, optimizer, scaler
    gc.collect()
    if device == 'cuda':
        torch.cuda.empty_cache()
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=['prepare', 'train'])
    parser.add_argument('--upstream', default='vendor')
    parser.add_argument('--data', default='data')
    parser.add_argument('--output', default='runs/pilot001')
    parser.add_argument('--size', choices=['tiny', 'pilot', 'standard'], default='pilot')
    parser.add_argument('--seq', type=int, default=128)
    parser.add_argument('--batch', type=int, default=8)
    parser.add_argument('--accum', type=int, default=4)
    parser.add_argument('--steps', type=int, default=200)
    parser.add_argument('--lr', type=float, default=3e-4)
    parser.add_argument('--eval-every', type=int, default=50)
    parser.add_argument('--save-every', type=int, default=25)
    parser.add_argument('--eval-blocks', type=int, default=256)
    parser.add_argument('--block-sublayers', type=int, default=4)
    parser.add_argument('--seeds', type=int, nargs='+', default=[42])
    parser.add_argument('--variants', nargs='+', choices=['baseline', 'attnres'], default=['baseline', 'attnres'])
    args = parser.parse_args()
    for key in ('seq', 'batch', 'accum', 'steps', 'eval_every', 'save_every', 'eval_blocks', 'block_sublayers'):
        if getattr(args, key) < 1:
            parser.error(f'{key} must be positive')
    if args.command == 'prepare':
        prepare_data(args.data, args.upstream)
        return
    results = []
    for seed in args.seeds:
        for variant in args.variants:
            results.append(run_variant(args, variant, seed))
    Path(args.output).mkdir(parents=True, exist_ok=True)
    dump_json(Path(args.output) / 'results.json', results)


if __name__ == '__main__':
    main()
