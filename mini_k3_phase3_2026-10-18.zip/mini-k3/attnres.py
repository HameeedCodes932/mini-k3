"""Block Attention Residuals adapted to the pinned MiniMind backbone.

Reference: Kimi K3, section 2.2, equations 8--10:
https://arxiv.org/html/2607.24653v2#S2.SS2
This small PyTorch implementation is not Moonshot's optimized kernel.
"""
import torch
from torch import nn
from model.model_minimind import MiniMindModel, RMSNorm


class DepthMixer(nn.Module):
    def __init__(self, width, eps=1e-6):
        super().__init__()
        self.query = nn.Parameter(torch.zeros(width))
        self.key_norm = RMSNorm(width, eps)

    def forward(self, sources):
        # sources: list of [batch, sequence, width]. Softmax is over depth.
        values = torch.stack(sources, dim=0)
        keys = self.key_norm(values).float()
        scores = (keys * self.query.float()).sum(dim=-1)
        weights = scores.softmax(dim=0)
        return (values.float() * weights.unsqueeze(-1)).sum(dim=0).to(values.dtype)


class BlockAttnResModel(MiniMindModel):
    def __init__(self, config, block_sublayers=4):
        super().__init__(config)
        if block_sublayers < 1 or config.use_moe:
            raise ValueError('This pilot supports dense models and positive block sizes.')
        self.block_sublayers = block_sublayers
        self.depth_mixers = nn.ModuleList([
            DepthMixer(config.hidden_size, config.rms_norm_eps)
            for _ in range(2 * config.num_hidden_layers + 1)
        ])

    def forward(self, input_ids, attention_mask=None, past_key_values=None,
                use_cache=False, **kwargs):
        if use_cache or past_key_values is not None:
            raise NotImplementedError('Pilot backbone has no KV cache; use_cache=False.')
        seq = input_ids.shape[1]
        if seq > self.config.max_position_embeddings:
            raise ValueError('Sequence exceeds configured context length.')
        embedding = self.dropout(self.embed_tokens(input_ids))
        positions = (self.freqs_cos[:seq], self.freqs_sin[:seq])
        completed, partial, index = [embedding], None, 0
        for layer in self.layers:
            for kind in ('attention', 'mlp'):
                sources = completed + ([] if partial is None else [partial])
                hidden = self.depth_mixers[index](sources)
                if kind == 'attention':
                    delta, _ = layer.self_attn(
                        layer.input_layernorm(hidden), positions,
                        use_cache=False, attention_mask=attention_mask)
                else:
                    delta = layer.mlp(layer.post_attention_layernorm(hidden))
                partial = delta if partial is None else partial + delta
                index += 1
                if index % self.block_sublayers == 0:
                    completed.append(partial)
                    partial = None
        sources = completed + ([] if partial is None else [partial])
        hidden = self.norm(self.depth_mixers[index](sources))
        return hidden, [None] * len(self.layers), hidden.new_zeros(())
