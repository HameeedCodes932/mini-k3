"""Create an untouched story-level holdout after the phase-one validation prefix."""
import hashlib
import json
from pathlib import Path
import numpy as np
from datasets import load_dataset
from transformers import AutoTokenizer
from experiment import DATASET, DATA_REVISION, digest, dump_json

ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'phase2/data'
OUT.mkdir(parents=True,exist_ok=True)
if (OUT/'holdout_manifest.json').exists():
    manifest=json.loads((OUT/'holdout_manifest.json').read_text())
    assert digest(OUT/'holdout.npy')==manifest['holdout_sha256']
    print('HOLDOUT_CACHE_VERIFIED',manifest,flush=True)
    raise SystemExit(0)
old=json.loads((ROOT/'data/data_manifest.json').read_text())
for split in ('train','validation'):
    assert digest(ROOT/f'data/{split}.npy')==old['files'][split]['sha256']
tokenizer=AutoTokenizer.from_pretrained(str(ROOT/'vendor/model'),trust_remote_code=False)
seen=set()
def encode(row):
    text=row['text'].strip()
    if not text:
        return None
    key=hashlib.sha256(text.encode('utf-8')).digest()
    if key in seen:
        return None
    seen.add(key)
    return tokenizer.encode(text,add_special_tokens=False)+[tokenizer.eos_token_id]
train_tokens=[]; train_count=0
for row in load_dataset(DATASET,revision=DATA_REVISION,split='train',streaming=True):
    token_ids=encode(row)
    if token_ids is None:
        continue
    train_tokens.extend(token_ids);train_count+=1
    if len(train_tokens)>=old['files']['train']['tokens']:
        break
assert np.array_equal(np.asarray(train_tokens[:2_000_000],dtype=np.int32),np.load(ROOT/'data/train.npy'))
print('Original train prefix reconstructed exactly; complete-story hashes retained.',flush=True)
validation_tokens=[];holdout=[];prefix_count=0;holdout_count=0
for row in load_dataset(DATASET,revision=DATA_REVISION,split='validation',streaming=True):
    token_ids=encode(row)
    if token_ids is None:
        continue
    if len(validation_tokens)<100_000:
        validation_tokens.extend(token_ids);prefix_count+=1
    else:
        holdout.extend(token_ids);holdout_count+=1
        if len(holdout)>=128_000:
            break
assert np.array_equal(np.asarray(validation_tokens[:100_000],dtype=np.int32),np.load(ROOT/'data/validation.npy'))
assert len(holdout)>=128_000
np.save(OUT/'holdout.npy',np.asarray(holdout[:128_000],dtype=np.int32))
manifest={'dataset':DATASET,'revision':DATA_REVISION,
    'selection':'Subsequent complete stories from official validation split, after all phase-one validation stories; exact text dedup against complete selected train/validation stories',
    'train_stories_reconstructed':train_count,'validation_prefix_stories':prefix_count,
    'holdout_stories':holdout_count,'holdout_token_cap':128_000,
    'holdout_sha256':digest(OUT/'holdout.npy'),
    'phase1_data_manifest_sha256':digest(ROOT/'data/data_manifest.json'),
    'role':'Held-out evaluation partition; not the dataset official test split; do not use for selecting hyperparameters.'}
dump_json(OUT/'holdout_manifest.json',manifest)
print('HOLDOUT_READY',json.dumps(manifest),flush=True)
