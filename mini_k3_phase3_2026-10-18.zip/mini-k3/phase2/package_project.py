"""Package code and measured evidence; model bytes are retained in Drive."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT.parent/'mini_k3_phase2_2026-10-18.zip'
excluded={'.venv','.git','__pycache__','tmp'}
with zipfile.ZipFile(OUT,'w',compression=zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(ROOT.rglob('*')):
        if not path.is_file():continue
        relative=path.relative_to(ROOT)
        if any(part in excluded for part in relative.parts):continue
        if path.suffix in ('.pt','.npy','.pyc') or path.name.endswith(('.tmp','.copying','_trace.json')):continue
        archive.write(path,Path('mini-k3')/relative)
with zipfile.ZipFile(OUT) as archive:
    assert archive.testzip() is None
    names=archive.namelist()
    assert 'mini-k3/output/pdf/Mini_K3_Technical_Report_Fazal_Hameed.pdf' in names
    assert 'mini-k3/phase2/mini_k3_stage2.ipynb' in names
    assert 'mini-k3/artifacts/colab_phase2_confirmation.png' in names
    assert not any(name.endswith(('.pt','.npy')) for name in names)
    proof=json.loads(archive.read('mini-k3/drive_backup_delivery.json'))
    report=next(r for r in proof['files'] if r['relative_destination'].endswith('/Mini_K3_Technical_Report_Fazal_Hameed.pdf'))
    assert hashlib.sha256(archive.read('mini-k3/output/pdf/Mini_K3_Technical_Report_Fazal_Hameed.pdf')).hexdigest()==report['sha256']
sha=hashlib.sha256(OUT.read_bytes()).hexdigest()
OUT.with_suffix('.zip.sha256').write_text(f'{sha}  {OUT.name}\n',encoding='ascii')
print(json.dumps({'archive':str(OUT),'bytes':OUT.stat().st_size,'files':len(names),'sha256':sha}))
