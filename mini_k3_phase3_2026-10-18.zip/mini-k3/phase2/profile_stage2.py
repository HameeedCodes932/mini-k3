"""Profile the original implementations without changing phase-one checkpoints."""
import gc
import json
from pathlib import Path
import torch
from torch.profiler import profile, ProfilerActivity, record_function
from experiment import build_model, token_blocks, training_batch, next_token_loss, environment

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'phase2' / 'results'
OUT.mkdir(parents=True, exist_ok=True)
assert torch.cuda.is_available(), 'Reconnect to a T4 GPU runtime.'
torch.set_num_threads(4)
data = token_blocks(ROOT / 'data/train.npy', 128)
summaries = {}
for variant in ('baseline', 'attnres'):
    model = build_model('pilot', 128, variant, 42).cuda().train()
    optimizer = torch.optim.AdamW(model.parameters(), lr=3e-4, betas=(.9,.95), weight_decay=.1)
    scaler = torch.amp.GradScaler('cuda', init_scale=1024)
    def step(index):
        optimizer.zero_grad(set_to_none=True)
        for micro in range(4):
            x,y = training_batch(data,42,index,micro,8,'cuda')
            with torch.autocast('cuda',dtype=torch.float16):
                loss = next_token_loss(model,x,y) / 4
            scaler.scale(loss).backward()
        scaler.unscale_(optimizer)
        torch.nn.utils.clip_grad_norm_(model.parameters(),1.0)
        scaler.step(optimizer)
        scaler.update()
    for i in range(3):
        step(i)
    torch.cuda.synchronize()
    with profile(activities=[ProfilerActivity.CPU,ProfilerActivity.CUDA],
                 record_shapes=True, profile_memory=True) as prof:
        with record_function(variant):
            for i in range(3,5):
                step(i)
        torch.cuda.synchronize()
    events=[]
    for e in prof.key_averages():
        events.append({'name':e.key,'calls':e.count,
            'self_cpu_us':float(e.self_cpu_time_total),
            'self_device_us':float(getattr(e,'self_device_time_total',0)),
            'device_total_us':float(getattr(e,'device_time_total',0))})
    events.sort(key=lambda e:e['self_device_us'],reverse=True)
    summaries[variant]={'environment':environment('cuda'),'profiled_steps':2,'events':events}
    print('\nPROFILE',variant,flush=True)
    print(json.dumps(events[:20],indent=2),flush=True)
    prof.export_chrome_trace(str(OUT/f'{variant}_trace.json'))
    del model,optimizer,scaler,prof
    gc.collect()
    torch.cuda.empty_cache()
(OUT/'original_profiles.json').write_text(json.dumps(summaries,indent=2))
print('PROFILE_COMPLETE',OUT/'original_profiles.json',flush=True)
