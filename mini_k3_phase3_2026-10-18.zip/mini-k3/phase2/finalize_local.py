"""Refresh the current entry point without rewriting historical source or scores."""
import hashlib
import json
from pathlib import Path
import statistics

ROOT=Path(__file__).resolve().parent.parent
bundle=json.loads((ROOT/'phase2/analysis/phase2_results.json').read_text())
summary=bundle['summary']
gain=statistics.mean(r['heldout_perplexity_reduction_percent'] for r in bundle['paired'])
speed=statistics.mean(r['throughput_change_percent'] for r in bundle['paired'])
drive=json.loads((ROOT/'drive_backup_final.json').read_text())
checks=[r for r in drive['files'] if r['relative_destination'].endswith('/latest.pt')]
assert len(checks)==12
text=f'''# mini-k3: phase two completed on free Colab

On 18 October 2026, six longer runs completed on a free Tesla T4: baseline and
Block Attention Residuals at seeds 42, 17 and 123. Each trained a reduced 13.2M
MiniMind from scratch for 1,000 updates (4,096,000 predicted training tokens).

| Mean over three seeds | Baseline | Attention residuals |
| --- | ---: | ---: |
| Heldout perplexity (lower is better) | {summary['baseline']['heldout_perplexity']['mean']:.3f} | {summary['attnres']['heldout_perplexity']['mean']:.3f} |
| Training tokens/second (higher is better) | {summary['baseline']['training_tokens_per_second']['mean']:,.0f} | {summary['attnres']['training_tokens_per_second']['mean']:,.0f} |

Mean paired heldout perplexity reduction: **{gain:.2f}%**. Mean paired throughput
change: **{speed:+.2f}%**. The new comparison uses matching FP32 residual/block
accumulation, FP16 linear operations, the same optimized training engine and a
separate set of 472 previously unused stories (126,976 evaluated predicted tokens).
Both architectures benefit from the faster training pipeline. The AttnRes model
remains slower than the equally optimized baseline, so the complete
faster-and-stronger objective has not yet been met. This is an English-domain
language-modeling experiment, not a general-purpose assistant benchmark.

## Read and reproduce

- Shareable report: `output/pdf/Mini_K3_Technical_Report_Fazal_Hameed.pdf`.
- Detailed Markdown report: `phase2/analysis/PHASE2_REPORT.md`.
- Clean runnable notebook: `phase2/mini_k3_stage2.ipynb`.
- Explanation for reviewing the work: `phase2/RESEARCH_NOTES.md`.
- Measured scores, histories and timings: `phase2/analysis/`, `phase2/runs/`,
  `phase2/results/` and `artifacts/phase2_measured_logs_2026-10-18.zip`.
- Live notebook: https://colab.research.google.com/drive/1NJODT4RLK_TMQTCbn_lbdLOye45TkFLz

## Verified backups

The user approved connecting this notebook to Google Drive. All **12 completed
model checkpoints** (six original pilot, six longer controlled runs), cached
tokens, tokenizer, pinned source and measured logs are backed up under
`My Drive/mini-k3/2026-10-18`:

{drive['folder_url']}

Copies are verified by SHA-256. `drive_backup_final.json` records file sizes and
checksums. Model checkpoint bytes remain in Drive and the live runtime; they
have not been copied to the laptop. Local ZIP bundles contain code, logs,
manifests, reports and charts. `/content` is temporary, so use the Drive backup
for restoration rather than relying on the Colab session.

## How the first pilot should now be interpreted

The original 200-step pilot reported a 23.9% paired validation-perplexity
reduction, but a later audit found different residual-accumulation precision
between its two paths. That gain cannot be attributed solely to architecture.
Phase two controls precision and trains longer; it is not a direct isolation
of the precision effect because its budget and learning-rate schedule also
change. Historical pilot source and measured JSON records are preserved.

Correctness checks cover cached/reference outputs and gradients, shared
initialization, causal outputs, FP32 states under autocast, and compiled/eager
scaled gradients. An earlier unscaled FP16 gradient check failed; the diagnostic
and its resolution are documented in the report. No tolerance was loosened.

'''
(ROOT/'START_HERE.md').write_text(text,encoding='utf-8')
historical=ROOT/'analysis/PRELIMINARY_REPORT.md'
old=historical.read_text(encoding='utf-8')
note='> Later audit: the original paths differ in residual-accumulation precision. The measured 23.9% gain includes that confound. See `../phase2/analysis/PHASE2_REPORT.md` for the longer precision-controlled comparison. Historical scores below are unchanged.\n\n'
if note not in old:historical.write_text(note+old,encoding='utf-8')
manifest_path=ROOT/'source_manifest.json'
manifest=json.loads(manifest_path.read_text(encoding='utf-8'))
manifest.update(status='Phase-two six-run precision-controlled study completed; all twelve model checkpoints verified in Google Drive',
    drive_backup_folder_url=drive['folder_url'],phase2_measured_log_archive_sha256=hashlib.sha256((ROOT/'artifacts/phase2_measured_logs_2026-10-18.zip').read_bytes()).hexdigest())
manifest_path.write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print('Current entry point and backup status updated. Historical source and measured scores preserved.')
