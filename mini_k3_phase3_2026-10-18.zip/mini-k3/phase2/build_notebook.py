"""Create a self-contained notebook for the reviewed phase-two experiment."""
import ast
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
cells=[]
def md(text):cells.append({'cell_type':'markdown','metadata':{},'source':text.splitlines(keepends=True)})
def code(text):
    ast.parse(text)
    cells.append({'cell_type':'code','metadata':{},'source':text.splitlines(keepends=True),'outputs':[],'execution_count':None})
md('# mini-k3: longer precision-controlled comparison\n\n'
   'Free Colab T4 workflow. Baseline and Block AttnRes use FP32 residual states and FP16 linear autocast. '
   'Six fixed 1,000-step runs; new heldout stories used only at the endpoint. '
   'Inspect the code before running. This is a 13.2M-model TinyStories study, not a complete K3 reproduction.\n\n'
   'The live research notebook is [here](https://colab.research.google.com/drive/1NJODT4RLK_TMQTCbn_lbdLOye45TkFLz). '
   'This clean notebook carries source, not fabricated cell outputs. Read `analysis/PHASE2_REPORT.md` for recorded results.\n')
code("import sys,torch\nprint(sys.version,torch.__version__)\nassert torch.cuda.is_available(),'Select Runtime > Change runtime type > T4 GPU'\nprint(torch.cuda.get_device_name(0))\n")
upstream_files=['model/model_minimind.py','model/tokenizer.json','model/tokenizer_config.json','LICENSE']
hashes={name:hashlib.sha256((ROOT/'vendor'/name).read_bytes()).hexdigest() for name in upstream_files}
payload={name:(ROOT/name).read_bytes().decode('utf-8') for name in ('attnres.py','experiment.py','test_experiment.py')}
for name in ('optimized.py','controlled.py','test_optimized.py','test_controlled.py',
             'benchmark_stage2.py','prepare_holdout.py','train_stage2.py','backup.py',
             'analyze_stage2.py','profile_stage2.py','export_logs.py'):
    payload['phase2/'+name]=(HERE/name).read_bytes().decode('utf-8')
for name,source in payload.items():ast.parse(source,filename=name)
setup='''import os,subprocess,urllib.request,hashlib,json
from pathlib import Path
WORK=Path('/content/mini_k3_work')
WORK.mkdir(exist_ok=True)
subprocess.check_call([sys.executable,'-m','pip','install','-q','transformers==4.57.6','datasets==3.6.0','matplotlib'])
os.environ.update(USE_TF='0',USE_FLAX='0',HF_HUB_DISABLE_XET='1',TOKENIZERS_PARALLELISM='false')
os.environ['PYTHONPATH']=str(WORK/'vendor')+os.pathsep+str(WORK)
'''
setup+=f'EXPECTED={hashes!r}\n'
setup+='''for name,expected in EXPECTED.items():
    target=WORK/'vendor'/name
    target.parent.mkdir(parents=True,exist_ok=True)
    data=urllib.request.urlopen('https://raw.githubusercontent.com/jingyaogong/minimind/f659b55761b754d306bd140573493a6543cafd7f/'+name).read()
    assert hashlib.sha256(data).hexdigest()==expected
    target.write_bytes(data)
'''
setup+=f'PAYLOAD={payload!r}\n'
setup+='''for name,source in PAYLOAD.items():
    target=WORK/name
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(source.encode('utf-8'))
def run(command):
    with subprocess.Popen(command,cwd=WORK,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1) as p:
        for line in p.stdout:print(line,end='',flush=True)
        status=p.wait()
    if status:raise RuntimeError(f'Experiment command failed: {status}')
print('Pinned source ready',WORK)
'''
code(setup)
md('## Optional Drive backup\n\nRun this cell to grant the notebook access to your Drive files. '
   'The research session already obtained Fazal’s permission. On a new session, review the access prompt. '
   'Only this experiment’s files are copied into `MyDrive/mini-k3/2026-10-18`; no sharing permissions are changed. '
   'Skip this cell to keep results temporary in `/content` and download them yourself.\n')
code("from google.colab import drive\ndrive.mount('/content/drive')\nDRIVE_BACKUP=Path('/content/drive/MyDrive/mini-k3/2026-10-18')\nos.environ['MINIK3_DRIVE_BACKUP']=str(DRIVE_BACKUP)\n")
md('## Recreate the pinned data and untouched stories\n\n'
   'If only manifests were restored, also restore their `.npy` files or use a fresh data directory. '
   'Do not change a completed run’s source/configuration and resume it under the same name.\n')
code("run([sys.executable,str(WORK/'experiment.py'),'prepare','--upstream',str(WORK/'vendor'),'--data',str(WORK/'data')])\nrun([sys.executable,str(WORK/'phase2/prepare_holdout.py')])\n")
md('## Verify and select the engine\n\n'
   'The compiled engine is used only when both models pass scaled-gradient checks and both benchmark speed thresholds. '
   'Otherwise both use eager execution. Compiler cache state affects first-step time.\n')
code("run([sys.executable,str(WORK/'test_experiment.py')])\nrun([sys.executable,str(WORK/'phase2/test_optimized.py')])\nrun([sys.executable,str(WORK/'phase2/test_controlled.py')])\nrun([sys.executable,str(WORK/'phase2/benchmark_stage2.py')])\n")
code("if os.environ.get('MINIK3_DRIVE_BACKUP'):\n    import sys\n    sys.path.insert(0,str(WORK/'phase2'))\n    from backup import backup_tree\n    backup_tree(WORK,Path(os.environ['MINIK3_DRIVE_BACKUP']))\nrun([sys.executable,str(WORK/'phase2/train_stage2.py')])\n")
code("run([sys.executable,str(WORK/'phase2/analyze_stage2.py')])\nfrom IPython.display import display,Markdown,Image\ndisplay(Markdown((WORK/'phase2/analysis/PHASE2_REPORT.md').read_text()))\ndisplay(Image(filename=str(WORK/'phase2/analysis/phase2_results.png')))\nif os.environ.get('MINIK3_DRIVE_BACKUP'):\n    backup_tree(WORK,Path(os.environ['MINIK3_DRIVE_BACKUP']))\n")
notebook={'cells':cells,'metadata':{'colab':{'name':'mini_k3_stage2.ipynb'},'accelerator':'GPU','kernelspec':{'display_name':'Python 3','language':'python','name':'python3'},'language_info':{'name':'python'}},'nbformat':4,'nbformat_minor':5}
(HERE/'mini_k3_stage2.ipynb').write_text(json.dumps(notebook,indent=1,ensure_ascii=False),encoding='utf-8')
print('Created',HERE/'mini_k3_stage2.ipynb',len(cells),'cells')
