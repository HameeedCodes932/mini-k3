"""Copy only this experiment's files to the explicitly authorized Drive folder."""
import hashlib
import json
import os
from pathlib import Path
import shutil


def sha256(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as handle:
        for chunk in iter(lambda:handle.read(4*1024*1024),b''):
            h.update(chunk)
    return h.hexdigest()


def verified_copy(source,destination):
    source,destination=Path(source),Path(destination)
    destination.parent.mkdir(parents=True,exist_ok=True)
    expected=sha256(source)
    if not destination.exists() or sha256(destination)!=expected:
        temp=destination.with_name(destination.name+'.copying')
        with source.open('rb') as src,temp.open('wb') as dst:
            shutil.copyfileobj(src,dst,4*1024*1024)
            dst.flush();os.fsync(dst.fileno())
        assert sha256(temp)==expected,'Backup verification failed'
        os.replace(temp,destination)
    return {'relative_destination':str(destination),'bytes':source.stat().st_size,'sha256':expected}


def backup_tree(root,destination,include_checkpoints=True):
    root,destination=Path(root),Path(destination)
    records=[]
    for path in sorted(root.rglob('*')):
        if not path.is_file() or any(p in ('.venv','.git','__pycache__') for p in path.relative_to(root).parts):
            continue
        if path.name.endswith(('.tmp','.copying')) or path.name.endswith('_trace.json'):
            continue
        if not include_checkpoints and path.suffix=='.pt':
            continue
        record=verified_copy(path,destination/path.relative_to(root))
        records.append(record)
        if path.suffix=='.pt':print('CHECKPOINT_BACKED_UP',json.dumps(record),flush=True)
    manifest=destination/'backup_manifest.json'
    manifest.write_text(json.dumps(records,indent=2),encoding='utf-8')
    print('BACKUP_VERIFIED',len(records),'files',sum(r['bytes'] for r in records),'bytes',destination,flush=True)
    return records
