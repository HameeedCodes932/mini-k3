"""Equivalence checks for numerical changes and cached depth mixing."""
import copy
import json
from pathlib import Path
import unittest
import torch
from experiment import build_model
from optimized import TrainingLM, TrainingLoss


class OptimizedTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(2)

    def test_upstream_wrapper_matches_original(self):
        original = build_model('tiny',16,'baseline',42).eval()
        wrapped = TrainingLM(copy.deepcopy(original), 'upstream').eval()
        x = torch.randint(0,6400,(2,12))
        torch.testing.assert_close(original(x).logits, wrapped(x), rtol=0, atol=0)

    def test_cached_logits_and_gradients(self):
        for block in (1,3,4,8):
            original = build_model('tiny',16,'attnres',42,block)
            # Nonzero queries and learned RMS weights exercise actual depth selection.
            with torch.no_grad():
                for m in original.model.depth_mixers:
                    m.query.normal_(0,.1)
                    m.key_norm.weight.uniform_(.8,1.2)
            a = TrainingLM(copy.deepcopy(original),'attnres_reference')
            b = TrainingLM(copy.deepcopy(original),'attnres_cached')
            x = torch.randint(0,6400,(2,12))
            y = torch.randint(0,6400,(2,12))
            torch.testing.assert_close(a(x), b(x), rtol=2e-4, atol=2e-6)
            TrainingLoss(a)(x,y).backward()
            TrainingLoss(b)(x,y).backward()
            for (name,p),(name2,q) in zip(a.named_parameters(),b.named_parameters()):
                self.assertEqual(name,name2)
                gp = torch.zeros_like(p) if p.grad is None else p.grad
                gq = torch.zeros_like(q) if q.grad is None else q.grad
                torch.testing.assert_close(gp,gq,rtol=2e-3,atol=3e-6,msg=name)

    def test_cached_is_causal(self):
        model=TrainingLM(build_model('tiny',16,'attnres',42),'attnres_cached').eval()
        x=torch.randint(0,6400,(2,12))
        y=x.clone(); y[:,7:]=torch.randint(0,6400,y[:,7:].shape)
        torch.testing.assert_close(model(x)[:,:7],model(y)[:,:7],rtol=1e-5,atol=1e-5)

    @unittest.skipUnless(torch.cuda.is_available(),'CUDA check runs in Colab')
    def test_cuda_fp16_equivalence(self):
        original=build_model('pilot',128,'attnres',42)
        with torch.no_grad():
            for mixer in original.model.depth_mixers:
                mixer.query.normal_(0,.02)
        a=TrainingLM(copy.deepcopy(original),'attnres_reference').cuda()
        b=TrainingLM(copy.deepcopy(original),'attnres_cached').cuda()
        x=torch.randint(0,6400,(2,128),device='cuda')
        with torch.autocast('cuda',dtype=torch.float16):
            ya,yb=a(x),b(x)
        torch.testing.assert_close(ya,yb,rtol=1e-2,atol=2e-3)
        # The wrapper must also preserve upstream's mixed-precision path.
        original=build_model('tiny',16,'baseline',42).cuda()
        wrapped=TrainingLM(copy.deepcopy(original),'upstream').cuda()
        with torch.autocast('cuda',dtype=torch.float16):
            ya=original(x[:,:12]).logits; yb=wrapped(x[:,:12])
        torch.testing.assert_close(ya,yb,rtol=0,atol=0)


if __name__=='__main__':
    unittest.main(verbosity=2)
