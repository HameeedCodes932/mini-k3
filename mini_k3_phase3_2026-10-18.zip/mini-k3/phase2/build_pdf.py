"""Typeset the measured Markdown report as a readable, shareable PDF."""
from html import escape
import json
from pathlib import Path
import re
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle,getSampleStyleSheet
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,Image,KeepTogether

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
source=HERE/'analysis/PHASE2_REPORT.md'
output=ROOT/'output/pdf/Mini_K3_Technical_Report_Fazal_Hameed.pdf'
output.parent.mkdir(parents=True,exist_ok=True)
fontroot=Path('C:/Windows/Fonts')
pdfmetrics.registerFont(TTFont('ReportArial',str(fontroot/'arial.ttf')))
pdfmetrics.registerFont(TTFont('ReportArialBold',str(fontroot/'arialbd.ttf')))
pdfmetrics.registerFontFamily('ReportArial',normal='ReportArial',bold='ReportArialBold',italic='ReportArial',boldItalic='ReportArialBold')
styles={
    'title':ParagraphStyle('Title',fontName='ReportArialBold',fontSize=22,leading=27,textColor=colors.HexColor('#123f53'),spaceAfter=14),
    'heading':ParagraphStyle('Heading',fontName='ReportArialBold',fontSize=13,leading=17,textColor=colors.HexColor('#123f53'),spaceBefore=14,spaceAfter=7,keepWithNext=True),
    'body':ParagraphStyle('Body',fontName='ReportArial',fontSize=9.4,leading=13.5,spaceAfter=7),
    'table':ParagraphStyle('TableBody',fontName='ReportArial',fontSize=7.7,leading=10),
    'tablehead':ParagraphStyle('TableHeader',fontName='ReportArialBold',fontSize=7.5,leading=10,textColor=colors.white),
}
def inline(text):
    text=text.replace('\u2011','-').replace('\u2013','-').replace('\u2014',' - ').replace('\u2193',' (lower)').replace('\u2191',' (higher)')
    text=escape(text)
    text=re.sub(r'\[([^\]]+)\]\((https?://[^\s)]+)\)',r'<link href="\2" color="#166181"><u>\1</u></link>',text)
    text=re.sub(r'`([^`]+)`',r'<font name="ReportArial">\1</font>',text)
    text=re.sub(r'\*\*([^*]+)\*\*',r'<b>\1</b>',text)
    return text
story=[];lines=source.read_text(encoding='utf-8').splitlines();index=0
while index<len(lines):
    line=lines[index].strip()
    if not line:index+=1;continue
    if line.startswith('# '):
        story.append(Paragraph(inline(line[2:]),styles['title']));index+=1;continue
    if line.startswith('## '):
        title=line[3:]
        if title=='Throughput trials before longer training':
            picture=HERE/'analysis/phase2_results.png'
            story.extend([Spacer(1,8),Image(str(picture),width=511,height=511*4/11),Spacer(1,7),
                Paragraph('Figure 1. Validation learning curves and fixed-endpoint heldout perplexity. Shading shows sample SD across three seeds.',styles['table'])])
        story.append(Paragraph(inline(title),styles['heading']));index+=1;continue
    if line.startswith('|'):
        rows=[]
        while index<len(lines) and lines[index].strip().startswith('|'):
            values=[s.strip() for s in lines[index].strip().strip('|').split('|')]
            if not all(re.fullmatch(r'[-: ]+',v or '-') for v in values):rows.append(values)
            index+=1
        n=len(rows[0]);widths={8:[38,58,66,62,68,77,68,68],5:[64,111,111,116,109],4:[220,100,110,81]}.get(n,[511/n]*n)
        # Keep table width exactly inside the content frame.
        widths=[v*511/sum(widths) for v in widths]
        cells=[[Paragraph(inline(v),styles['tablehead'] if r==0 else styles['table']) for v in row] for r,row in enumerate(rows)]
        table=Table(cells,colWidths=widths,repeatRows=1,hAlign='LEFT')
        table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#123f53')),('VALIGN',(0,0),(-1,-1),'TOP'),
            ('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6),
            ('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.HexColor('#eef4f7'),colors.white]),('LINEBELOW',(0,-1),(-1,-1),.5,colors.HexColor('#c7d7df'))]))
        story.extend([table,Spacer(1,10)]);continue
    paragraph=[]
    if line.startswith('- '):
        story.append(Paragraph('- '+inline(line[2:]),styles['body']));index+=1;continue
    while index<len(lines) and lines[index].strip() and not lines[index].startswith(('#','|','- ')):
        paragraph.append(lines[index].strip());index+=1
    paragraph_text=' '.join(paragraph)
    style=ParagraphStyle('TableLead',parent=styles['body'],keepWithNext=True) if paragraph_text.startswith('Mean ±') else styles['body']
    story.append(Paragraph(inline(paragraph_text),style))
story.extend([Paragraph('Source links',styles['heading'])])
for label,url in [
    ('Kimi K3 report: Block Attention Residuals','https://arxiv.org/html/2607.24653v2#S2.SS2'),
    ('MiniMind upstream repository','https://github.com/jingyaogong/minimind'),
    ('TinyStories dataset and license','https://huggingface.co/datasets/roneneldan/TinyStories'),
    ('PyTorch compilation documentation','https://docs.pytorch.org/docs/2.11/generated/torch.compile.html'),
    ('Google Colab usage limits','https://research.google.com/colaboratory/faq.html')]:
    story.append(Paragraph(f'<b>{escape(label)}</b><br/><link href="{escape(url)}" color="#166181">{escape(url)}</link>',styles['body']))
def decorate(canvas,doc):
    canvas.saveState();canvas.setStrokeColor(colors.HexColor('#c7d7df'));canvas.setLineWidth(.5)
    canvas.line(42,806,553,806);canvas.setFont('ReportArial',8);canvas.setFillColor(colors.HexColor('#526875'))
    canvas.drawString(42,816,'MINI-K3  |  PRECISION-CONTROLLED STUDY')
    canvas.drawString(42,25,'Fazal Hameed  |  18 October 2026')
    canvas.drawRightString(553,25,str(doc.page));canvas.restoreState()
doc=SimpleDocTemplate(str(output),pagesize=A4,leftMargin=42,rightMargin=42,topMargin=49,bottomMargin=44,
    title='mini-k3: precision-controlled training and speed optimization',author='Fazal Hameed')
doc.build(story,onFirstPage=decorate,onLaterPages=decorate)
print(output)
