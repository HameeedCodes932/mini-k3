"""Training-only wrappers and a cached-RMS implementation of Block AttnRes.

Original phase-one files remain unchanged. No KV-cache generation is implemented.
"""
import torch
from torch import nn
import torch.nn.functional as F
from experiment import build_model


class TrainingLM(nn.Module):
    def __init__(self, original, mode):
        super().__init__()
        self.backbone = original.model
        self.lm_head = original.lm_head
        self.mode = mode
        if mode not in ('upstream', 'fp32', 'attnres_reference', 'attnres_cached'):
            raise ValueError(mode)

    @staticmethod
    def inverse_rms(values, eps):
        return torch.rsqrt(values.square().mean(-1, keepdim=True) + eps)

    @staticmethod
    def mix_cached(mixer, completed, inverse, partial):
        if completed.shape[0] == 1 and partial is None:
            # A softmax with one source is exactly one. These query/norm
            # parameters are mathematically inactive and may have grad=None.
            return completed[0]
        effective_query = mixer.query.float() * mixer.key_norm.weight.float()
        scores = (completed * effective_query).sum(-1) * inverse.squeeze(-1)
        if partial is not None:
            p = partial.float()
            inv_p = TrainingLM.inverse_rms(p, mixer.key_norm.eps)
            p_score = (p * effective_query).sum(-1) * inv_p.squeeze(-1)
            weights = torch.cat((scores, p_score.unsqueeze(0)), dim=0).softmax(0)
            return (completed * weights[:-1].unsqueeze(-1)).sum(0) + p * weights[-1].unsqueeze(-1)
        weights = scores.softmax(0)
        return (completed * weights.unsqueeze(-1)).sum(0)

    def forward(self, x):
        body = self.backbone
        if self.mode == 'attnres_reference':
            hidden, _, _ = body(x, use_cache=False)
            return self.lm_head(hidden)
        embedding = body.dropout(body.embed_tokens(x))
        positions = (body.freqs_cos[:x.shape[1]], body.freqs_sin[:x.shape[1]])
        if self.mode in ('upstream', 'fp32'):
            hidden = embedding
            for layer in body.layers:
                delta, _ = layer.self_attn(layer.input_layernorm(hidden), positions, use_cache=False)
                if self.mode == 'upstream':
                    # Preserve upstream's in-place destination dtype exactly.
                    hidden = delta.add_(hidden)
                else:
                    hidden = hidden + delta.float()
                delta = layer.mlp(layer.post_attention_layernorm(hidden))
                hidden = hidden + (delta.float() if self.mode == 'fp32' else delta)
            return self.lm_head(body.norm(hidden))
        completed = embedding.unsqueeze(0).float()
        inverse = self.inverse_rms(completed, body.config.rms_norm_eps)
        partial, index = None, 0
        for layer in body.layers:
            for is_attention in (True, False):
                hidden = self.mix_cached(body.depth_mixers[index], completed, inverse, partial)
                if is_attention:
                    delta, _ = layer.self_attn(layer.input_layernorm(hidden), positions, use_cache=False)
                else:
                    delta = layer.mlp(layer.post_attention_layernorm(hidden))
                # Match phase-one partial-sum precision; do not silently make
                # this a different architecture/precision experiment.
                partial = delta if partial is None else partial + delta
                index += 1
                if index % body.block_sublayers == 0:
                    value = partial.float().unsqueeze(0)
                    completed = torch.cat((completed, value), dim=0)
                    inverse = torch.cat((inverse, self.inverse_rms(value, body.config.rms_norm_eps)), dim=0)
                    partial = None
        hidden = self.mix_cached(body.depth_mixers[index], completed, inverse, partial)
        return self.lm_head(body.norm(hidden))


class TrainingLoss(nn.Module):
    def __init__(self, model):
        super().__init__()
        self.model = model

    def forward(self, x, y):
        logits = self.model(x)
        return F.cross_entropy(logits.float().reshape(-1, logits.shape[-1]), y.reshape(-1))


def create_model(mode, size='pilot', seq=128, seed=42, block_sublayers=4):
    variant = 'attnres' if mode.startswith('attnres') else 'baseline'
    original = build_model(size, seq, variant, seed, block_sublayers)
    return TrainingLM(original, mode)
