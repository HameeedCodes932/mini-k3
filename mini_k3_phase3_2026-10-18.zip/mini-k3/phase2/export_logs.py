"""Export small measured artifacts through visible Colab output, with integrity checks."""
import base64
import hashlib
import io
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parent.parent
buffer=io.BytesIO()
with zipfile.ZipFile(buffer,'w',compression=zipfile.ZIP_DEFLATED) as archive:
    for path in sorted((ROOT/'phase2').rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts or path.name.endswith('_trace.json'):
            continue
        if path.suffix in ('.json','.csv','.md') or path.name=='test_controlled_unscaled.py':
            archive.write(path,path.relative_to(ROOT))
    for name in ('drive_backup_final.json','drive_backup_verification.json'):
        if (ROOT/name).exists():archive.write(ROOT/name,name)
blob=buffer.getvalue()
encoded=base64.b64encode(blob).decode('ascii')
chunks=[encoded[i:i+6000] for i in range(0,len(encoded),6000)]
print('P2LOG_SIZE:'+str(len(blob)))
print('P2LOG_SHA256:'+hashlib.sha256(blob).hexdigest())
print('P2LOG_CHUNK_COUNT:'+str(len(chunks)))
for index,chunk in enumerate(chunks):print(f'P2LOG_CHUNK_{index}:'+chunk)
