# mini-k3: precision-controlled training and speed optimization

Date: 18 October 2026. Author: Fazal Hameed.

## Main findings

Three matched seeds completed 1,000 updates per architecture (4,096,000 predicted training tokens each). The mean paired change in heldout perplexity was a 6.16% reduction; the mean paired training-throughput change was -17.74%. These are measurements on a reduced dense MiniMind and one simple English dataset, not evidence of general reasoning or assistant quality.

Both architectures receive the same optimized training engine. A speedup over the original unoptimized implementation does not establish a speedup over an equally optimized baseline. The raw-throughput and quality results must be read together.

The modified model is still slower than the equally optimized baseline. The complete faster-and-stronger objective has not yet been met on this comparison.

## Research scope and implemented changes

The project adapts Block Attention Residuals from [Kimi K3, section 2.2, equations 8–10](https://arxiv.org/html/2607.24653v2#S2.SS2). It retains MiniMind grouped-query causal attention, rotary positions, RMSNorm and its dense feed-forward network. Each attention/MLP is a sublayer. Four sublayers form a block. A learned query scores RMS-normalized depth sources; a softmax weights the embedding, completed block sums and current partial sum. A final depth mixer aggregates all completed blocks. No KDA, Stable LatentMoE, SiTU-GLU or Muon optimizer is implemented. No KV cache or decoding-speed claim is included.

The original implementation repeatedly stacked and normalized old block outputs. The new implementation retains a stack of completed block sums and reuses their inverse RMS values. Query and learned RMS weights combine algebraically in each score. This retains gradients through the cached tensors; it is not detached activation caching. The singleton-source mixer returns that source directly; its mathematically inactive query/norm parameters may have no gradient rather than an explicit zero.

The training path merges four batches of eight into one physical batch of 32, uses fused AdamW, and compiles the loss with `torch.compile(fullgraph=True, dynamic=False, mode="default")` when both architectures pass the fixed speed rule. Compilation is selected only if both controlled scaled-gradient checks pass, both benchmark candidates complete, and each is at least 5% faster than its eager candidate. The old meta-device rotary-position guard is omitted in this training-only wrapper because all model tensors are materialized.

## Precision issue found in the first pilot

The upstream attention residual uses an in-place addition whose FP16 destination rounds the running state under autocast. The first AttnRes implementation promoted depth mixing to FP32 because its sources included the FP32 embedding, but its partial block sums could still accumulate in FP16. Thus phase one had a precision difference as well as an architectural difference. Its reported 23.9% perplexity reduction is a valid measurement of those implementations, but cannot be attributed solely to AttnRes.

This phase explicitly casts each attention/MLP output to FP32 before residual or partial-block accumulation in both architectures. Model parameters and all residual/depth states remain FP32; linear operations use FP16 autocast. Both models are retrained from the same shared initialization for each seed. The longer learning-rate schedule also differs from phase one, so cross-phase quality differences do not isolate the numerical-precision effect. Historical phase-one source and results remain unchanged.

## Training and evaluation setup

- Free Tesla T4, 14.56 GiB; Python 3.13.15; PyTorch 2.11.0+cu130; Transformers 4.57.6.
- MiniMind pinned commit `f659b55761b754d306bd140573493a6543cafd7f`, Apache-2.0; license retained.
- Hidden width 384; six transformer layers; six query/two KV heads; vocabulary 6,400; input length 128.
- Baseline: 13,227,648 parameters. AttnRes: 13,237,632 parameters. Original MiniMind tokenizer.
- Seeds 42, 17, 123; baseline first at 42, AttnRes first at 17/123. Shared weights match exactly before training.
- 1,000 updates from scratch per run, physical/logical batch 32, 4,096 predicted tokens per update.
- AdamW fused; peak LR 3e-4; 50-step warmup and cosine decay toward 10% of peak; betas (0.9, 0.95); weight decay 0.1.
- FP16 linear autocast with FP32 accumulation; gradient scaling initially 1,024; gradient norm clipping at 1.0.
- Nonfinite loss/gradients stop a run rather than silently skipping updates. Same seed/step-dependent batches for both models.
- Training cache: 2,000,000 tokens. Blocks sampled with replacement; not a unique-token count or multiple full epochs.
- Validation: fixed 32,768 predicted tokens at step 0 and every 100 updates. Endpoint fixed at 1,000 updates.
- New heldout partition: 472 accepted stories, 128,000 cached tokens; 126,976 predicted tokens in full packed blocks, evaluated only at the fixed endpoint.

Data uses [TinyStories](https://huggingface.co/datasets/roneneldan/TinyStories), pinned revision `f54c09fd23315a6f9c86f9dc80f725de7d8f9c64`, CDLA-Sharing-1.0. EOS is inserted between stories. Train and original validation token caches are reconstructed and checked for exact equality before creating the new partition. The holdout starts after the last complete story contributing to the original validation prefix. Exact text hashes exclude selected train stories, original validation stories and repeated holdout stories. This is an extra partition of the official validation split, not an official test split or an independent domain. Near-duplicate/paraphrase removal was not performed. The holdout was not used to tune the learning rate, architecture, budget or engine.

Evaluation reports mean next-token negative log-likelihood in nats per predicted token and perplexity exp(NLL). Packed blocks can cross story boundaries and do not mask attention at EOS. The same packing and causal mask apply to both models.

## Per-seed measured results

| Seed | Model | Validation NLL | Heldout NLL | Heldout perplexity | Training tokens/s | First step, s | Full run, s |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 17 | baseline | 2.0093 | 2.2278 | 9.279 | 122063 | 0.03 | 44.34 |
| 17 | attnres | 1.9418 | 2.1689 | 8.749 | 101879 | 0.04 | 52.77 |
| 42 | baseline | 2.0127 | 2.2274 | 9.276 | 137709 | 4.53 | 45.67 |
| 42 | attnres | 1.9429 | 2.1611 | 8.680 | 109416 | 30.26 | 79.69 |
| 123 | baseline | 2.0116 | 2.2307 | 9.306 | 120919 | 0.04 | 45.00 |
| 123 | attnres | 1.9436 | 2.1651 | 8.716 | 101413 | 0.04 | 52.37 |

Mean ± sample standard deviation across three seeds:

| Model | Heldout NLL | Heldout perplexity | Training tokens/s | Peak GPU MiB |
| --- | ---: | ---: | ---: | ---: |
| baseline | 2.2286 ± 0.0018 | 9.287 ± 0.017 | 126897 ± 9381 | 636.6 ± 1.0 |
| attnres | 2.1650 ± 0.0039 | 8.715 ± 0.034 | 104236 ± 4492 | 742.8 ± 1.9 |

## Throughput trials before longer training

Each isolated trial used eight warmup and 60 measured updates at a logical batch of 32. Trials started from scratch and are performance experiments, not heldout-quality results. The cached AttnRes benchmark preserves phase-one FP16 partial-block accumulation; the subsequent controlled trainer uses FP32 for those sums. Its actual training speeds are therefore reported separately above.

| Candidate | Median tokens/s | First step including compilation, s | Peak GPU MiB |
| --- | ---: | ---: | ---: |
| original_baseline_8x4 | 35184 | 0.54 | 481.9 |
| original_attnres_8x4 | 25306 | 0.54 | 662.8 |
| fp32_baseline_eager_32 | 69844 | 0.49 | 1152.9 |
| cached_attnres_eager_32 | 48192 | 0.47 | 1277.7 |
| fp32_baseline_compiled_32 | 140110 | 30.49 | 638.5 |
| cached_attnres_compiled_32 | 118536 | 50.83 | 717.4 |

Timing uses synchronized complete optimizer updates, including batch construction/transfer, forward/backward, gradient scaling, clipping and optimizer work. Steady throughput is the median of per-step tokens/s after the first eight steps. It excludes validation, compilation setup, checkpoint writes, Drive backup and data/dependency setup. The first-step measurement includes any compilation on that invocation; later runs can reuse compiler caches, so it is not a guaranteed cold-cache compilation cost for every seed. Full-run wall time includes model setup, compilation, evaluation and periodic checkpoint/Drive backup IO, but excludes data preparation, imports, and final result-metadata backup. GPU memory is PyTorch peak allocated memory during each uninterrupted run, not reserved memory or full-device use.

The benchmark loop also reduces per-microbatch Python checks relative to the historical pilot. Consequently its eager original timings differ from phase-one timings; one must not attribute the entire cross-phase throughput gain to depth-mixing optimization. Free shared hardware, compiler-cache reuse, single-session timing and limited execution-order reversal restrict performance claims.

## Verification, artifacts and reproducibility

Four optimized-wrapper checks passed in Colab: original-path equality, cached/reference logits and gradients (including nonzero learned queries and multiple block sizes), causal outputs, and CUDA FP16 equivalence. The controlled-model checks verify exact shared initialization, FP32 reference outputs/gradients and causality, and FP32 states entering every layer normalization under CUDA FP16 autocast. Compiled and eager losses and gradients were compared at the real batch/context shape for both controlled architectures, using loss scaling of 1,024 before backward and unscaling gradients afterward, as in training. Tolerances and maximum observed errors are saved in `controlled_compilation_checks.json`; tests are not quality results.

An earlier unscaled FP16 backward comparison failed the gradient tolerance despite nearly identical losses. Diagnostics were retained under `unscaled_*` in `phase2/results/`. Repeating the test with the trainer’s loss scaling greatly reduced differences and both models passed the same tolerance. This is consistent with FP16 small-gradient underflow/rounding in the unscaled computation; it does not establish bitwise equivalence or prove compiler correctness for every trained state. No tolerance was loosened to obtain the scaled result.

Every run stores its configuration, source/data hashes, per-step timings, validation history, endpoint result and a resumable checkpoint containing model, optimizer, scaler, RNG state and step. Runtime checkpoints are saved every 100 updates; verified Drive copies are made at 500 and 1,000 updates and after completion. Changing the source/configuration/data/environment requires a new run directory. The original phase-one trainer also passed interrupted-resume equality tests; the phase-two runner reuses the same checkpoint-state pattern but has not undergone a full GPU interrupted/resumed trajectory equivalence test.

User-authorized Drive destination: `My Drive/mini-k3/2026-10-18`. Each copied file is verified by SHA-256. Phase-one and phase-two model bytes live there; the local research bundle contains code, logs, manifests and reports, and does not pretend to contain model checkpoint bytes. A complete backup manifest records sizes and checksums.

## Interpretation and remaining work

This study measures early domain language modeling on a 13.2M-parameter model. Three seeds quantify initialization/sampling variability on a fixed corpus, not statistical confidence across tasks or domains. The unchanged hyperparameters may favor one architecture; no learning-rate sweep was conducted. A longer or full-size MiniMind study, independent-domain evaluation, downstream tasks, cached inference and wall-clock-budget comparisons remain. Results should be described with these limits; a professor’s acceptance decision is independent of completing this experiment.


