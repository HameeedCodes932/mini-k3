"""Isolated bounded trials: no quality claims from these throughput measurements."""
import argparse
import gc
import json
from pathlib import Path
import statistics
import subprocess
import sys
import time
import torch
from torch import nn
from experiment import build_model, environment, token_blocks, training_batch
from optimized import create_model, TrainingLoss

ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'phase2/results'
OUT.mkdir(exist_ok=True,parents=True)
CONFIGS=[
    {'name':'original_baseline_8x4','mode':'baseline_original','physical_batch':8,'compile':False,'fused':False},
    {'name':'original_attnres_8x4','mode':'attnres_original','physical_batch':8,'compile':False,'fused':False},
    {'name':'fp32_baseline_eager_32','mode':'fp32','physical_batch':32,'compile':False,'fused':True},
    {'name':'cached_attnres_eager_32','mode':'attnres_cached','physical_batch':32,'compile':False,'fused':True},
    {'name':'fp32_baseline_compiled_32','mode':'fp32','physical_batch':32,'compile':True,'fused':True},
    {'name':'cached_attnres_compiled_32','mode':'attnres_cached','physical_batch':32,'compile':True,'fused':True}]

class OriginalLogits(nn.Module):
    def __init__(self,model):
        super().__init__(); self.original=model
    def forward(self,x):
        return self.original(x,use_cache=False).logits

def logical_batch(blocks,seed,step,device='cuda'):
    # Same four logical groups of eight as phase one, merged before transfer.
    parts=[training_batch(blocks,seed,step,m,8,'cpu') for m in range(4)]
    return tuple(torch.cat([p[k] for p in parts],0).to(device) for k in (0,1))

def trial(config):
    assert torch.cuda.is_available()
    torch.set_num_threads(4)
    torch.backends.cuda.matmul.allow_tf32=False
    torch.backends.cudnn.allow_tf32=False
    torch.cuda.reset_peak_memory_stats()
    if config['mode'].endswith('_original'):
        variant='baseline' if config['mode'].startswith('baseline') else 'attnres'
        model=OriginalLogits(build_model('pilot',128,variant,42)).cuda()
    else:
        model=create_model(config['mode']).cuda()
    objective=TrainingLoss(model)
    if config['compile']:
        objective=torch.compile(objective,fullgraph=True,dynamic=False,mode='default')
    optimizer=torch.optim.AdamW(model.parameters(),lr=1e-4,betas=(.9,.95),weight_decay=.1,fused=config['fused'])
    scaler=torch.amp.GradScaler('cuda',init_scale=1024)
    data=token_blocks(ROOT/'data/train.npy',128)
    timings=[]
    first_step=None
    for index in range(68):
        optimizer.zero_grad(set_to_none=True)
        torch.cuda.synchronize(); start=time.perf_counter()
        x,y=logical_batch(data,42,index)
        for lo in range(0,32,config['physical_batch']):
            hi=lo+config['physical_batch']
            with torch.autocast('cuda',dtype=torch.float16):
                loss=objective(x[lo:hi],y[lo:hi]) * (config['physical_batch']/32)
            scaler.scale(loss).backward()
        scaler.unscale_(optimizer)
        norm=torch.nn.utils.clip_grad_norm_(model.parameters(),1.,error_if_nonfinite=True)
        scaler.step(optimizer); scaler.update()
        torch.cuda.synchronize(); elapsed=time.perf_counter()-start
        if index==0:
            first_step=elapsed
            print('FIRST_STEP',config['name'],round(elapsed,3),flush=True)
        if index>=8:
            timings.append(elapsed)
    row={'config':config,'environment':environment('cuda'),
         'first_step_seconds_including_cold_compile':first_step,
         'warmup_steps':8,'measured_steps':60,'logical_batch':32,'sequence':128,
         'median_training_tokens_per_second':4096/statistics.median(timings),
         'p10_step_seconds':sorted(timings)[6], 'p90_step_seconds':sorted(timings)[53],
         'peak_allocated_gpu_bytes':torch.cuda.max_memory_allocated(),
         'step_seconds':timings,'status':'ok'}
    (OUT/f"benchmark_{config['name']}.json").write_text(json.dumps(row,indent=2))
    print('BENCHMARK',json.dumps({k:v for k,v in row.items() if k!='step_seconds'}),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--trial',type=int)
    args=parser.parse_args()
    if args.trial is not None:
        trial(CONFIGS[args.trial])
    else:
        rows=[]
        for index,config in enumerate(CONFIGS):
            print('START_TRIAL',config['name'],flush=True)
            try:
                done=subprocess.run([sys.executable,__file__,'--trial',str(index)],timeout=240)
                path=OUT/f"benchmark_{config['name']}.json"
                if done.returncode==0 and path.exists():
                    rows.append(json.loads(path.read_text()))
                else:
                    rows.append({'config':config,'status':'failed','returncode':done.returncode})
            except subprocess.TimeoutExpired:
                rows.append({'config':config,'status':'timeout_240_seconds'})
            (OUT/'benchmark_summary.json').write_text(json.dumps(rows,indent=2))
        print('BENCHMARKS_COMPLETE',flush=True)
