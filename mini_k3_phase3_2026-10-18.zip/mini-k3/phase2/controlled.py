"""Both comparison models use FP32 residual states, including AttnRes block sums."""
import torch
from optimized import TrainingLM
from experiment import build_model


class ControlledLM(TrainingLM):
    def __init__(self,original,architecture):
        super().__init__(original, 'fp32' if architecture=='baseline' else 'attnres_cached')
        self.architecture=architecture

    def forward(self,x):
        if self.architecture=='baseline':
            return super().forward(x)
        body=self.backbone
        embedding=body.dropout(body.embed_tokens(x)).float()
        positions=(body.freqs_cos[:x.shape[1]],body.freqs_sin[:x.shape[1]])
        completed=embedding.unsqueeze(0)
        inverse=self.inverse_rms(completed,body.config.rms_norm_eps)
        partial,index=None,0
        for layer in body.layers:
            for is_attention in (True,False):
                hidden=self.mix_cached(body.depth_mixers[index],completed,inverse,partial)
                if is_attention:
                    delta,_=layer.self_attn(layer.input_layernorm(hidden),positions,use_cache=False)
                else:
                    delta=layer.mlp(layer.post_attention_layernorm(hidden))
                delta=delta.float()
                partial=delta if partial is None else partial+delta
                index+=1
                if index%body.block_sublayers==0:
                    value=partial.unsqueeze(0)
                    completed=torch.cat((completed,value),0)
                    inverse=torch.cat((inverse,self.inverse_rms(value,body.config.rms_norm_eps)),0)
                    partial=None
        hidden=self.mix_cached(body.depth_mixers[index],completed,inverse,partial)
        return self.lm_head(body.norm(hidden))


def controlled_model(architecture,seed=42):
    original=build_model('pilot',128,architecture,seed,4)
    return ControlledLM(original,architecture)
