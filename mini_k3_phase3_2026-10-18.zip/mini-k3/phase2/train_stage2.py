"""Longer, precision-controlled training; heldout scores only at the fixed endpoint."""
import gc
import hashlib
import json
import math
import os
from pathlib import Path
import statistics
import time
import torch
from experiment import dump_json,digest,environment,token_blocks
from benchmark_stage2 import logical_batch
from optimized import TrainingLoss
from controlled import controlled_model
from backup import backup_tree

ROOT=Path(__file__).resolve().parent.parent
HERE=ROOT/'phase2'
OUT=HERE/'runs/controlled1000'
OUT.mkdir(parents=True,exist_ok=True)
BACKUP=Path(os.environ['MINIK3_DRIVE_BACKUP']) if os.environ.get('MINIK3_DRIVE_BACKUP') else None
assert torch.cuda.is_available()
torch.set_num_threads(4)
torch.backends.cuda.matmul.allow_tf32=False
torch.backends.cudnn.allow_tf32=False
bench=json.loads((HERE/'results/benchmark_summary.json').read_text())
by_name={r['config']['name']:r for r in bench}
compiled_names=('fp32_baseline_compiled_32','cached_attnres_compiled_32')
compile_checks=json.loads((HERE/'results/controlled_compilation_checks.json').read_text())
use_compile=len(compile_checks)==2 and all(r['status']=='passed' for r in compile_checks)
use_compile=use_compile and all(by_name.get(name,{}).get('status')=='ok' for name in compiled_names)
if use_compile:
    use_compile=all(by_name[c]['median_training_tokens_per_second'] > 1.05*by_name[e]['median_training_tokens_per_second']
        for c,e in zip(compiled_names,('fp32_baseline_eager_32','cached_attnres_eager_32')))
print('SELECTED_ENGINE', 'inductor' if use_compile else 'eager',flush=True)
data=token_blocks(ROOT/'data/train.npy',128)
validation=token_blocks(ROOT/'data/validation.npy',128)[:256]
holdout=token_blocks(HERE/'data/holdout.npy',128)
source_hashes={name:digest(HERE/name) for name in ['optimized.py','controlled.py','train_stage2.py','benchmark_stage2.py','backup.py','prepare_holdout.py','../experiment.py','../attnres.py']}

@torch.no_grad()
def evaluate(model,blocks):
    model.eval(); total,tokens=0.,0
    loss_fn=TrainingLoss(model)
    for lo in range(0,len(blocks),32):
        pack=blocks[lo:lo+32].cuda()
        with torch.autocast('cuda',dtype=torch.float16):
            loss=loss_fn(pack[:,:-1],pack[:,1:])
        count=pack.shape[0]*128
        total+=loss.item()*count; tokens+=count
    model.train()
    return {'nll':total/tokens,'perplexity':math.exp(total/tokens),'tokens':tokens}


def train(architecture,seed):
    start_wall=time.perf_counter()
    folder=OUT/f'{architecture}_seed{seed}'
    folder.mkdir(exist_ok=True)
    spec={'architecture':architecture,'seed':seed,'steps':1000,'sequence':128,
        'physical_batch':32,'logical_batch':32,'lr':3e-4,'optimizer':'AdamW fused',
        'betas':[.9,.95],'weight_decay':.1,'gradient_clip':1.,'residual_dtype':'float32',
        'linear_autocast':'float16','engine':'inductor' if use_compile else 'eager',
        'source_hashes':source_hashes,'data_manifest_sha256':digest(ROOT/'data/data_manifest.json'),
        'compilation_checks_sha256':digest(HERE/'results/controlled_compilation_checks.json'),
        'holdout_manifest_sha256':digest(HERE/'data/holdout_manifest.json'),
        'environment':environment('cuda')}
    if (folder/'config.json').exists():
        assert json.loads((folder/'config.json').read_text())==spec,'Use a new run directory after changing settings or source.'
    dump_json(folder/'config.json',spec)
    if (folder/'result.json').exists():
        print('ALREADY_COMPLETE',architecture,seed,flush=True)
        return json.loads((folder/'result.json').read_text())
    model=controlled_model(architecture,seed).cuda().train()
    objective=TrainingLoss(model)
    optimizer=torch.optim.AdamW(model.parameters(),lr=3e-4,betas=(.9,.95),weight_decay=.1,fused=True)
    scaler=torch.amp.GradScaler('cuda',init_scale=1024)
    history,timing,start=[],[],0
    checkpoint=folder/'latest.pt'
    if checkpoint.exists():
        saved=torch.load(checkpoint,map_location='cpu',weights_only=True)
        assert saved['spec']==spec
        model.load_state_dict(saved['model']);optimizer.load_state_dict(saved['optimizer'])
        scaler.load_state_dict(saved['scaler']);history=saved['history'];timing=saved['timing'];start=saved['step']
        torch.set_rng_state(saved['cpu_rng']);torch.cuda.set_rng_state_all(saved['cuda_rng'])
        print('RESUME',architecture,seed,start,flush=True)
    else:
        history.append({'step':0,'validation':evaluate(model,validation)})
    if use_compile:
        objective=torch.compile(objective,fullgraph=True,dynamic=False,mode='default')
    torch.cuda.reset_peak_memory_stats()
    def save(step):
        state={'spec':spec,'step':step,'model':model.state_dict(),'optimizer':optimizer.state_dict(),
            'scaler':scaler.state_dict(),'history':history,'timing':timing,
            'cpu_rng':torch.get_rng_state(),'cuda_rng':torch.cuda.get_rng_state_all()}
        temporary=checkpoint.with_suffix('.pt.tmp')
        torch.save(state,temporary);os.replace(temporary,checkpoint)
        dump_json(folder/'history.json',history);dump_json(folder/'timing.json',timing)
        if BACKUP and step%500==0:
            backup_tree(folder,BACKUP/folder.relative_to(ROOT))
    for step in range(start,1000):
        lr=3e-4*min(1.,(step+1)/50)*(.1+.9*(1+math.cos(math.pi*max(0,step-50)/950))/2)
        for group in optimizer.param_groups:group['lr']=lr
        optimizer.zero_grad(set_to_none=True)
        torch.cuda.synchronize();began=time.perf_counter()
        x,y=logical_batch(data,seed,step)
        with torch.autocast('cuda',dtype=torch.float16):loss=objective(x,y)
        scaler.scale(loss).backward();scaler.unscale_(optimizer)
        norm=torch.nn.utils.clip_grad_norm_(model.parameters(),1.,error_if_nonfinite=True)
        if not torch.isfinite(loss):raise FloatingPointError('Nonfinite loss')
        scaler.step(optimizer);scaler.update()
        torch.cuda.synchronize();elapsed=time.perf_counter()-began
        timing.append({'step':step+1,'seconds':elapsed,'tokens':4096})
        if (step+1)%100==0 or step==start:
            print('TRAIN',architecture,seed,step+1,'nll',round(loss.item(),4),'tokens/s',round(4096/elapsed),flush=True)
        if (step+1)%100==0:
            row={'step':step+1,'validation':evaluate(model,validation)}
            history.append(row);print('VALIDATION',architecture,seed,json.dumps(row),flush=True)
            save(step+1)
    # Endpoint-only evaluation: no hyperparameter selection against this score.
    heldout=evaluate(model,holdout)
    measured=[r for r in timing if r['step']>8]
    result={'architecture':architecture,'seed':seed,'steps':1000,'training_tokens':4_096_000,
        'parameters':sum(p.numel() for p in model.parameters()),
        'validation':history[-1]['validation'],'heldout':heldout,
        'median_training_tokens_per_second':statistics.median(4096/r['seconds'] for r in measured),
        'first_step_seconds_including_cold_compile':timing[0]['seconds'],
        'training_step_seconds':sum(r['seconds'] for r in timing),
        'run_wall_seconds_including_compile_eval_checkpoint_io':time.perf_counter()-start_wall,
        'peak_allocated_gpu_bytes_this_session':torch.cuda.max_memory_allocated(),
        'resume_step_this_session':start,'engine':spec['engine'],'environment':spec['environment']}
    dump_json(folder/'result.json',result)
    if BACKUP:
        backup_tree(folder,BACKUP/folder.relative_to(ROOT))
    print('CONTROLLED_RESULT',json.dumps(result),flush=True)
    del model,objective,optimizer,scaler
    gc.collect();torch.cuda.empty_cache()
    return result

results=[]
for seed in (42,17,123):
    order=('baseline','attnres') if seed==42 else ('attnres','baseline')
    for architecture in order:
        results.append(train(architecture,seed))
        dump_json(OUT/'results.json',results)
print('CONTROLLED_STAGE_COMPLETE',flush=True)
