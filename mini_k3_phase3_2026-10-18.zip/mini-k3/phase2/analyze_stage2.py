"""Summarize measured phase-two artifacts without substituting missing runs."""
import csv
import hashlib
import json
from pathlib import Path
import statistics as stats

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
OUT=HERE/'analysis'
OUT.mkdir(exist_ok=True)
runs=HERE/'runs/controlled1000'
results=[];configs=[];histories=[]
for seed in (17,42,123):
    for architecture in ('baseline','attnres'):
        folder=runs/f'{architecture}_seed{seed}'
        row=json.loads((folder/'result.json').read_text())
        config=json.loads((folder/'config.json').read_text())
        assert row['steps']==1000 and row['training_tokens']==4_096_000
        assert row['architecture']==architecture and row['seed']==seed
        assert config['residual_dtype']=='float32'
        results.append(row);configs.append(config)
        for point in json.loads((folder/'history.json').read_text()):
            histories.append({'architecture':architecture,'seed':seed,'step':point['step'],**point['validation']})
assert len({json.dumps(c['source_hashes'],sort_keys=True) for c in configs})==1
assert len({c['data_manifest_sha256'] for c in configs})==1
assert len({c['holdout_manifest_sha256'] for c in configs})==1
for name,expected in configs[0]['source_hashes'].items():
    assert hashlib.sha256((HERE/name).read_bytes()).hexdigest()==expected,name
assert len({r['engine'] for r in results})==1
assert len({json.dumps(r['environment'],sort_keys=True) for r in results})==1
summary={}
for architecture in ('baseline','attnres'):
    group=[r for r in results if r['architecture']==architecture]
    fields={
        'validation_nll':[r['validation']['nll'] for r in group],
        'validation_perplexity':[r['validation']['perplexity'] for r in group],
        'heldout_nll':[r['heldout']['nll'] for r in group],
        'heldout_perplexity':[r['heldout']['perplexity'] for r in group],
        'training_tokens_per_second':[r['median_training_tokens_per_second'] for r in group],
        'first_step_seconds':[r['first_step_seconds_including_cold_compile'] for r in group],
        'run_wall_seconds':[r['run_wall_seconds_including_compile_eval_checkpoint_io'] for r in group],
        'peak_gpu_mib':[r['peak_allocated_gpu_bytes_this_session']/2**20 for r in group]}
    summary[architecture]={'parameters':group[0]['parameters'],
        **{key:{'mean':stats.mean(values),'sample_sd':stats.stdev(values)} for key,values in fields.items()}}
by_key={(r['architecture'],r['seed']):r for r in results}
paired=[]
for seed in (17,42,123):
    a,b=by_key['baseline',seed],by_key['attnres',seed]
    paired.append({'seed':seed,
        'heldout_nll_difference_attnres_minus_baseline':b['heldout']['nll']-a['heldout']['nll'],
        'heldout_perplexity_reduction_percent':100*(1-b['heldout']['perplexity']/a['heldout']['perplexity']),
        'validation_perplexity_reduction_percent':100*(1-b['validation']['perplexity']/a['validation']['perplexity']),
        'throughput_change_percent':100*(b['median_training_tokens_per_second']/a['median_training_tokens_per_second']-1)})
bench=json.loads((HERE/'results/benchmark_summary.json').read_text())
holdout=json.loads((HERE/'data/holdout_manifest.json').read_text())
checks=json.loads((HERE/'results/controlled_compilation_checks.json').read_text())
bundle={'summary':summary,'paired':paired,'results':results,'configs':configs,
    'benchmark':bench,'holdout_manifest':holdout,'compilation_checks':checks}
(OUT/'phase2_results.json').write_text(json.dumps(bundle,indent=2),encoding='utf-8')
flat=[]
for r in results:
    flat.append({k:v for k,v in r.items() if k not in ('validation','heldout','environment')}|
        {f'{prefix}_{k}':v for prefix in ('validation','heldout') for k,v in r[prefix].items()})
for name,rows in [('results.csv',flat),('paired_comparisons.csv',paired),('learning_curves.csv',histories)]:
    with (OUT/name).open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)

gain=stats.mean(r['heldout_perplexity_reduction_percent'] for r in paired)
speed=stats.mean(r['throughput_change_percent'] for r in paired)
lines=['# mini-k3: precision-controlled training and speed optimization','',
    'Date: 18 October 2026. Author: Fazal Hameed.','',
    '## Main findings','',
    f'Three matched seeds completed 1,000 updates per architecture (4,096,000 predicted training tokens each). '
    f'The mean paired change in heldout perplexity was a {gain:.2f}% reduction; '
    f'the mean paired training-throughput change was {speed:+.2f}%. '
    'These are measurements on a reduced dense MiniMind and one simple English dataset, not evidence of general reasoning or assistant quality.','',
    'Both architectures receive the same optimized training engine. A speedup over the original unoptimized implementation '
    'does not establish a speedup over an equally optimized baseline. The raw-throughput and quality results must be read together.','',
    ('The modified model is still slower than the equally optimized baseline. The complete faster-and-stronger objective '
     'has not yet been met on this comparison.' if speed<0 else
     'The speed and quality claims apply only to this model, dataset, hardware and measured training path.'),'',
    '## Research scope and implemented changes','',
    'The project adapts Block Attention Residuals from [Kimi K3, section 2.2, equations 8–10]'
    '(https://arxiv.org/html/2607.24653v2#S2.SS2). It retains MiniMind grouped-query causal attention, rotary positions, '
    'RMSNorm and its dense feed-forward network. Each attention/MLP is a sublayer. Four sublayers form a block. '
    'A learned query scores RMS-normalized depth sources; a softmax weights the embedding, completed block sums and current partial sum. '
    'A final depth mixer aggregates all completed blocks. No KDA, Stable LatentMoE, SiTU-GLU or Muon optimizer is implemented. '
    'No KV cache or decoding-speed claim is included.','',
    'The original implementation repeatedly stacked and normalized old block outputs. The new implementation retains a stack '
    'of completed block sums and reuses their inverse RMS values. Query and learned RMS weights combine algebraically in each score. '
    'This retains gradients through the cached tensors; it is not detached activation caching. The singleton-source mixer returns '
    'that source directly; its mathematically inactive query/norm parameters may have no gradient rather than an explicit zero.','',
    'The training path merges four batches of eight into one physical batch of 32, uses fused AdamW, and compiles the loss '
    'with `torch.compile(fullgraph=True, dynamic=False, mode="default")` when both architectures pass the fixed speed rule. '
    'Compilation is selected only if both controlled scaled-gradient checks pass, both benchmark candidates complete, '
    'and each is at least 5% faster than its eager candidate. '
    'The old meta-device rotary-position guard is omitted in this training-only wrapper because all model tensors are materialized.','',
    '## Precision issue found in the first pilot','',
    'The upstream attention residual uses an in-place addition whose FP16 destination rounds the running state under autocast. '
    'The first AttnRes implementation promoted depth mixing to FP32 because its sources included the FP32 embedding, but its partial '
    'block sums could still accumulate in FP16. Thus phase one had a precision difference as well as an architectural difference. '
    'Its reported 23.9% perplexity reduction is a valid measurement of those implementations, but cannot be attributed solely to AttnRes.','',
    'This phase explicitly casts each attention/MLP output to FP32 before residual or partial-block accumulation in both architectures. '
    'Model parameters and all residual/depth states remain FP32; linear operations use FP16 autocast. Both models are retrained from '
    'the same shared initialization for each seed. The longer learning-rate schedule also differs from phase one, so cross-phase '
    'quality differences do not isolate the numerical-precision effect. Historical phase-one source and results remain unchanged.','',
    '## Training and evaluation setup','',
    '- Free Tesla T4, 14.56 GiB; Python 3.13.15; PyTorch 2.11.0+cu130; Transformers 4.57.6.',
    '- MiniMind pinned commit `f659b55761b754d306bd140573493a6543cafd7f`, Apache-2.0; license retained.',
    '- Hidden width 384; six transformer layers; six query/two KV heads; vocabulary 6,400; input length 128.',
    '- Baseline: 13,227,648 parameters. AttnRes: 13,237,632 parameters. Original MiniMind tokenizer.',
    '- Seeds 42, 17, 123; baseline first at 42, AttnRes first at 17/123. Shared weights match exactly before training.',
    '- 1,000 updates from scratch per run, physical/logical batch 32, 4,096 predicted tokens per update.',
    '- AdamW fused; peak LR 3e-4; 50-step warmup and cosine decay toward 10% of peak; betas (0.9, 0.95); weight decay 0.1.',
    '- FP16 linear autocast with FP32 accumulation; gradient scaling initially 1,024; gradient norm clipping at 1.0.',
    '- Nonfinite loss/gradients stop a run rather than silently skipping updates. Same seed/step-dependent batches for both models.',
    '- Training cache: 2,000,000 tokens. Blocks sampled with replacement; not a unique-token count or multiple full epochs.',
    '- Validation: fixed 32,768 predicted tokens at step 0 and every 100 updates. Endpoint fixed at 1,000 updates.',
    f"- New heldout partition: {holdout['holdout_stories']} accepted stories, 128,000 cached tokens; "
    f"{results[0]['heldout']['tokens']:,} predicted tokens in full packed blocks, evaluated only at the fixed endpoint.",'',
    'Data uses [TinyStories](https://huggingface.co/datasets/roneneldan/TinyStories), pinned revision '
    '`f54c09fd23315a6f9c86f9dc80f725de7d8f9c64`, CDLA-Sharing-1.0. EOS is inserted between stories. '
    'Train and original validation token caches are reconstructed and checked for exact equality before creating the new partition. '
    'The holdout starts after the last complete story contributing to the original validation prefix. Exact text hashes exclude '
    'selected train stories, original validation stories and repeated holdout stories. This is an extra partition of the official '
    'validation split, not an official test split or an independent domain. Near-duplicate/paraphrase removal was not performed. '
    'The holdout was not used to tune the learning rate, architecture, budget or engine.','',
    'Evaluation reports mean next-token negative log-likelihood in nats per predicted token and perplexity exp(NLL). '
    'Packed blocks can cross story boundaries and do not mask attention at EOS. The same packing and causal mask apply to both models.','',
    '## Per-seed measured results','',
    '| Seed | Model | Validation NLL | Heldout NLL | Heldout perplexity | Training tokens/s | First step, s | Full run, s |',
    '| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |']
for r in results:
    lines.append(f"| {r['seed']} | {r['architecture']} | {r['validation']['nll']:.4f} | {r['heldout']['nll']:.4f} | "
        f"{r['heldout']['perplexity']:.3f} | {r['median_training_tokens_per_second']:.0f} | "
        f"{r['first_step_seconds_including_cold_compile']:.2f} | {r['run_wall_seconds_including_compile_eval_checkpoint_io']:.2f} |")
lines+=['','Mean ± sample standard deviation across three seeds:','',
    '| Model | Heldout NLL | Heldout perplexity | Training tokens/s | Peak GPU MiB |',
    '| --- | ---: | ---: | ---: | ---: |']
for architecture,s in summary.items():
    def fmt(key,places):return f"{s[key]['mean']:.{places}f} ± {s[key]['sample_sd']:.{places}f}"
    lines.append(f"| {architecture} | {fmt('heldout_nll',4)} | {fmt('heldout_perplexity',3)} | {fmt('training_tokens_per_second',0)} | {fmt('peak_gpu_mib',1)} |")
lines+=['','## Throughput trials before longer training','',
    'Each isolated trial used eight warmup and 60 measured updates at a logical batch of 32. '
    'Trials started from scratch and are performance experiments, not heldout-quality results. '
    'The cached AttnRes benchmark preserves phase-one FP16 partial-block accumulation; the subsequent controlled trainer '
    'uses FP32 for those sums. Its actual training speeds are therefore reported separately above.','',
    '| Candidate | Median tokens/s | First step including compilation, s | Peak GPU MiB |',
    '| --- | ---: | ---: | ---: |']
for row in bench:
    if row['status']=='ok':
        lines.append(f"| {row['config']['name']} | {row['median_training_tokens_per_second']:.0f} | "
            f"{row['first_step_seconds_including_cold_compile']:.2f} | {row['peak_allocated_gpu_bytes']/2**20:.1f} |")
    else:lines.append(f"| {row['config']['name']} | {row['status']} | — | — |")
lines+=['',
    'Timing uses synchronized complete optimizer updates, including batch construction/transfer, forward/backward, gradient scaling, '
    'clipping and optimizer work. Steady throughput is the median of per-step tokens/s after the first eight steps. '
    'It excludes validation, compilation setup, checkpoint writes, Drive backup and data/dependency setup. '
    'The first-step measurement includes any compilation on that invocation; later runs can reuse compiler caches, so '
    'it is not a guaranteed cold-cache compilation cost for every seed. Full-run wall time includes model setup, compilation, '
    'evaluation and periodic checkpoint/Drive backup IO, but excludes data preparation, imports, and final result-metadata backup. '
    'GPU memory is PyTorch peak allocated memory during each uninterrupted run, not reserved memory or full-device use.','',
    'The benchmark loop also reduces per-microbatch Python checks relative to the historical pilot. '
    'Consequently its eager original timings differ from phase-one timings; one must not attribute the entire '
    'cross-phase throughput gain to depth-mixing optimization. Free shared hardware, compiler-cache reuse, '
    'single-session timing and limited execution-order reversal restrict performance claims.','',
    '## Verification, artifacts and reproducibility','',
    'Four optimized-wrapper checks passed in Colab: original-path equality, cached/reference logits and gradients '
    '(including nonzero learned queries and multiple block sizes), causal outputs, and CUDA FP16 equivalence. '
    'The controlled-model checks verify exact shared initialization, FP32 reference outputs/gradients and causality, '
    'and FP32 states entering every layer normalization under CUDA FP16 autocast. '
    'Compiled and eager losses and gradients were compared at the real batch/context shape for both controlled architectures, '
    'using loss scaling of 1,024 before backward and unscaling gradients afterward, as in training. '
    'Tolerances and maximum observed errors are saved in `controlled_compilation_checks.json`; tests are not quality results.','',
    'An earlier unscaled FP16 backward comparison failed the gradient tolerance despite nearly identical losses. '
    'Diagnostics were retained under `unscaled_*` in `phase2/results/`. Repeating the test with the trainer’s loss scaling '
    'greatly reduced differences and both models passed the same tolerance. This is consistent with FP16 small-gradient '
    'underflow/rounding in the unscaled computation; it does not establish bitwise equivalence or prove compiler correctness '
    'for every trained state. No tolerance was loosened to obtain the scaled result.','',
    'Every run stores its configuration, source/data hashes, per-step timings, validation history, endpoint result and '
    'a resumable checkpoint containing model, optimizer, scaler, RNG state and step. Runtime checkpoints are saved every '
    '100 updates; verified Drive copies are made at 500 and 1,000 updates and after completion. '
    'Changing the source/configuration/data/environment requires a new run directory. The original phase-one trainer '
    'also passed interrupted-resume equality tests; the phase-two runner reuses the same checkpoint-state pattern but '
    'has not undergone a full GPU interrupted/resumed trajectory equivalence test.','',
    'User-authorized Drive destination: `My Drive/mini-k3/2026-10-18`. Each copied file is verified by SHA-256. '
    'Phase-one and phase-two model bytes live there; the local research bundle contains code, logs, manifests and reports, '
    'and does not pretend to contain model checkpoint bytes. A complete backup manifest records sizes and checksums.','',
    '## Interpretation and remaining work','',
    'This study measures early domain language modeling on a 13.2M-parameter model. Three seeds quantify '
    'initialization/sampling variability on a fixed corpus, not statistical confidence across tasks or domains. '
    'The unchanged hyperparameters may favor one architecture; no learning-rate sweep was conducted. '
    'A longer or full-size MiniMind study, independent-domain evaluation, downstream tasks, cached inference and '
    'wall-clock-budget comparisons remain. Results should be described with these limits; a professor’s acceptance '
    'decision is independent of completing this experiment.','',
    '']
(OUT/'PHASE2_REPORT.md').write_text('\n'.join(lines),encoding='utf-8')

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig,axes=plt.subplots(1,2,figsize=(11,4))
for architecture,color in [('baseline','#3659a5'),('attnres','#d46423')]:
    points=sorted({r['step'] for r in histories})
    values=[[r['nll'] for r in histories if r['architecture']==architecture and r['step']==step] for step in points]
    means=[stats.mean(v) for v in values];sd=[stats.stdev(v) for v in values]
    xs=[s*4096/1e6 for s in points]
    axes[0].plot(xs,means,label=architecture,color=color,marker='.',markersize=5)
    axes[0].fill_between(xs,[m-s for m,s in zip(means,sd)],[m+s for m,s in zip(means,sd)],alpha=.15,color=color)
    ys=[by_key[architecture,seed]['heldout']['perplexity'] for seed in (17,42,123)]
    axes[1].scatter([architecture]*3,ys,color=color,s=35,label=architecture)
axes[0].set(xlabel='Predicted training tokens (millions)',ylabel='Validation NLL (nats/token)',title='Mean ± sample SD, three seeds')
axes[0].legend();axes[0].grid(alpha=.2)
axes[1].set(ylabel='Heldout perplexity (lower is better)',title='Untouched stories: fixed 1,000-step endpoint')
axes[1].grid(axis='y',alpha=.2)
fig.tight_layout();fig.savefig(OUT/'phase2_results.png',dpi=180);plt.close(fig)
print(json.dumps({'summary':summary,'paired':paired},indent=2))
print('PHASE2_ANALYSIS_COMPLETE',OUT/'PHASE2_REPORT.md')
