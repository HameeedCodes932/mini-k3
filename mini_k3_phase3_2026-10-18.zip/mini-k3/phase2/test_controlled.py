"""Check shared initialization, precision, causal masking and compilation."""
import copy
import gc
import json
from pathlib import Path
import time
import unittest
import torch
from experiment import build_model
from controlled import ControlledLM,controlled_model
from optimized import TrainingLM,TrainingLoss


class ControlledTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):torch.set_num_threads(2)

    def test_shared_initialization(self):
        a=controlled_model('baseline').state_dict()
        b=controlled_model('attnres').state_dict()
        for key,value in a.items():torch.testing.assert_close(value,b[key],rtol=0,atol=0)

    def test_reference_math_and_causality(self):
        original=build_model('tiny',16,'attnres',42)
        with torch.no_grad():
            for m in original.model.depth_mixers:
                m.query.normal_(0,.1);m.key_norm.weight.uniform_(.8,1.2)
        a=TrainingLM(copy.deepcopy(original),'attnres_reference')
        b=ControlledLM(copy.deepcopy(original),'attnres')
        x=torch.randint(0,6400,(2,12));y=x.clone();y[:,7:]=0
        torch.testing.assert_close(a(x),b(x),rtol=2e-4,atol=2e-6)
        torch.testing.assert_close(b(x)[:,:7],b(y)[:,:7],rtol=1e-5,atol=1e-5)
        TrainingLoss(a)(x,y).backward();TrainingLoss(b)(x,y).backward()
        for (name,p),(_,q) in zip(a.named_parameters(),b.named_parameters()):
            gp=torch.zeros_like(p) if p.grad is None else p.grad
            gq=torch.zeros_like(q) if q.grad is None else q.grad
            self.assertTrue(torch.isfinite(gq).all(),name)
            torch.testing.assert_close(gp,gq,rtol=2e-3,atol=3e-6,msg=name)

    @unittest.skipUnless(torch.cuda.is_available(),'GPU test runs in Colab')
    def test_fp32_states_under_autocast(self):
        for architecture in ('baseline','attnres'):
            model=controlled_model(architecture).cuda()
            seen=[]
            hooks=[norm.register_forward_pre_hook(lambda m,args:seen.append(args[0].dtype))
                for layer in model.backbone.layers for norm in (layer.input_layernorm,layer.post_attention_layernorm)]
            with torch.autocast('cuda',dtype=torch.float16):model(torch.ones((2,128),dtype=torch.long,device='cuda'))
            self.assertEqual(len(seen),12)
            self.assertTrue(all(dtype==torch.float32 for dtype in seen))
            for hook in hooks:hook.remove()
            del model;gc.collect();torch.cuda.empty_cache()


def compiled_checks():
    rows=[]
    for architecture in ('baseline','attnres'):
        eager=TrainingLoss(controlled_model(architecture).cuda())
        candidate=copy.deepcopy(eager)
        compiled=torch.compile(candidate,fullgraph=True,dynamic=False,mode='default')
        generator=torch.Generator(device='cuda').manual_seed(7)
        x=torch.randint(0,6400,(32,128),generator=generator,device='cuda')
        y=torch.randint(0,6400,(32,128),generator=generator,device='cuda')
        began=time.perf_counter()
        with torch.autocast('cuda',dtype=torch.float16):a=eager(x,y);b=compiled(x,y)
        # Match the actual mixed-precision trainer: scale before backward.
        # Unscaled FP16 CE gradients can underflow before reaching FP32 weights.
        scale=1024.
        (a*scale).backward();(b*scale).backward();torch.cuda.synchronize()
        for objective in (eager,candidate):
            for parameter in objective.parameters():
                if parameter.grad is not None:parameter.grad.div_(scale)
        torch.testing.assert_close(a,b,rtol=1e-3,atol=1e-3)
        max_error=0.;details=[]
        for (name,p),(_,q) in zip(eager.named_parameters(),candidate.named_parameters()):
            gp=torch.zeros_like(p) if p.grad is None else p.grad
            gq=torch.zeros_like(q) if q.grad is None else q.grad
            self_max=(gp-gq).abs().max().item();max_error=max(max_error,self_max)
            details.append({'parameter':name,'max_abs_error':self_max,'eager_max_abs':gp.abs().max().item(),
                'eager_norm':gp.norm().item(),'difference_norm':(gp-gq).norm().item()})
        diagnostic={'architecture':architecture,'gradient_scale':scale,'eager_loss':a.item(),'compiled_loss':b.item(),'parameters':details}
        diagnostics=Path(__file__).parent/'results'/f'compiled_diagnostic_{architecture}.json'
        diagnostics.write_text(json.dumps(diagnostic,indent=2))
        print('COMPILED_DIAGNOSTIC',json.dumps({'architecture':architecture,'eager_loss':a.item(),'compiled_loss':b.item(),
            'largest_errors':sorted(details,key=lambda r:r['max_abs_error'],reverse=True)[:5]}),flush=True)
        passed=True
        for (_,p),(_,q) in zip(eager.named_parameters(),candidate.named_parameters()):
            gp=torch.zeros_like(p) if p.grad is None else p.grad
            gq=torch.zeros_like(q) if q.grad is None else q.grad
            try:torch.testing.assert_close(gp,gq,rtol=.04,atol=2e-4)
            except AssertionError:passed=False
        row={'architecture':architecture,'loss_absolute_error':abs(a.item()-b.item()),
            'max_gradient_absolute_error':max_error,'seconds_including_compile':time.perf_counter()-began,
            'gradient_rtol':.04,'gradient_atol':2e-4,'loss_rtol':1e-3,'loss_atol':1e-3,
            'gradient_scale':scale,
            'status':'passed' if passed else 'failed'}
        rows.append(row);print('COMPILED_EQUIVALENCE',json.dumps(row),flush=True)
        del eager,candidate,compiled,a,b;gc.collect();torch.cuda.empty_cache()
    path=Path(__file__).parent/'results/controlled_compilation_checks.json'
    path.parent.mkdir(exist_ok=True);path.write_text(json.dumps(rows,indent=2))


if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(ControlledTests)
    outcome=unittest.TextTestRunner(verbosity=2).run(suite)
    if not outcome.wasSuccessful():raise SystemExit(1)
    if torch.cuda.is_available():compiled_checks()
