# Understanding and reproducing mini-k3

This is a small research experiment, not a finished chatbot. The starting model
has random weights and learns to predict the next MiniMind token in short English
stories. Lower negative log-likelihood (NLL) and perplexity indicate better
predictions on the particular heldout text. They do not measure factual accuracy,
general intelligence, instruction following or performance in Chinese.

## What changed

The baseline adds each attention and feed-forward output to a running residual
state. Block Attention Residuals instead learns how strongly to combine the
embedding, earlier completed block outputs, and the current partial block.
Softmax weights sum to one over these depth sources. Queries start at zero, so
the first weights are uniform; queries learn different depth choices during
training. Each block here contains two transformer layers (four sublayers).

The faster implementation reuses the inverse RMS of completed block outputs
within the same forward computation. It does not store detached activations
between training updates. It keeps the gradient path intact. Larger physical
batches, fused AdamW and PyTorch compilation reduce additional training overhead.
Both architectures receive these improvements for a fair comparison.

## The numerical-precision finding

FP16 is useful for fast matrix multiplication on a T4, but running sums and tiny
gradients can lose accuracy. Phase one's original baseline and AttnRes paths
accumulated some states differently. Phase two keeps all residual/block states
in FP32 for both models, while still using FP16 matrix operations.

The first compiled/eager gradient check did not scale the loss. It failed the
gradient tolerance. The revised check matches training: multiply the loss by
1,024 before backward, then divide FP32 parameter gradients by 1,024. Both models
passed the unchanged comparison tolerance. Unscaled diagnostics are retained;
this is a numerical-precision issue to understand and disclose, not a quality
result. Compilation does not promise bitwise equality.

## Reproduce

Open `mini_k3_stage2.ipynb` in free Colab and select a T4. Run its setup, optionally
connect Drive, recreate the pinned token cache/holdout, run correctness checks and
benchmarks, then run training and analysis. Internet access is needed for the
pinned upstream source, public dataset and Python packages. GPU availability and
session lifetime depend on Colab's current free allocation.

The notebook trains six runs: baseline and AttnRes at seeds 42, 17 and 123. Each
uses 1,000 optimizer updates, 32 sequences of length 128 per update, and
4,096,000 predicted training tokens. Matching seeds receive the same initial
shared weights and the same sampled training blocks. The data cache holds two
million training tokens; sampling is with replacement, so the training-token
budget is not a count of distinct tokens.

Do not rerun a completed output directory after editing its source, data,
environment or settings. Use a new directory for a new experiment. Backups retain
the model, optimizer, gradient scaler, random states, step, history and timing.
For a fresh runtime, also restore the `.npy` caches and the exact source. A
manifest alone cannot restore cached token bytes.

## What to read before discussing the work

1. `PHASE2_REPORT.md` in `analysis/`: findings, setup, tradeoffs and limitations.
2. `controlled.py` and `optimized.py`: residual accumulation and depth mixing.
3. `train_stage2.py`: matched batches, learning rate, evaluation and checkpoints.
4. `prepare_holdout.py`: exact-story exclusions and endpoint evaluation data.
5. `test_controlled.py` and `test_optimized.py`: what correctness checks establish.
6. `results.csv`, `paired_comparisons.csv` and `learning_curves.csv`: raw evidence.

A useful discussion should explain why
the depth mixer might help, where its extra work costs time, why the FP32 control
matters, and why this small English-domain result cannot establish general LLM
improvement. No result guarantees an acceptance letter.
