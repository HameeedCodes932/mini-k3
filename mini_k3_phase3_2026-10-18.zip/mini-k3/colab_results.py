import json, pandas as pd
result_path = WORK / 'runs' / RUN_NAME / 'results.json'
assert result_path.exists(), 'Training has not completed both variants yet.'
results = json.loads(result_path.read_text())
display(pd.DataFrame(results)[['variant', 'seed', 'parameters', 'training_tokens',
    'validation_nll', 'validation_perplexity', 'median_step_tokens_per_second',
    'peak_allocated_gpu_bytes_this_session']])
print('One short run is preliminary. Report actual gains or regressions, then repeat seeds.')
