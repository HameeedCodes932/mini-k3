"""Summarize completed pilot runs only; no inferred or synthetic results."""
import csv
import hashlib
import json
from pathlib import Path
import statistics

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'analysis'
OUT.mkdir(exist_ok=True)
results, histories, provenance = [], [], []
for folder in ('pilot001', 'replications001'):
    path = ROOT / 'runs' / folder / 'results.json'
    if not path.exists():
        raise RuntimeError(f'Missing completed result file: {path}')
    for row in json.loads(path.read_text()):
        results.append({'run': folder, **row})
        run_dir = path.parent / f"{row['variant']}_seed{row['seed']}"
        config = json.loads((run_dir / 'config.json').read_text())
        provenance.append({'run': folder, 'variant': row['variant'], 'seed': row['seed'],
                           'config': config})
        for point in json.loads((run_dir / 'history.json').read_text()):
            histories.append({'run': folder, 'variant': row['variant'], 'seed': row['seed'], **point})
assert len(results) == 6 and len({(r['variant'], r['seed']) for r in results}) == 6
assert {r['seed'] for r in results} == {17, 42, 123}
assert all(r['completed_steps'] == 200 and r['training_tokens'] == 819200 for r in results)
for key in ('experiment_sha256', 'attnres_sha256', 'data_manifest_sha256'):
    assert len({r['config'][key] for r in provenance}) == 1, f'Mismatched {key}'
by_key = {(r['variant'], r['seed']): r for r in results}
paired = []
for seed in (17, 42, 123):
    a, b = by_key[('baseline', seed)], by_key[('attnres', seed)]
    assert a['environment'] == b['environment']
    paired.append({'seed': seed,
        'baseline_nll': a['validation_nll'], 'attnres_nll': b['validation_nll'],
        'nll_difference_attnres_minus_baseline': b['validation_nll'] - a['validation_nll'],
        'perplexity_reduction_percent': 100 * (1 - b['validation_perplexity'] / a['validation_perplexity']),
        'throughput_change_percent': 100 * (b['median_step_tokens_per_second'] / a['median_step_tokens_per_second'] - 1)})
summary = {}
for variant in ('baseline', 'attnres'):
    rows = [r for r in results if r['variant'] == variant]
    summary[variant] = {'seeds': 3, 'parameters': rows[0]['parameters']}
    for field in ('validation_nll', 'validation_perplexity', 'median_step_tokens_per_second',
                  'peak_allocated_gpu_bytes_this_session'):
        values = [r[field] for r in rows]
        summary[variant][field] = {'mean': statistics.mean(values), 'sample_sd': statistics.stdev(values)}
bundle = {'results': results, 'summary': summary, 'paired_comparisons': paired,
          'provenance': provenance}
(OUT / 'pilot_results.json').write_text(json.dumps(bundle, indent=2), encoding='utf-8')
for filename, rows in [('results.csv', [{k:v for k,v in r.items() if k != 'environment'} for r in results]),
                       ('learning_curves.csv', histories), ('paired_comparisons.csv', paired)]:
    with (OUT / filename).open('w', newline='', encoding='utf-8') as file:
        writer = csv.DictWriter(file, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)
lines = ['# mini-k3: preliminary free-Colab pilot', '', 'Date: 18 October 2026.', '',
    '## Scope and method', '',
    'A reduced dense MiniMind was trained from scratch with standard residual connections '
    'and with a Block Attention Residuals adaptation. Attention and MLP are treated as '
    'separate sublayers. Blocks contain four sublayers. Depth mixers use learned queries, '
    'RMS-normalized keys and a softmax over completed block sums and the current partial sum. '
    'The final mixer aggregates the embedding and all block outputs. '
    'Reference: [Kimi K3, section 2.2](https://arxiv.org/html/2607.24653v2#S2.SS2).', '',
    'This adaptation uses ordinary PyTorch operations, retains MiniMind grouped-query attention, '
    'and implements neither KDA, MLA nor Stable LatentMoE. No optimized AttnRes kernel or '
    'KV cache is included. This experiment evaluates early English language modeling, '
    'not a complete assistant, general reasoning, or reproduction of Kimi K3.', '',
    '## Training setup', '',
    '- Free Tesla T4, 14.56 GiB VRAM; Python 3.13.15, PyTorch 2.11.0+cu130, Transformers 4.57.6.',
    '- MiniMind commit: `f659b55761b754d306bd140573493a6543cafd7f` (Apache-2.0).',
    '- Hidden size 384; six transformer layers; six query/two KV heads; vocabulary 6,400.',
    '- Standard residual model: 13,227,648 parameters; AttnRes: 13,237,632.',
    '- MiniMind tokenizer, unchanged; 128-token inputs; microbatch eight; accumulation four.',
    '- AdamW, peak LR 3e-4, betas (0.9, 0.95), weight decay 0.1; warmup/cosine schedule.',
    '- FP16 autocast, FP32 model parameters, gradient scaling and norm clipping at 1.0.',
    '- 200 optimizer steps: 819,200 predicted tokens per variant per seed.',
    '- Seeds 42, 17, 123. Shared initial parameters and sampled batches match within each seed.',
    '- Seed 42 ran baseline then AttnRes. Seeds 17/123 reversed that order.', '',
    '## Data and evaluation', '',
    'Pinned [TinyStories](https://huggingface.co/datasets/roneneldan/TinyStories) revision '
    '`f54c09fd23315a6f9c86f9dc80f725de7d8f9c64` (CDLA-Sharing-1.0). '
    'Official train/validation split prefixes were streamed; exact-text duplicates were removed '
    'within and across selected splits. Two million training tokens and 100,000 validation '
    'tokens were cached, with EOS between stories. Training samples packed blocks with '
    'replacement using a model-independent seed/step/microbatch index.', '',
    'Validation loss is mean next-token negative log-likelihood (nats/token). Perplexity is '
    'exp(loss), computed on the same 32,768 predicted validation tokens at steps 0, 50, 100, '
    '150 and 200. No test-set evaluation or downstream task accuracy is reported.', '',
    '## Measured results', '',
    '| Seed | Baseline NLL | AttnRes NLL | Baseline perplexity | AttnRes perplexity | Baseline tokens/s | AttnRes tokens/s |',
    '| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
for seed in (17, 42, 123):
    a, b = by_key[('baseline', seed)], by_key[('attnres', seed)]
    lines.append(f"| {seed} | {a['validation_nll']:.4f} | {b['validation_nll']:.4f} | "
        f"{a['validation_perplexity']:.2f} | {b['validation_perplexity']:.2f} | "
        f"{a['median_step_tokens_per_second']:.0f} | {b['median_step_tokens_per_second']:.0f} |")
lines += ['', 'Across seeds (mean ± sample standard deviation):', '',
    '| Variant | NLL | Perplexity | Training tokens/s | Peak allocated GPU memory (MiB) |',
    '| --- | ---: | ---: | ---: | ---: |']
for variant in ('baseline', 'attnres'):
    s = summary[variant]
    def stat(field, divisor=1, places=3):
        a = s[field]
        return f"{a['mean']/divisor:.{places}f} ± {a['sample_sd']/divisor:.{places}f}"
    lines.append(f"| {variant} | {stat('validation_nll')} | {stat('validation_perplexity',places=2)} | "
        f"{stat('median_step_tokens_per_second',places=0)} | {stat('peak_allocated_gpu_bytes_this_session',2**20,1)} |")
mean_ppl_gain = statistics.mean(p['perplexity_reduction_percent'] for p in paired)
mean_speed_change = statistics.mean(p['throughput_change_percent'] for p in paired)
all_lower = all(p['nll_difference_attnres_minus_baseline'] < 0 for p in paired)
lines += ['', f"Mean paired perplexity reduction: **{mean_ppl_gain:.1f}%**. "
    f"Mean paired training throughput change: **{mean_speed_change:+.1f}%**. "
    f"Lower validation NLL in every seed: **{all_lower}**.", '',
    'Training speed is the median predicted tokens/second across synchronized optimizer steps, '
    'excluding the first two steps. It excludes validation, checkpoint writes, dependency '
    'installation and data preparation. Memory uses PyTorch peak allocated bytes during '
    'each uninterrupted run; it is not total device usage or reserved memory. Free shared '
    'hardware and execution order limit timing conclusions.', '',
    '## Interpretation and limitations', '',
    'The quality comparison is preliminary and restricted to a short training budget and '
    'one simple English domain. The seeds assess initialization/sampling variability on '
    'the same fixed corpus, not variation across datasets. This is not a statistical proof '
    'of a general capability gain. The current implementation has a measured speed cost; '
    'it does not satisfy the complete faster-and-stronger objective.', '',
    'Next: extend matched-budget training, evaluate a separate untouched test set and '
    'appropriate downstream tasks, profile depth mixing, and test an optimized implementation '
    'with equivalence checks before reporting a speed gain. A full 64M MiniMind study is '
    'a separate stage. Do not interpret this pilot as an acceptance-letter guarantee.', '',
    '## Reproducibility', '',
    'Six correctness checks passed locally and in Colab: normalized depth mixing, matching '
    'shared initialization, causal outputs/finite gradients, model-independent batches, '
    'completed-run resume and a simulated interruption whose final CPU weights match '
    'uninterrupted training. Test inputs are random and are not research results.', '',
    'Each run includes config, hashes, learning history, timing and a resumable latest.pt '
    'checkpoint (model, optimizer, scaler, RNG, step). The JSON alongside this report '
    'contains all six measured rows and per-run provenance.', '']
(OUT / 'PRELIMINARY_REPORT.md').write_text('\n'.join(lines), encoding='utf-8')
try:
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(7, 4.2))
    for variant, color in [('baseline', '#3659a5'), ('attnres', '#d46423')]:
        points = sorted({r['step'] for r in histories if r['variant'] == variant})
        values = [[r['validation_nll'] for r in histories if r['variant'] == variant and r['step'] == step]
                  for step in points]
        means = [statistics.mean(v) for v in values]
        sd = [statistics.stdev(v) for v in values]
        xs = [step * 4096 / 1e6 for step in points]
        ax.plot(xs, means, marker='o', label=variant, color=color)
        ax.fill_between(xs, [m-s for m,s in zip(means,sd)], [m+s for m,s in zip(means,sd)],
                        alpha=0.15, color=color)
    ax.set(xlabel='Predicted training tokens (millions)', ylabel='Validation NLL (nats/token)',
           title='MiniMind pilot: mean ± sample SD, three seeds')
    ax.grid(alpha=.2)
    ax.legend()
    fig.tight_layout()
    fig.savefig(OUT / 'learning_curves.png', dpi=180)
    plt.close(fig)
except ImportError:
    pass
print(json.dumps({'summary': summary, 'paired_comparisons': paired}, indent=2))
print('Preliminary report:', OUT / 'PRELIMINARY_REPORT.md')
