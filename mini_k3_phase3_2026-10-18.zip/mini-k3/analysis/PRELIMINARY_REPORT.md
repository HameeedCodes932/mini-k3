> Later audit: the original paths differ in residual-accumulation precision. The measured 23.9% gain includes that confound. See `../phase2/analysis/PHASE2_REPORT.md` for the longer precision-controlled comparison. Historical scores below are unchanged.

# mini-k3: preliminary free-Colab pilot

Date: 18 October 2026.

## Scope and method

A reduced dense MiniMind was trained from scratch with standard residual connections and with a Block Attention Residuals adaptation. Attention and MLP are treated as separate sublayers. Blocks contain four sublayers. Depth mixers use learned queries, RMS-normalized keys and a softmax over completed block sums and the current partial sum. The final mixer aggregates the embedding and all block outputs. Reference: [Kimi K3, section 2.2](https://arxiv.org/html/2607.24653v2#S2.SS2).

This adaptation uses ordinary PyTorch operations, retains MiniMind grouped-query attention, and implements neither KDA, MLA nor Stable LatentMoE. No optimized AttnRes kernel or KV cache is included. This experiment evaluates early English language modeling, not a complete assistant, general reasoning, or reproduction of Kimi K3.

## Training setup

- Free Tesla T4, 14.56 GiB VRAM; Python 3.13.15, PyTorch 2.11.0+cu130, Transformers 4.57.6.
- MiniMind commit: `f659b55761b754d306bd140573493a6543cafd7f` (Apache-2.0).
- Hidden size 384; six transformer layers; six query/two KV heads; vocabulary 6,400.
- Standard residual model: 13,227,648 parameters; AttnRes: 13,237,632.
- MiniMind tokenizer, unchanged; 128-token inputs; microbatch eight; accumulation four.
- AdamW, peak LR 3e-4, betas (0.9, 0.95), weight decay 0.1; warmup/cosine schedule.
- FP16 autocast, FP32 model parameters, gradient scaling and norm clipping at 1.0.
- 200 optimizer steps: 819,200 predicted tokens per variant per seed.
- Seeds 42, 17, 123. Shared initial parameters and sampled batches match within each seed.
- Seed 42 ran baseline then AttnRes. Seeds 17/123 reversed that order.

## Data and evaluation

Pinned [TinyStories](https://huggingface.co/datasets/roneneldan/TinyStories) revision `f54c09fd23315a6f9c86f9dc80f725de7d8f9c64` (CDLA-Sharing-1.0). Official train/validation split prefixes were streamed; exact-text duplicates were removed within and across selected splits. Two million training tokens and 100,000 validation tokens were cached, with EOS between stories. Training samples packed blocks with replacement using a model-independent seed/step/microbatch index.

Validation loss is mean next-token negative log-likelihood (nats/token). Perplexity is exp(loss), computed on the same 32,768 predicted validation tokens at steps 0, 50, 100, 150 and 200. No test-set evaluation or downstream task accuracy is reported.

## Measured results

| Seed | Baseline NLL | AttnRes NLL | Baseline perplexity | AttnRes perplexity | Baseline tokens/s | AttnRes tokens/s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 17 | 3.5087 | 3.1938 | 33.41 | 24.38 | 21306 | 16834 |
| 42 | 3.4699 | 3.2068 | 32.13 | 24.70 | 23574 | 17143 |
| 123 | 3.4480 | 3.2048 | 31.44 | 24.65 | 21497 | 16579 |

Across seeds (mean ± sample standard deviation):

| Variant | NLL | Perplexity | Training tokens/s | Peak allocated GPU memory (MiB) |
| --- | ---: | ---: | ---: | ---: |
| baseline | 3.476 ± 0.031 | 32.32 ± 1.00 | 22126 ± 1258 | 512.4 ± 0.6 |
| attnres | 3.202 ± 0.007 | 24.58 ± 0.17 | 16852 ± 283 | 698.3 ± 3.4 |

Mean paired perplexity reduction: **23.9%**. Mean paired training throughput change: **-23.7%**. Lower validation NLL in every seed: **True**.

Training speed is the median predicted tokens/second across synchronized optimizer steps, excluding the first two steps. It excludes validation, checkpoint writes, dependency installation and data preparation. Memory uses PyTorch peak allocated bytes during each uninterrupted run; it is not total device usage or reserved memory. Free shared hardware and execution order limit timing conclusions.

## Interpretation and limitations

The quality comparison is preliminary and restricted to a short training budget and one simple English domain. The seeds assess initialization/sampling variability on the same fixed corpus, not variation across datasets. This is not a statistical proof of a general capability gain. The current implementation has a measured speed cost; it does not satisfy the complete faster-and-stronger objective.

Next: extend matched-budget training, evaluate a separate untouched test set and appropriate downstream tasks, profile depth mixing, and test an optimized implementation with equivalence checks before reporting a speed gain. A full 64M MiniMind study is a separate stage. Do not interpret this pilot as an acceptance-letter guarantee.

## Reproducibility

Six correctness checks passed locally and in Colab: normalized depth mixing, matching shared initialization, causal outputs/finite gradients, model-independent batches, completed-run resume and a simulated interruption whose final CPU weights match uninterrupted training. Test inputs are random and are not research results.

Each run includes config, hashes, learning history, timing and a resumable latest.pt checkpoint (model, optimizer, scaler, RNG, step). The JSON alongside this report contains all six measured rows and per-run provenance.
