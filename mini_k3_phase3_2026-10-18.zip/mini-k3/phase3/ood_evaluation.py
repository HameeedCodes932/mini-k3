"""Locked, custom WikiText-2 prefix evaluation after model selection."""
import gc
import json
from pathlib import Path
import numpy as np
import torch
from datasets import load_dataset
from transformers import AutoTokenizer
from experiment import digest,dump_json,token_blocks
from models import create_model
from runner import evaluate

ROOT=Path(__file__).resolve().parent.parent
HERE=ROOT/'phase3'
OUT=HERE/'data'
DATASET='Salesforce/wikitext'
REVISION='b08601e04326c79dfdd32d625aee71d232d685c3'
manifest_path=OUT/'wikitext_manifest.json'
if manifest_path.exists():
    manifest=json.loads(manifest_path.read_text())
    assert digest(OUT/'wikitext.npy')==manifest['sha256']
else:
    tokenizer=AutoTokenizer.from_pretrained(str(ROOT/'vendor/model'),trust_remote_code=False)
    ids=[];lines=0
    stream=load_dataset(DATASET,'wikitext-2-raw-v1',revision=REVISION,split='test',streaming=True)
    for row in stream:
        text=row['text'].strip()
        if not text:continue
        ids.extend(tokenizer.encode(text,add_special_tokens=False)+[tokenizer.eos_token_id]);lines+=1
        if len(ids)>=128_000:break
    assert len(ids)>=128_000
    np.save(OUT/'wikitext.npy',np.asarray(ids[:128_000],dtype=np.int32))
    manifest={'dataset':DATASET,'configuration':'wikitext-2-raw-v1','split':'test','revision':REVISION,
        'token_cap':128_000,'nonempty_lines_consumed':lines,'sha256':digest(OUT/'wikitext.npy'),
        'tokenizer_sha256':digest(ROOT/'vendor/model/tokenizer.json'),
        'protocol_sha256':digest(HERE/'OOD_PROTOCOL.md'),
        'packing':'Strip nonempty lines; EOS after each; consecutive 129-token blocks; 128 predictions per block',
        'license_tags':['cc-by-sa-3.0','gfdl'],'standard_wikitext_protocol':False}
    dump_json(manifest_path,manifest)
print('OOD_DATA_READY',json.dumps(manifest),flush=True)
selection=json.loads((HERE/'selection.json').read_text())
confirmation=json.loads((HERE/'confirmation_results.json').read_text())
assert len(confirmation)==9
blocks=token_blocks(OUT/'wikitext.npy',128)
results=[]
for row in confirmation:
    folder=HERE/'runs/confirmation'/f"{row['candidate']}_seed{row['seed']}"
    weights=folder/'model_weights.pt'
    saved=torch.load(weights,map_location='cpu',weights_only=True)
    model=create_model(row['candidate'],row['seed']).cuda()
    model.load_state_dict(saved['model'],strict=True)
    result={'candidate':row['candidate'],'seed':row['seed'],**evaluate(model,blocks),
        'weights_sha256':digest(weights),'dataset_manifest_sha256':digest(manifest_path),
        'selection_sha256':digest(HERE/'selection.json'),'protocol_sha256':digest(HERE/'OOD_PROTOCOL.md')}
    results.append(result);dump_json(HERE/'ood_results.json',results)
    print('PHASE3_OOD_RESULT',json.dumps(result),flush=True)
    del model,saved;gc.collect();torch.cuda.empty_cache()
print('PHASE3_OOD_COMPLETE',flush=True)
