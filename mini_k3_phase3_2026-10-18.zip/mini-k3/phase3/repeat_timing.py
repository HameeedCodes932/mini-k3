"""Short alternating-order repetitions using fixed saved confirmation models."""
import gc
import json
from pathlib import Path
import statistics
import time
import torch
from experiment import digest,dump_json,environment,token_blocks
from models import create_model
from optimized import TrainingLoss
from benchmark_stage2 import logical_batch

ROOT=Path(__file__).resolve().parent.parent
HERE=ROOT/'phase3'
selection=json.loads((HERE/'selection.json').read_text())
names=['baseline6',selection['winner']]
data=token_blocks(ROOT/'data/train.npy',128)
torch.set_num_threads(4)
torch.backends.cuda.matmul.allow_tf32=False
torch.backends.cudnn.allow_tf32=False
states={};hashes={}
for name in names:
    path=HERE/'runs/confirmation'/f'{name}_seed777/model_weights.pt'
    saved=torch.load(path,map_location='cpu',weights_only=True)
    model=create_model(name,777).cuda().train();model.load_state_dict(saved['model'])
    objective=torch.compile(TrainingLoss(model),fullgraph=True,dynamic=False,mode='default')
    optimizer=torch.optim.AdamW(model.parameters(),lr=1e-4,betas=(.9,.95),weight_decay=.1,fused=True)
    states[name]={'model':model,'objective':objective,'optimizer':optimizer,'scaler':torch.amp.GradScaler('cuda',init_scale=1024)}
    hashes[name]=digest(path)
    del saved
def step(name,index):
    state=states[name];model=state['model'];optimizer=state['optimizer'];scaler=state['scaler']
    optimizer.zero_grad(set_to_none=True)
    torch.cuda.synchronize();start=time.perf_counter()
    x,y=logical_batch(data,888,index)
    with torch.autocast('cuda',dtype=torch.float16):loss=state['objective'](x,y)
    scaler.scale(loss).backward();scaler.unscale_(optimizer)
    torch.nn.utils.clip_grad_norm_(model.parameters(),1.,error_if_nonfinite=True)
    if not torch.isfinite(loss):raise FloatingPointError('Nonfinite timing loss')
    scaler.step(optimizer);scaler.update();torch.cuda.synchronize()
    return time.perf_counter()-start
for name in names:
    for index in range(8):step(name,index)
rows=[]
for repeat in range(5):
    order=names if repeat%2==0 else list(reversed(names))
    speeds={}
    for name in order:
        durations=[step(name,8+repeat*50+index) for index in range(50)]
        speeds[name]=statistics.median(4096/value for value in durations)
        rows.append({'repeat':repeat,'candidate':name,'order':order.index(name),
            'median_training_tokens_per_second':speeds[name],'step_seconds':durations})
    print('PHASE3_TIMING_REPEAT',repeat,json.dumps(speeds),
        'winner_speed_change_percent',100*(speeds[names[1]]/speeds['baseline6']-1),flush=True)
bundle={'rows':rows,'source_checkpoint_sha256':hashes,'environment':environment('cuda'),
    'protocol_sha256':digest(HERE/'TIMING_PROTOCOL.md'),'source_sha256':digest(__file__),
    'winner':names[1],'timing_only':True,'saved_weights_unchanged':True}
for name in names:
    assert digest(HERE/'runs/confirmation'/f'{name}_seed777/model_weights.pt')==hashes[name]
dump_json(HERE/'repeated_timing.json',bundle)
print('PHASE3_REPEATED_TIMING_COMPLETE',flush=True)
