"""Analyze the fixed development screen, confirmation, and independent-domain check."""
import csv
import hashlib
import json
from pathlib import Path
import statistics as stats
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

HERE=Path(__file__).resolve().parent
OUT=HERE/'analysis'
OUT.mkdir(exist_ok=True)
selection=json.loads((HERE/'selection.json').read_text())
screen=json.loads((HERE/'screen_results.json').read_text())
confirmation=json.loads((HERE/'confirmation_results.json').read_text())
ood=json.loads((HERE/'ood_results.json').read_text())
holdout=json.loads((HERE/'data/holdout_manifest.json').read_text())
ood_manifest=json.loads((HERE/'data/wikitext_manifest.json').read_text())
repeated=json.loads((HERE/'repeated_timing.json').read_text())
assert len(screen)==6 and len(confirmation)==9 and len(ood)==9
winner=selection['winner'];names=['baseline6','baseline5',winner]
seeds=selection['confirmation_seeds']
assert {(r['candidate'],r['seed']) for r in confirmation}=={(name,seed) for name in names for seed in seeds}
assert all(r['steps']==1000 and r['training_tokens']==4_096_000 for r in screen+confirmation)
configs=[];histories=[];backups=[]
for row in screen+confirmation:
    folder=HERE/'runs'/row['phase']/f"{row['candidate']}_seed{row['seed']}"
    config=json.loads((folder/'config.json').read_text())
    configs.append(config)
    for source,expected in config['source_hashes'].items():
        actual=hashlib.sha256((HERE/source).read_bytes()).hexdigest()
        if actual!=expected:
            # The signed run hashes remain unchanged. Only a recorded editorial
            # revision of the non-executable protocol is accepted here.
            revisions=json.loads((HERE/'document_revisions.json').read_text())
            revision=next((r for r in revisions['files'] if r['path']=='phase3/'+source),None)
            assert source=='PROTOCOL.md' and revision is not None,source
            assert revision['original_sha256']==expected and revision['revised_sha256']==actual,source
    if row['phase']=='confirmation':
        assert config['selection_sha256']==hashlib.sha256((HERE/'selection.json').read_bytes()).hexdigest()
    for point in json.loads((folder/'history.json').read_text()):
        histories.append({'candidate':row['candidate'],'seed':row['seed'],'phase':row['phase'],**point})
    backups.extend(json.loads((folder/'backup_verification.json').read_text()))
assert len({json.dumps(c['source_hashes'],sort_keys=True) for c in configs})==1
assert len({json.dumps(c['environment'],sort_keys=True) for c in configs})==1
assert all(r['resume_step_this_session']==0 for r in confirmation),'Resumed timings require an explicit separate analysis'
by_key={(r['candidate'],r['seed']):r for r in confirmation}
ood_by_key={(r['candidate'],r['seed']):r for r in ood}
summary={}
for name in names:
    rows=[r for r in confirmation if r['candidate']==name]
    values={
        'heldout_nll':[r['heldout']['nll'] for r in rows],
        'heldout_perplexity':[r['heldout']['perplexity'] for r in rows],
        'development_nll':[r['development']['nll'] for r in rows],
        'training_tokens_per_second':[r['median_training_tokens_per_second'] for r in rows],
        'wikitext_nll':[ood_by_key[name,r['seed']]['nll'] for r in rows],
        'wikitext_perplexity':[ood_by_key[name,r['seed']]['perplexity'] for r in rows],
        'target_wall_seconds':[r['first_observed_target_crossing']['wall_seconds'] for r in rows if r['first_observed_target_crossing']],
        'target_training_seconds':[r['first_observed_target_crossing']['training_seconds'] for r in rows if r['first_observed_target_crossing']],
        'full_run_wall_seconds':[r['active_run_wall_seconds_including_setup_compile_eval_checkpoint_io'] for r in rows],
        'peak_gpu_mib':[r['peak_allocated_gpu_bytes_this_session']/2**20 for r in rows]}
    summary[name]={'parameters':rows[0]['parameters'],
        **{key:{'count':len(v),'mean':stats.mean(v) if v else None,'sample_sd':stats.stdev(v) if len(v)>1 else None} for key,v in values.items()}}
paired=[]
for seed in seeds:
    a,b,c=by_key['baseline6',seed],by_key[winner,seed],by_key['baseline5',seed]
    target_a,target_b=a['first_observed_target_crossing'],b['first_observed_target_crossing']
    paired.append({'seed':seed,
        'heldout_nll_difference':b['heldout']['nll']-a['heldout']['nll'],
        'heldout_perplexity_reduction_percent':100*(1-b['heldout']['perplexity']/a['heldout']['perplexity']),
        'throughput_change_percent':100*(b['median_training_tokens_per_second']/a['median_training_tokens_per_second']-1),
        'target_wall_reduction_percent':100*(1-target_b['wall_seconds']/target_a['wall_seconds']) if target_a and target_b else None,
        'target_training_time_reduction_percent':100*(1-target_b['training_seconds']/target_a['training_seconds']) if target_a and target_b else None,
        'wikitext_nll_difference':ood_by_key[winner,seed]['nll']-ood_by_key['baseline6',seed]['nll'],
        'wikitext_perplexity_reduction_percent':100*(1-ood_by_key[winner,seed]['perplexity']/ood_by_key['baseline6',seed]['perplexity']),
        'same_depth5_nll_difference':b['heldout']['nll']-c['heldout']['nll'] if selection['configuration']['layers']==5 else None,
        'same_depth5_throughput_change_percent':100*(b['median_training_tokens_per_second']/c['median_training_tokens_per_second']-1) if selection['configuration']['layers']==5 else None})
quality_all=all(r['heldout_nll_difference']<0 for r in paired)
speed_all=all(r['throughput_change_percent']>0 for r in paired)
ood_all=all(r['wikitext_nll_difference']<0 for r in paired)
criteria={'lower_tinystories_nll_every_seed':quality_all,'higher_raw_throughput_every_seed':speed_all,
    'primary_local_faster_and_stronger_criterion_met':quality_all and speed_all,
    'lower_custom_wikitext_nll_every_seed':ood_all,
    'lower_target_wall_every_seed':all(r['target_wall_reduction_percent'] is not None and r['target_wall_reduction_percent']>0 for r in paired)}
bundle={'selection':selection,'criteria':criteria,'summary':summary,'paired':paired,'screen':screen,
    'confirmation':confirmation,'ood':ood,'configs':configs,'holdout_manifest':holdout,'ood_manifest':ood_manifest,
    'repeated_timing':repeated}
(OUT/'phase3_results.json').write_text(json.dumps(bundle,indent=2),encoding='utf-8')
flat=[]
for r in confirmation:
    flat.append({'candidate':r['candidate'],'seed':r['seed'],'parameters':r['parameters'],
        'heldout_nll':r['heldout']['nll'],'heldout_perplexity':r['heldout']['perplexity'],
        'wikitext_nll':ood_by_key[r['candidate'],r['seed']]['nll'],
        'wikitext_perplexity':ood_by_key[r['candidate'],r['seed']]['perplexity'],
        'training_tokens_per_second':r['median_training_tokens_per_second'],
        'target_step':r['first_observed_target_crossing']['step'] if r['first_observed_target_crossing'] else None,
        'target_wall_seconds':r['first_observed_target_crossing']['wall_seconds'] if r['first_observed_target_crossing'] else None,
        'full_run_wall_seconds':r['active_run_wall_seconds_including_setup_compile_eval_checkpoint_io']})
for name,rows in [('confirmation_results.csv',flat),('paired_comparisons.csv',paired),('learning_curves.csv',histories)]:
    with (OUT/name).open('w',newline='',encoding='utf-8') as handle:
        writer=csv.DictWriter(handle,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
gain=stats.mean(r['heldout_perplexity_reduction_percent'] for r in paired)
speed=stats.mean(r['throughput_change_percent'] for r in paired)
ood_gain=stats.mean(r['wikitext_perplexity_reduction_percent'] for r in paired)
wall_values=[r['target_wall_reduction_percent'] for r in paired if r['target_wall_reduction_percent'] is not None]
wall_gain=stats.mean(wall_values) if wall_values else None
reduction=100*(1-summary[winner]['parameters']/summary['baseline6']['parameters'])
status='MET within the stated small-model TinyStories comparison' if criteria['primary_local_faster_and_stronger_criterion_met'] else 'NOT MET on the locked three-seed comparison'
lines=['# mini-k3: lower-cost attention residuals and compact-model confirmation','',
    'Date: 18 October 2026. Author: Fazal Hameed.','',
    '## Outcome','',
    f"Selected model: **{winner}**, {summary[winner]['parameters']:,} parameters ({reduction:.2f}% fewer than baseline6). "
    f'The mean paired heldout-perplexity reduction was **{gain:.2f}%** and the mean paired raw-throughput change was **{speed:+.2f}%**. '
    f'The internally fixed faster-and-stronger criterion was **{status}**.','',
    f'The additional custom WikiText-2 test-prefix perplexity change was a {ood_gain:+.2f}% reduction '
    f'(positive means better). Lower WikiText NLL in every seed: {ood_all}. '
    'These results do not establish general LLM capability, Chinese ability or assistant quality.','',
    '## Experiment design','',
    'The six-layer pilot MiniMind baseline and five-layer ordinary-residual control were compared with four AttnRes '
    'candidates: five/six layers and blocks of four/twelve sublayers. All retain width 384, six query/two KV heads, '
    'vocabulary 6,400, the original tokenizer, causal grouped-query attention, rotary positions, dense feed-forward '
    'layers and FP32 residual/block accumulation under FP16 linear autocast. The models train from scratch. '
    'MiniMind is pinned at `f659b55761b754d306bd140573493a6543cafd7f` (Apache-2.0).','',
    'Block Attention Residuals follows the depth-mixing idea in [Kimi K3, section 2.2]'
    '(https://arxiv.org/html/2607.24653v2#S2.SS2). The new implementation stores completed block states in tuples '
    'rather than repeatedly stacking full hidden-state tensors. It caches each completed state’s inverse RMS '
    'within the differentiable forward computation. With two source scores s0/s1 and values v0/v1, '
    'the second softmax weight equals sigmoid(s1-s0); the mixture is v0 + gate*(v1-v0). '
    'More than two sources use small score stacks and '
    'weighted sums. The sigmoid identity is algebraically equivalent, with floating-point roundoff differences.','',
    'Larger blocks reduce the number of completed depth sources, while the mixer is still evaluated before each '
    'attention/MLP and at the output. A block size of twelve exceeds a five-layer model’s ten sublayers; '
    'its final mixer includes the unfinished partial sum. Compactness is a real architecture change, and '
    'the comparison is not parameter-matched. The five-layer ordinary control separates depth reduction '
    'from adding AttnRes. Matching-depth models share identical initial weights; different-depth models '
    'use the same seed but do not assert all initial tensors are identical. No KDA, LatentMoE, SiTU-GLU or Muon '
    'is implemented. No KV-cache or decoding-speed claim is made.','',
    '## Development screen and selection','',
    'An internal protocol was written before the new training. Seed 42 was used only for development. '
    'Each of six candidates trained for 1,000 updates. Among AttnRes candidates whose endpoint development '
    'NLL beat baseline6 by at least 0.005, the highest measured steady training throughput was selected. '
    'If no candidate passed, the lowest-NLL AttnRes candidate would be selected and the condition flagged as '
    'failed. Selection never used new confirmation holdout or WikiText scores. This was an internal '
    'prospective plan, not an externally registered study.','',
    '| Candidate | Parameters | Development NLL | Training tokens/s | First step, s |',
    '| --- | ---: | ---: | ---: | ---: |']
for r in screen:
    lines.append(f"| {r['candidate']} | {r['parameters']:,} | {r['development']['nll']:.4f} | "
        f"{r['median_training_tokens_per_second']:.0f} | {r['first_step_seconds_including_compilation']:.2f} |")
lines+=['',f"Selected: `{winner}`. Quality selection condition passed: {selection['quality_selection_condition_passed']}.",'',
    '## Locked training and heldout evaluation','',
    '- Three confirmation seeds: 17, 123 and 777. Seeds 17/123 occurred in earlier work, but were not used to select '
    'this phase’s winner; 777 is new. The development screen uses seed 42 only.',
    '- Baseline6, baseline5 and the locked winner run at every seed, with execution order rotated.',
    '- Free Tesla T4 (14.56 GiB), Python 3.13.15, PyTorch 2.11.0+cu130, Transformers 4.57.6.',
    '- Physical/logical batch 32, 128 predicted tokens per sequence: 4,096 predicted tokens per update.',
    '- 1,000 updates and 4,096,000 processed training tokens per run. Same seed/step-dependent batch stream.',
    '- Fused AdamW, peak LR 3e-4, 50-update warmup and cosine decay toward 10% peak, betas (.9,.95), weight decay .1.',
    '- FP32 parameters and residual/block states; FP16 linear autocast; initial loss scale 1,024; clip norm 1.0.',
    '- Full-graph `torch.compile`, default mode, fixed shapes. All candidates pass compiled/eager scaled-gradient checks.',
    '- Development NLL evaluated every 50 updates on the same 32,768 predicted tokens. No hyperparameter sweep.',
    '- Nonfinite loss/gradients halt training; no silently skipped updates or unequal token budgets.','',
    'Training uses the same pinned, exact-text-deduplicated two-million-token TinyStories cache. It is sampled '
    'with replacement, so processed-token count is not a distinct-token count. Dataset revision '
    '`f54c09fd23315a6f9c86f9dc80f725de7d8f9c64`, CDLA-Sharing-1.0. The training cache, original validation '
    'prefix and phase-two heldout prefix were reconstructed and checked for exact token equality. '
    f"A new partition uses {holdout['new_holdout_stories']} subsequent complete validation stories, "
    f"128,000 cached tokens and {confirmation[0]['heldout']['tokens']:,} predicted tokens in full packed blocks. "
    'Complete selected train, original validation and earlier heldout stories are excluded by exact text hash. '
    'Near-duplicate/paraphrase removal was not performed. The new partition is not an official test split '
    'or a new domain; it is evaluated only at the fixed confirmation endpoint.','',
    'Perplexity is exp(mean next-token NLL in nats/token). Packed blocks can cross story boundaries and '
    'do not mask attention at EOS. Both models use the same packing, tokenizer and causal mask.','',
    '## Three-seed confirmation results','',
    '| Seed | Candidate | Heldout NLL | Heldout perplexity | Training tokens/s | Target step | Target wall, s |',
    '| --- | --- | ---: | ---: | ---: | ---: | ---: |']
for row in flat:
    step='not reached' if row['target_step'] is None else str(row['target_step'])
    wall='not reached' if row['target_wall_seconds'] is None else f"{row['target_wall_seconds']:.2f}"
    lines.append(f"| {row['seed']} | {row['candidate']} | {row['heldout_nll']:.4f} | {row['heldout_perplexity']:.3f} | "
        f"{row['training_tokens_per_second']:.0f} | {step} | {wall} |")
lines+=['','Means ± sample SD across three confirmation seeds:','',
    '| Candidate | Heldout perplexity | Training tokens/s | Target wall, s | Peak GPU MiB |',
    '| --- | ---: | ---: | ---: | ---: |']
for name in names:
    s=summary[name]
    def fmt(key,places):
        v=s[key]
        if v['count']!=3:return f"{v['count']}/3 reached"
        return f"{v['mean']:.{places}f} ± {v['sample_sd']:.{places}f}"
    lines.append(f"| {name} | {fmt('heldout_perplexity',3)} | {fmt('training_tokens_per_second',0)} | {fmt('target_wall_seconds',2)} | {fmt('peak_gpu_mib',1)} |")
lines+=['','Paired winner changes against baseline6 (positive percentages mean improvement):','',
    '| Seed | Heldout perplexity reduction | Throughput increase | Target wall reduction | WikiText perplexity reduction |',
    '| --- | ---: | ---: | ---: | ---: |']
for p in paired:
    target='not comparable' if p['target_wall_reduction_percent'] is None else f"{p['target_wall_reduction_percent']:+.2f}%"
    lines.append(f"| {p['seed']} | {p['heldout_perplexity_reduction_percent']:+.2f}% | {p['throughput_change_percent']:+.2f}% | "
        f"{target} | {p['wikitext_perplexity_reduction_percent']:+.2f}% |")
lines+=['','## Repeated timing validation','',
    'A separate timing-only check loads the fixed seed-777 confirmation checkpoints, uses fresh AdamW/scaler '
    'states, warms up eight updates per model, then measures five repetitions of 50 updates each. '
    'The execution order alternates. Data seed 888, LR 1e-4 and the same precision/compiler settings '
    'are fixed. The temporary benchmark updates do not modify saved weights and do not produce quality scores. '
    'This check reduces the separation between speed comparisons; it does not replace the primary criterion.','',
    '| Repetition | Baseline6 tokens/s | Winner tokens/s | Winner speed change |',
    '| --- | ---: | ---: | ---: |']
repeat_changes=[]
for repeat in range(5):
    a=next(r for r in repeated['rows'] if r['repeat']==repeat and r['candidate']=='baseline6')['median_training_tokens_per_second']
    b=next(r for r in repeated['rows'] if r['repeat']==repeat and r['candidate']==winner)['median_training_tokens_per_second']
    change=100*(b/a-1);repeat_changes.append(change)
    lines.append(f'| {repeat+1} | {a:.0f} | {b:.0f} | {change:+.2f}% |')
lines+=['',f'Mean paired repeated-benchmark speed change: {stats.mean(repeat_changes):+.2f}%. '
    f'Higher winner throughput in all five repetitions: {all(v>0 for v in repeat_changes)}.','',
    '## Time to a fixed prediction quality','',
    'The fixed target is development NLL <= 2.10, chosen from the earlier phase before these runs. '
    'The first observed crossing is measured at 50-update intervals; it is not interpolated or an exact '
    'earliest crossing. Cumulative training-step time and wall time are both retained. Wall time includes '
    'model creation, compiler-cache loading/compilation, development evaluation and any runtime checkpoints '
    'written before the crossing. It excludes dependency/data preparation and final model export/Drive backup. '
    'No Drive checkpoint writes occur inside the timed training run. These are training-time measurements '
    'and cannot be described as inference latency.','',
    (f'Mean paired target wall-time reduction: {wall_gain:+.2f}%.' if wall_gain is not None else 'No paired target wall-time comparison was possible.'),
    'Faster time to this one quality threshold is a separate metric. It cannot replace a failed raw '
    'throughput result or establish performance at every quality target.','',
    'Steady throughput includes synchronized batch construction/transfer, forward/backward, scaling, clipping '
    'and optimizer work after the first eight updates; it excludes evaluation/checkpoint IO. Compiler caches '
    'were primed by correctness checks and development runs. First-step times are recorded but are not a '
    'controlled empty-cache compilation experiment. Shared free hardware, thermal/load variation, a single '
    'session and limited order rotation restrict small timing differences. Peak memory is PyTorch allocated '
    'memory, not reserved or total-device use.','',
    '## Additional-domain check','',
    'After selection and confirmation training, all nine checkpoints are evaluated on the same custom '
    '[WikiText-2 raw test prefix](https://huggingface.co/datasets/Salesforce/wikitext), pinned at '
    '`b08601e04326c79dfdd32d625aee71d232d685c3`. The unchanged MiniMind tokenizer encodes stripped nonempty '
    'lines with EOS after each; the first 128,000 tokens are packed as above. '
    f"This evaluates {ood[0]['tokens']:,} predicted tokens. License tags on the source card are CC-BY-SA-3.0 and GFDL. "
    'The additional-domain plan was fixed before selection and inspecting development endpoint results. '
    'This is not the standard published WikiText perplexity protocol and is not comparable with numbers '
    'using another tokenizer, context or line handling. No WikiText training or tuning was performed.','',
    '| Seed | Candidate | Custom WikiText NLL | Custom WikiText perplexity |',
    '| --- | --- | ---: | ---: |']
for r in ood:lines.append(f"| {r['seed']} | {r['candidate']} | {r['nll']:.4f} | {r['perplexity']:.3f} |")
lines+=['','## Interpretation and limits','',
    f'Primary condition: lower TinyStories heldout NLL in every seed = {quality_all}; '
    f'higher throughput in every seed = {speed_all}. '
    f'Additional-domain lower NLL in every seed = {ood_all}. '
    'A local success supports only this compact-model, fixed-budget comparison on the measured hardware. '
    'It does not show that adding AttnRes to an otherwise identical model has zero cost. '
    'The same-depth ordinary control and development candidates reveal that distinction. '
    'A larger model study, more domains, downstream tasks, cached inference and repeated timing sessions '
    'remain. Three seeds are not proof of general superiority.','',
    'The custom WikiText perplexities are very high in absolute terms: all these story-trained models '
    'remain poor encyclopedic language models. A mixed additional-domain result prevents a claim of '
    'consistent superiority across domains. Phase-three and phase-two heldout sets differ, so their '
    'percentage improvements should not be compared as if measured on identical text.','',
    'Phase one’s original paths accumulated residuals at different precision. Phase two corrected that '
    'confound and found a quality gain with a speed cost. Phase three preserves the precision control, '
    'changes the implementation/block size, and explicitly tests smaller capacity. Earlier sources and '
    'measurements remain intact; the new result must not be substituted retrospectively into old runs.','',
    '## Correctness and artifacts','',
    'CPU/reference checks cover tuple/reference logits and gradients with nonzero queries, causality, '
    'matching-depth initial weights, and FP32 states under GPU autocast. All six candidates passed '
    'compiled/eager losses and scaled-gradient checks at batch 32/context 128. These correctness tests '
    'are distinct from model-quality results. Configuration, data/code hashes, histories, per-step timing '
    'and individual confirmation scores are retained. No GPU interrupted/resumed trajectory-equivalence '
    'test was performed for this runner.','',
    'Full resumable checkpoints were written every 250 updates in the original Colab runtime. '
    'That runtime expired after the experiments finished; its temporary optimizer checkpoints were lost. New completed '
    'model-only files, configs, results and logs are backed up with SHA-256 verification under '
    '`My Drive/mini-k3/2026-10-18/phase3`. These persistent model exports omit AdamW/scaler state and '
    'cannot resume the exact optimizer trajectory after runtime loss. They can reproduce evaluation '
    'with the pinned source. Local bundles contain code, measured evidence and reports; model and '
    'cached-token bytes remain in Drive/the runtime.','',
    '']
(OUT/'PHASE3_REPORT.md').write_text('\n'.join(lines),encoding='utf-8')
fig=plt.figure(figsize=(10,6.2))
grid=fig.add_gridspec(2,2)
axes=[fig.add_subplot(grid[0,:]),fig.add_subplot(grid[1,0]),fig.add_subplot(grid[1,1])]
palette={'baseline6':'#3659a5','baseline5':'#6d8583',winner:'#d46423'}
for name in names:
    points=sorted({r['step'] for r in histories if r['phase']=='confirmation' and r['candidate']==name})
    values=[[r['nll'] for r in histories if r['phase']=='confirmation' and r['candidate']==name and r['step']==s] for s in points]
    means=[stats.mean(v) for v in values]
    axes[0].plot([s*4096/1e6 for s in points],means,label=name,color=palette[name])
    axes[1].scatter([summary[name]['training_tokens_per_second']['mean']/1000],
        [summary[name]['heldout_perplexity']['mean']],label=name,color=palette[name],s=70)
    targets=[by_key[name,seed]['first_observed_target_crossing'] for seed in seeds]
    axes[2].scatter([name for t in targets if t],[t['wall_seconds'] for t in targets if t],color=palette[name],s=35)
axes[0].axhline(2.1,color='#777777',ls='--',lw=.8)
axes[0].set(xlabel='Training tokens (millions)',ylabel='Development NLL',title='Three-seed mean learning curves')
axes[0].legend(fontsize=7);axes[0].grid(alpha=.2)
axes[1].set(xlabel='Training throughput (thousand tokens/s)',ylabel='Heldout perplexity (lower is better)',title='Quality and raw throughput')
axes[1].legend(fontsize=7);axes[1].grid(alpha=.2)
axes[2].set(ylabel='First observed target wall time (s)',title='Fixed development NLL target <= 2.10')
axes[2].tick_params(axis='x',labelrotation=20);axes[2].grid(axis='y',alpha=.2)
fig.tight_layout();fig.savefig(OUT/'phase3_results.png',dpi=180);plt.close(fig)
print('PHASE3_ANALYSIS',json.dumps({'winner':winner,'criteria':criteria,'summary':summary,'paired':paired}),flush=True)
print('PHASE3_ANALYSIS_COMPLETE',OUT/'PHASE3_REPORT.md',flush=True)
