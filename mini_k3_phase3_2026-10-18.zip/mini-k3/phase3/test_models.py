"""Math, causality, shared initialization, FP32 states, and compiled gradients."""
import copy
import gc
import json
from pathlib import Path
import unittest
import torch
from models import CONFIGS,TupleLM,create_model,original_model
from controlled import ControlledLM
from optimized import TrainingLoss


class ModelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):torch.set_num_threads(2)

    def test_shared_initialization(self):
        for depth in (5,6):
            baseline=create_model(f'baseline{depth}').state_dict()
            attnres=create_model(f'attnres{depth}_b12').state_dict()
            for name,tensor in baseline.items():torch.testing.assert_close(tensor,attnres[name],rtol=0,atol=0)

    def test_tuple_matches_reference_and_is_causal(self):
        for name in ('attnres6_b4','attnres6_b12','attnres5_b4','attnres5_b12'):
            original=original_model(name,size='tiny')
            with torch.no_grad():
                for mixer in original.model.depth_mixers:
                    mixer.query.normal_(0,.1);mixer.key_norm.weight.uniform_(.8,1.2)
            a=ControlledLM(copy.deepcopy(original),'attnres')
            b=TupleLM(copy.deepcopy(original),'attnres_cached')
            x=torch.randint(0,6400,(2,12));y=x.clone();y[:,7:]=0
            torch.testing.assert_close(a(x),b(x),rtol=3e-4,atol=3e-6)
            torch.testing.assert_close(b(x)[:,:7],b(y)[:,:7],rtol=1e-5,atol=1e-5)
            TrainingLoss(a)(x,y).backward();TrainingLoss(b)(x,y).backward()
            for (pname,p),(_,q) in zip(a.named_parameters(),b.named_parameters()):
                gp=torch.zeros_like(p) if p.grad is None else p.grad
                gq=torch.zeros_like(q) if q.grad is None else q.grad
                torch.testing.assert_close(gp,gq,rtol=.003,atol=4e-6,msg=pname)

    @unittest.skipUnless(torch.cuda.is_available(),'CUDA runs in Colab')
    def test_fp32_residual_states(self):
        for name in CONFIGS:
            model=create_model(name).cuda();seen=[]
            hooks=[norm.register_forward_pre_hook(lambda m,args:seen.append(args[0].dtype))
                for layer in model.backbone.layers for norm in (layer.input_layernorm,layer.post_attention_layernorm)]
            with torch.autocast('cuda',dtype=torch.float16):model(torch.ones((2,128),dtype=torch.long,device='cuda'))
            self.assertTrue(seen and all(dtype==torch.float32 for dtype in seen))
            for hook in hooks:hook.remove()
            del model;gc.collect();torch.cuda.empty_cache()


def gpu_compilation_checks():
    rows=[]
    for name in CONFIGS:
        a=TrainingLoss(create_model(name).cuda());b=copy.deepcopy(a)
        compiled=torch.compile(b,fullgraph=True,dynamic=False,mode='default')
        generator=torch.Generator(device='cuda').manual_seed(19)
        x=torch.randint(0,6400,(32,128),generator=generator,device='cuda')
        y=torch.randint(0,6400,(32,128),generator=generator,device='cuda')
        with torch.autocast('cuda',dtype=torch.float16):la=a(x,y);lb=compiled(x,y)
        torch.testing.assert_close(la,lb,rtol=.001,atol=.001)
        (la*1024).backward();(lb*1024).backward()
        maximum=0.
        for (key,p),(_,q) in zip(a.named_parameters(),b.named_parameters()):
            gp=torch.zeros_like(p) if p.grad is None else p.grad/1024
            gq=torch.zeros_like(q) if q.grad is None else q.grad/1024
            maximum=max(maximum,(gp-gq).abs().max().item())
            torch.testing.assert_close(gp,gq,rtol=.04,atol=2e-4,msg=key)
        row={'candidate':name,'status':'passed','loss_absolute_error':abs(la.item()-lb.item()),
            'max_gradient_absolute_error':maximum,'loss_scale':1024,'gradient_rtol':.04,'gradient_atol':2e-4}
        rows.append(row);print('PHASE3_COMPILE_CHECK',json.dumps(row),flush=True)
        del a,b,compiled,la,lb;gc.collect();torch.cuda.empty_cache()
    path=Path(__file__).parent/'results/compilation_checks.json'
    path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(rows,indent=2))


if __name__=='__main__':
    outcome=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(ModelTests))
    if not outcome.wasSuccessful():raise SystemExit(1)
    if torch.cuda.is_available():gpu_compilation_checks()
