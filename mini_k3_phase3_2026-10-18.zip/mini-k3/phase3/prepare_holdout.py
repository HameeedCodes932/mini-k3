"""Reconstruct preceding caches before reserving subsequent complete stories."""
import hashlib
import json
from pathlib import Path
import numpy as np
from datasets import load_dataset
from transformers import AutoTokenizer
from experiment import DATASET,DATA_REVISION,digest,dump_json

ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'phase3/data'
OUT.mkdir(parents=True,exist_ok=True)
if (OUT/'holdout_manifest.json').exists():
    manifest=json.loads((OUT/'holdout_manifest.json').read_text())
    assert digest(OUT/'holdout.npy')==manifest['sha256']
    print('PHASE3_HOLDOUT_VERIFIED',json.dumps(manifest),flush=True)
    raise SystemExit(0)
tokenizer=AutoTokenizer.from_pretrained(str(ROOT/'vendor/model'),trust_remote_code=False)
seen=set()
def encode(row):
    text=row['text'].strip()
    if not text:return None
    key=hashlib.sha256(text.encode('utf-8')).digest()
    if key in seen:return None
    seen.add(key)
    return tokenizer.encode(text,add_special_tokens=False)+[tokenizer.eos_token_id]
train=[];train_count=0
for row in load_dataset(DATASET,revision=DATA_REVISION,split='train',streaming=True):
    tokens=encode(row)
    if tokens is None:continue
    train.extend(tokens);train_count+=1
    if len(train)>=2_000_000:break
assert np.array_equal(np.asarray(train[:2_000_000],dtype=np.int32),np.load(ROOT/'data/train.npy'))
print('PHASE3_TRAIN_PREFIX_VERIFIED',train_count,flush=True)
groups=[[],[],[]];counts=[0,0,0];caps=[100_000,128_000,128_000]
index=0
for row in load_dataset(DATASET,revision=DATA_REVISION,split='validation',streaming=True):
    tokens=encode(row)
    if tokens is None:continue
    groups[index].extend(tokens);counts[index]+=1
    if len(groups[index])>=caps[index]:
        index+=1
        if index==3:break
assert index==3
assert np.array_equal(np.asarray(groups[0][:100_000],dtype=np.int32),np.load(ROOT/'data/validation.npy'))
assert np.array_equal(np.asarray(groups[1][:128_000],dtype=np.int32),np.load(ROOT/'phase2/data/holdout.npy'))
np.save(OUT/'holdout.npy',np.asarray(groups[2][:128_000],dtype=np.int32))
manifest={'dataset':DATASET,'revision':DATA_REVISION,'tokens':128_000,
    'sha256':digest(OUT/'holdout.npy'),'train_stories':train_count,
    'original_validation_stories':counts[0],'phase2_holdout_stories':counts[1],'new_holdout_stories':counts[2],
    'selection':'Subsequent complete validation stories, exact-text disjoint from all previously selected complete train/validation/heldout stories',
    'previous_data_sha256':digest(ROOT/'data/data_manifest.json'),
    'phase2_manifest_sha256':digest(ROOT/'phase2/data/holdout_manifest.json'),
    'role':'Endpoint confirmation only; not an official test split or independent domain.'}
dump_json(OUT/'holdout_manifest.json',manifest)
print('PHASE3_HOLDOUT_READY',json.dumps(manifest),flush=True)
