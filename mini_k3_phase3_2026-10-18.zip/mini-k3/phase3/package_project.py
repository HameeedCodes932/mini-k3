"""Create the reviewed source/evidence bundle, excluding model and token bytes."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT.parent/'mini_k3_phase3_2026-10-18.zip'
with zipfile.ZipFile(OUT,'w',compression=zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(ROOT.rglob('*')):
        if not path.is_file():continue
        relative=path.relative_to(ROOT)
        if any(part in ('.venv','.git','__pycache__','tmp') for part in relative.parts):continue
        if path.suffix in ('.pt','.npy','.pyc') or path.name.endswith(('.tmp','.copying','_trace.json')):continue
        # The submission includes current evidence and sources. Original working
        # archives and superseded PDF drafts remain outside this submission.
        if relative.parts[0]=='artifacts' and path.name!='colab_phase3_confirmation.png':continue
        if path.suffix=='.pdf' and path.name!='Mini_K3_Phase3_Technical_Report_Fazal_Hameed.pdf':continue
        archive.write(path,Path('mini-k3')/relative)
with zipfile.ZipFile(OUT) as archive:
    assert archive.testzip() is None
    names=archive.namelist()
    pdf='mini-k3/output/pdf/Mini_K3_Phase3_Technical_Report_Fazal_Hameed.pdf'
    assert pdf in names
    assert 'mini-k3/phase3/mini_k3_phase3.ipynb' in names
    assert 'mini-k3/artifacts/colab_phase3_confirmation.png' in names
    assert not any(name.endswith(('.pt','.npy')) for name in names)
    certificate=json.loads(archive.read('mini-k3/phase3/delivery_verification.json'))
    record=next(r for r in certificate['files'] if r['relative_destination'].endswith('/Mini_K3_Phase3_Technical_Report_Fazal_Hameed.pdf'))
    assert hashlib.sha256(archive.read(pdf)).hexdigest()==record['sha256']
    assert len(json.loads(archive.read('mini-k3/phase3/persistent_model_verification.json')))==15
sha=hashlib.sha256(OUT.read_bytes()).hexdigest()
OUT.with_suffix('.zip.sha256').write_text(f'{sha}  {OUT.name}\n',encoding='ascii')
print(json.dumps({'archive':str(OUT),'bytes':OUT.stat().st_size,'files':len(names),'sha256':sha}))
