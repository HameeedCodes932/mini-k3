"""Update current status while preserving every earlier source and measurement."""
import hashlib
import json
from pathlib import Path
import statistics as stats

ROOT=Path(__file__).resolve().parent.parent
HERE=ROOT/'phase3'
bundle=json.loads((HERE/'analysis/phase3_results.json').read_text())
summary=bundle['summary'];winner=bundle['selection']['winner']
gain=stats.mean(r['heldout_perplexity_reduction_percent'] for r in bundle['paired'])
speed=stats.mean(r['throughput_change_percent'] for r in bundle['paired'])
target=stats.mean(r['target_wall_reduction_percent'] for r in bundle['paired'])
reduction=100*(1-summary[winner]['parameters']/summary['baseline6']['parameters'])
models=json.loads((HERE/'persistent_model_verification.json').read_text())
assert len(models)==15
text=f'''# mini-k3: compact-model comparison completed

On 18 October 2026, six development runs selected `{winner}` and nine locked
confirmation runs compared it with ordinary five- and six-layer MiniMind.
All models trained from scratch on a free Tesla T4, with matching token budgets,
FP32 residual states, FP16 linear operations, fused AdamW and the same compiler.

| Three-seed confirmation mean | Baseline6 | Compact AttnRes |
| --- | ---: | ---: |
| Parameters | {summary['baseline6']['parameters']:,} | {summary[winner]['parameters']:,} |
| New-story heldout perplexity | {summary['baseline6']['heldout_perplexity']['mean']:.3f} | {summary[winner]['heldout_perplexity']['mean']:.3f} |
| Training tokens/second | {summary['baseline6']['training_tokens_per_second']['mean']:,.0f} | {summary[winner]['training_tokens_per_second']['mean']:,.0f} |
| Time to fixed development quality, seconds | {summary['baseline6']['target_wall_seconds']['mean']:.2f} | {summary[winner]['target_wall_seconds']['mean']:.2f} |

Mean paired changes: **{gain:.2f}% lower heldout perplexity**, **{speed:.2f}% higher
training throughput**, and **{target:.2f}% less wall time to development NLL <= 2.10**.
The compact model has **{reduction:.2f}% fewer parameters**. The quality/throughput
criterion passed in every confirmation seed (17, 123, 777). Five alternating-order
timing repetitions also favored the winner. The same-depth five-layer ordinary
baseline is faster but has worse heldout quality, so adding AttnRes still has a
cost. Compactness and the depth-mixing technique work together in this result.

This achieves the internally defined faster-and-stronger goal **within this
small-model TinyStories comparison**. It is not a full 64M MiniMind study or a
general-assistant result. The custom WikiText test-prefix check improved in two
seeds and regressed in one; all models have very high perplexity on that domain.
Do not claim consistent superiority across domains or cached decoding speed.

## Read and reproduce

- Report: `output/pdf/Mini_K3_Phase3_Technical_Report_Fazal_Hameed.pdf`.
- Markdown report: `phase3/analysis/PHASE3_REPORT.md`.
- Clean self-contained Colab notebook: `phase3/mini_k3_phase3.ipynb`.
- Exact source, rules and selection: `phase3/models.py`, `runner.py`,
  `PROTOCOL.md`, `OOD_PROTOCOL.md`, `TIMING_PROTOCOL.md`, and `selection.json`.
- Measured evidence: `phase3/analysis/`, `phase3/runs/`,
  `phase3/repeated_timing.json` and `phase3/persistent_model_verification.json`.
- Live notebook: https://colab.research.google.com/drive/1NJODT4RLK_TMQTCbn_lbdLOye45TkFLz
- Drive: https://drive.google.com/drive/u/0/folders/1SGN7N1bAIFEN7EKVthnhx3bmepkPWkqC

## Verified preservation

The 15 new completed model files are backed up under
`My Drive/mini-k3/2026-10-18/phase3/runs/`. After Colab disconnected, all 15 files
were read back from Drive and verified against their SHA-256 certificates.
See `phase3/persistent_model_verification.json`. These exports contain weights,
configuration and results; they omit AdamW/scaler state. The original runtime
expired after training, so its temporary optimizer checkpoints are gone. The
completed model exports can reproduce evaluation, but cannot resume that exact
optimizer trajectory. Full source, sampled-batch recipe, data pins and scores
support training reproduction in a fresh run.

The previous 12 checkpoint backups and earlier reports are retained in Drive.
Local ZIP bundles contain code, logs, reports, charts and certificates; model
and cached-token bytes are not included. The original 200-step pilot had a
residual-precision confound. Phase two controlled precision and measured a
speed cost; phase three retains the control and explicitly changes model depth,
block size and implementation. Compare results within each phase because the
heldout partitions differ.

'''
(ROOT/'START_HERE.md').write_text(text,encoding='utf-8')
readme=ROOT/'README.md';old=readme.read_text(encoding='utf-8')
begin=old.index('The current experiment is in `phase2/`:') if 'The current experiment is in `phase2/`:' in old else -1
if begin>=0:
    end=old.index('\n## Start',begin)
    new=f'''The current experiment is in `phase3/`: a compact five-layer Block AttnRes
model, a six-candidate development screen, nine locked confirmation runs,
additional-domain evaluation and repeated timing validation. The selected model
had {gain:.2f}% lower heldout perplexity and {speed:.2f}% higher throughput than
the six-layer baseline, with {reduction:.2f}% fewer parameters. These are narrow
small-model results; WikiText performance was mixed across seeds. Read
`phase3/analysis/PHASE3_REPORT.md` and use `phase3/mini_k3_phase3.ipynb` to reproduce.
The sections below describe the preserved first pilot. Current backup status and
limitations are in `START_HERE.md`.
'''
    readme.write_text(old[:begin]+new+old[end:],encoding='utf-8')
manifest_path=ROOT/'source_manifest.json'
manifest=json.loads(manifest_path.read_text())
manifest.setdefault('measured_source_sha256',dict(manifest['source_sha256']))
manifest['source_sha256']={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in manifest['source_sha256']}
recorded_config=json.loads((HERE/'runs/confirmation/attnres5_b12_seed777/config.json').read_text())
manifest['phase3_measured_source_sha256']={name:recorded_config['source_hashes'][name] for name in ('models.py','runner.py','test_models.py','prepare_holdout.py','PROTOCOL.md')}
manifest['document_revisions']='phase3/document_revisions.json'
manifest.update(status='Phase-three compact model achieved the fixed local speed-and-quality criterion in all three confirmation seeds; 15 new model exports verified in Drive',
    phase3_measured_log_archive_sha256=hashlib.sha256((ROOT/'artifacts/phase3_measured_logs_2026-10-18.zip').read_bytes()).hexdigest(),
    phase3_source_sha256={name:hashlib.sha256((HERE/name).read_bytes()).hexdigest() for name in ('models.py','runner.py','test_models.py','prepare_holdout.py','PROTOCOL.md')},
    phase3_model_exports=15,phase3_optimizer_state_persisted=False)
manifest_path.write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print(json.dumps({'perplexity_reduction_percent':gain,'throughput_increase_percent':speed,'target_wall_reduction_percent':target,'parameter_reduction_percent':reduction,'verified_new_models':15}))
