"""Tuple-based Block AttnRes; all residual and block accumulation is FP32."""
import torch
from torch import nn
from experiment import make_config
from model.model_minimind import MiniMindForCausalLM
from attnres import BlockAttnResModel
from optimized import TrainingLM

CONFIGS={
    'baseline6':{'architecture':'baseline','layers':6,'block_sublayers':4},
    'baseline5':{'architecture':'baseline','layers':5,'block_sublayers':4},
    'attnres6_b4':{'architecture':'attnres','layers':6,'block_sublayers':4},
    'attnres6_b12':{'architecture':'attnres','layers':6,'block_sublayers':12},
    'attnres5_b4':{'architecture':'attnres','layers':5,'block_sublayers':4},
    'attnres5_b12':{'architecture':'attnres','layers':5,'block_sublayers':12},
}


class TupleLM(TrainingLM):
    @staticmethod
    def mix_tuple(mixer,sources,inverses):
        if len(sources)==1:return sources[0]
        query=mixer.query.float()*mixer.key_norm.weight.float()
        scores=[(value*query).sum(-1)*inverse.squeeze(-1) for value,inverse in zip(sources,inverses)]
        if len(sources)==2:
            # Exact two-way softmax identity, with FP32 roundoff differences.
            gate=(scores[1]-scores[0]).sigmoid().unsqueeze(-1)
            return sources[0]+gate*(sources[1]-sources[0])
        weights=torch.stack(scores,0).softmax(0)
        mixed=sources[0]*weights[0].unsqueeze(-1)
        for index in range(1,len(sources)):
            mixed=mixed+sources[index]*weights[index].unsqueeze(-1)
        return mixed

    def forward(self,x):
        if self.mode=='fp32':return super().forward(x)
        body=self.backbone
        embedding=body.dropout(body.embed_tokens(x)).float()
        positions=(body.freqs_cos[:x.shape[1]],body.freqs_sin[:x.shape[1]])
        completed=(embedding,)
        inverses=(self.inverse_rms(embedding,body.config.rms_norm_eps),)
        partial,index=None,0
        for layer in body.layers:
            for attention in (True,False):
                sources=completed if partial is None else completed+(partial,)
                rms=inverses if partial is None else inverses+(self.inverse_rms(partial,body.config.rms_norm_eps),)
                hidden=self.mix_tuple(body.depth_mixers[index],sources,rms)
                if attention:
                    delta,_=layer.self_attn(layer.input_layernorm(hidden),positions,use_cache=False)
                else:delta=layer.mlp(layer.post_attention_layernorm(hidden))
                delta=delta.float()
                partial=delta if partial is None else partial+delta
                index+=1
                if index%body.block_sublayers==0:
                    completed=completed+(partial,)
                    inverses=inverses+(self.inverse_rms(partial,body.config.rms_norm_eps),)
                    partial=None
        sources=completed if partial is None else completed+(partial,)
        rms=inverses if partial is None else inverses+(self.inverse_rms(partial,body.config.rms_norm_eps),)
        hidden=self.mix_tuple(body.depth_mixers[index],sources,rms)
        return self.lm_head(body.norm(hidden))


def original_model(name,seed=42,size='pilot'):
    spec=CONFIGS[name]
    config=make_config(size,128)
    config.num_hidden_layers=spec['layers'] if size=='pilot' else 2
    torch.manual_seed(seed)
    original=MiniMindForCausalLM(config)
    if spec['architecture']=='attnres':
        body=BlockAttnResModel(config,spec['block_sublayers'])
        missing,unexpected=body.load_state_dict(original.model.state_dict(),strict=False)
        assert not unexpected and all(k.startswith('depth_mixers.') for k in missing)
        original.model=body
        if config.tie_word_embeddings:original.model.embed_tokens.weight=original.lm_head.weight
    return original


def create_model(name,seed=42,size='pilot'):
    original=original_model(name,seed,size)
    return TupleLM(original,'fp32' if CONFIGS[name]['architecture']=='baseline' else 'attnres_cached')
