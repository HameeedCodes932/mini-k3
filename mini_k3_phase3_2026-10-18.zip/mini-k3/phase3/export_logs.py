"""Export measured evidence and exact source through visible notebook output."""
import base64
import hashlib
import io
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parent.parent
buffer=io.BytesIO()
with zipfile.ZipFile(buffer,'w',compression=zipfile.ZIP_DEFLATED) as archive:
    for path in sorted((ROOT/'phase3').rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts:continue
        if path.suffix in ('.json','.csv','.md','.py'):
            archive.write(path,path.relative_to(ROOT))
blob=buffer.getvalue();encoded=base64.b64encode(blob).decode('ascii')
chunks=[encoded[i:i+6000] for i in range(0,len(encoded),6000)]
print('P3LOG_SIZE:'+str(len(blob)))
print('P3LOG_SHA256:'+hashlib.sha256(blob).hexdigest())
print('P3LOG_CHUNK_COUNT:'+str(len(chunks)))
for index,chunk in enumerate(chunks):print(f'P3LOG_CHUNK_{index}:'+chunk)
