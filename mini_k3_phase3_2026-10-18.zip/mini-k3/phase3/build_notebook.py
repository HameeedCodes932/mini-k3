"""Package exact experiment sources in a fresh-runtime Colab notebook."""
import ast
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
base=json.loads((ROOT/'phase2/mini_k3_stage2.ipynb').read_text(encoding='utf-8'))
cells=[]
def md(source):cells.append({'cell_type':'markdown','metadata':{},'source':source.splitlines(keepends=True)})
def code(source):
    ast.parse(source)
    cells.append({'cell_type':'code','metadata':{},'source':source.splitlines(keepends=True),'outputs':[],'execution_count':None})
md('# mini-k3: compact-model speed and quality study\n\n'
   'This clean notebook reproduces the internally fixed development screen, locked confirmation, '
   'additional-domain check and repeated timing validation. It contains exact source and no invented execution outputs. '
   'Use a fresh Colab T4 runtime. Inspect `PROTOCOL.md`, `OOD_PROTOCOL.md` and `TIMING_PROTOCOL.md` before running. '
   'The experiment trains 15 small models; free GPU access and session lifetime are variable.\n')
result_path=HERE/'analysis/phase3_results.json'
if result_path.exists():
    measured=json.loads(result_path.read_text());winner=measured['selection']['winner'];s=measured['summary']
    md('## Recorded result from 18 October 2026\n\n'
       'The following is a summary of the saved measured evidence, separate from this notebook’s fresh execution.\n\n'
       '| Model | Parameters | Mean heldout perplexity | Mean training tokens/s |\n| --- | ---: | ---: | ---: |\n'+
       '\n'.join(f"| {name} | {s[name]['parameters']:,} | {s[name]['heldout_perplexity']['mean']:.3f} | {s[name]['training_tokens_per_second']['mean']:,.0f} |" for name in ('baseline6','baseline5',winner))+ '\n\n'
       'Read `analysis/PHASE3_REPORT.md` for all seeds, additional-domain failures and timing limitations.\n')
code(''.join(base['cells'][1]['source']))
code(''.join(base['cells'][2]['source']))
payload={}
for name in ('models.py','test_models.py','prepare_holdout.py','runner.py','ood_evaluation.py','repeat_timing.py',
             'analyze.py','export_logs.py','PROTOCOL.md','OOD_PROTOCOL.md','TIMING_PROTOCOL.md','document_revisions.json'):
    payload[name]=(HERE/name).read_bytes().decode('utf-8')
code(f'PHASE3_SOURCES={payload!r}\n'+'''(WORK/'phase3').mkdir(exist_ok=True)
for name,source in PHASE3_SOURCES.items():
    (WORK/'phase3'/name).write_bytes(source.encode('utf-8'))
os.environ['PYTHONPATH']=os.pathsep.join(str(p) for p in [WORK/'phase3',WORK/'phase2',WORK/'vendor',WORK])
''')
md('## Drive backup\n\nThis workflow uses Drive backup certificates in the final analysis. '
   'This grants notebook code access to Drive files. '
   'The original research notebook obtained Fazal’s approval for project backups. Review the prompt in a fresh notebook. '
   'Completed new model exports contain weights/config, while exact optimizer-resume state stays in the temporary runtime.\n')
code("from google.colab import drive\ndrive.mount('/content/drive',timeout_ms=180000)\nDRIVE_BACKUP=Path('/content/drive/MyDrive/mini-k3/2026-10-18')\nos.environ['MINIK3_DRIVE_BACKUP']=str(DRIVE_BACKUP)\n")
md('## Data and checks\n\nRestore token bytes as well as manifests when resuming. '
   'For changed code/settings/environment, choose a fresh output directory rather than resuming an old run.\n')
code("run([sys.executable,str(WORK/'experiment.py'),'prepare','--upstream',str(WORK/'vendor'),'--data',str(WORK/'data')])\nrun([sys.executable,str(WORK/'phase2/prepare_holdout.py')])\nrun([sys.executable,str(WORK/'phase3/prepare_holdout.py')])\nrun([sys.executable,str(WORK/'test_experiment.py')])\nrun([sys.executable,str(WORK/'phase3/test_models.py')])\n")
md('## Screen, lock, confirm\n\nThe winner is selected using seed-42 development results only. '
   'Confirmation seeds are 17, 123 and 777; no new heldout or WikiText scores enter selection.\n')
code("run([sys.executable,str(WORK/'phase3/runner.py'),'screen'])\nrun([sys.executable,str(WORK/'phase3/runner.py'),'confirmation'])\n")
code("run([sys.executable,str(WORK/'phase3/ood_evaluation.py')])\nrun([sys.executable,str(WORK/'phase3/repeat_timing.py')])\nrun([sys.executable,str(WORK/'phase3/analyze.py')])\n")
code("from IPython.display import display,Markdown,Image\ndisplay(Markdown((WORK/'phase3/analysis/PHASE3_REPORT.md').read_text()))\ndisplay(Image(filename=str(WORK/'phase3/analysis/phase3_results.png')))\nif os.environ.get('MINIK3_DRIVE_BACKUP'):\n    import sys\n    sys.path.insert(0,str(WORK/'phase2'))\n    from backup import backup_tree\n    backup_tree(WORK/'phase3',Path(os.environ['MINIK3_DRIVE_BACKUP'])/'phase3',include_checkpoints=False)\n")
notebook={'cells':cells,'metadata':{'colab':{'name':'mini_k3_phase3.ipynb'},'accelerator':'GPU','kernelspec':{'display_name':'Python 3','name':'python3','language':'python'},'language_info':{'name':'python'}},'nbformat':4,'nbformat_minor':5}
(HERE/'mini_k3_phase3.ipynb').write_text(json.dumps(notebook,indent=1,ensure_ascii=False),encoding='utf-8')
print('Created',HERE/'mini_k3_phase3.ipynb',len(cells),'cells')
