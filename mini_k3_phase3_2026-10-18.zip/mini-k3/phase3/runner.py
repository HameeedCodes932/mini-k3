"""Fixed-budget development screen and locked three-seed confirmation."""
import argparse
import gc
import json
import math
import os
from pathlib import Path
import statistics
import time
import torch
from experiment import digest,dump_json,environment,token_blocks
from optimized import TrainingLoss
from benchmark_stage2 import logical_batch
from backup import backup_tree,verified_copy
from models import CONFIGS,create_model

ROOT=Path(__file__).resolve().parent.parent
HERE=ROOT/'phase3'
TARGET=2.10
torch.set_num_threads(4)
torch.backends.cuda.matmul.allow_tf32=False
torch.backends.cudnn.allow_tf32=False
assert torch.cuda.is_available()
checks=json.loads((HERE/'results/compilation_checks.json').read_text())
assert {r['candidate'] for r in checks if r['status']=='passed'}==set(CONFIGS),'All compiled model checks must pass'
data=token_blocks(ROOT/'data/train.npy',128)
validation=token_blocks(ROOT/'data/validation.npy',128)[:256]
source_hashes={name:digest(HERE/name) for name in ['models.py','runner.py','test_models.py','prepare_holdout.py','PROTOCOL.md',
    '../phase2/optimized.py','../phase2/benchmark_stage2.py','../phase2/controlled.py','../attnres.py','../experiment.py']}
DRIVE=Path(os.environ['MINIK3_DRIVE_BACKUP']) if os.environ.get('MINIK3_DRIVE_BACKUP') else None


@torch.no_grad()
def evaluate(model,blocks):
    model.eval();total,tokens=0.,0
    loss_fn=TrainingLoss(model)
    for lo in range(0,len(blocks),32):
        pack=blocks[lo:lo+32].cuda()
        with torch.autocast('cuda',dtype=torch.float16):loss=loss_fn(pack[:,:-1],pack[:,1:])
        count=pack.shape[0]*128
        total+=loss.item()*count;tokens+=count
    model.train()
    return {'nll':total/tokens,'perplexity':math.exp(total/tokens),'tokens':tokens}


def train(name,seed,phase):
    wall_start=time.perf_counter();previous_wall=0.
    folder=HERE/'runs'/phase/f'{name}_seed{seed}'
    folder.mkdir(parents=True,exist_ok=True)
    spec={'candidate':name,**CONFIGS[name],'phase':phase,'seed':seed,'steps':1000,'sequence':128,
        'physical_batch':32,'logical_batch':32,'lr':3e-4,'warmup_steps':50,'min_lr_fraction':.1,
        'optimizer':'AdamW fused','betas':[.9,.95],'weight_decay':.1,'gradient_clip':1.,
        'initial_loss_scale':1024,'residual_dtype':'float32','linear_autocast':'float16',
        'engine':'inductor fullgraph default dynamicFalse','target_development_nll':TARGET,'evaluate_every':50,
        'source_hashes':source_hashes,'data_manifest_sha256':digest(ROOT/'data/data_manifest.json'),
        'compilation_checks_sha256':digest(HERE/'results/compilation_checks.json'),
        'holdout_manifest_sha256':digest(HERE/'data/holdout_manifest.json'),
        'selection_sha256':digest(HERE/'selection.json') if phase=='confirmation' else None,
        'environment':environment('cuda')}
    spec=json.loads(json.dumps(spec))
    if (folder/'config.json').exists():
        assert json.loads((folder/'config.json').read_text())==spec,'Changed source/configuration: use a new output directory'
    dump_json(folder/'config.json',spec)
    if (folder/'result.json').exists():
        print('PHASE3_ALREADY_COMPLETE',name,seed,phase,flush=True)
        return json.loads((folder/'result.json').read_text())
    model=create_model(name,seed).cuda().train()
    objective=TrainingLoss(model)
    optimizer=torch.optim.AdamW(model.parameters(),lr=3e-4,betas=(.9,.95),weight_decay=.1,fused=True)
    scaler=torch.amp.GradScaler('cuda',init_scale=1024)
    history,timings,start=[],[],0
    checkpoint=folder/'latest.pt'
    if checkpoint.exists():
        saved=torch.load(checkpoint,map_location='cpu',weights_only=True)
        assert saved['spec']==spec
        model.load_state_dict(saved['model']);optimizer.load_state_dict(saved['optimizer']);scaler.load_state_dict(saved['scaler'])
        history=saved['history'];timings=saved['timings'];start=saved['step'];previous_wall=saved['elapsed_wall']
        torch.set_rng_state(saved['cpu_rng']);torch.cuda.set_rng_state_all(saved['cuda_rng'])
        print('PHASE3_RESUME',name,seed,start,flush=True)
    else:
        metrics=evaluate(model,validation)
        history.append({'step':0,**metrics,'training_seconds':0.,'wall_seconds':time.perf_counter()-wall_start})
    objective=torch.compile(objective,fullgraph=True,dynamic=False,mode='default')
    torch.cuda.reset_peak_memory_stats()
    cumulative_training=sum(r['seconds'] for r in timings)
    def save(step):
        state={'spec':spec,'model':model.state_dict(),'optimizer':optimizer.state_dict(),'scaler':scaler.state_dict(),
            'step':step,'history':history,'timings':timings,'elapsed_wall':previous_wall+time.perf_counter()-wall_start,
            'cpu_rng':torch.get_rng_state(),'cuda_rng':torch.cuda.get_rng_state_all()}
        temporary=checkpoint.with_suffix('.pt.tmp')
        torch.save(state,temporary);os.replace(temporary,checkpoint)
        dump_json(folder/'history.json',history);dump_json(folder/'timing.json',timings)
    for step in range(start,1000):
        lr=3e-4*min(1.,(step+1)/50)*(.1+.9*(1+math.cos(math.pi*max(0,step-50)/950))/2)
        for group in optimizer.param_groups:group['lr']=lr
        optimizer.zero_grad(set_to_none=True)
        torch.cuda.synchronize();began=time.perf_counter()
        x,y=logical_batch(data,seed,step)
        with torch.autocast('cuda',dtype=torch.float16):loss=objective(x,y)
        scaler.scale(loss).backward();scaler.unscale_(optimizer)
        torch.nn.utils.clip_grad_norm_(model.parameters(),1.,error_if_nonfinite=True)
        if not torch.isfinite(loss):raise FloatingPointError('Nonfinite loss; paired run stopped')
        scaler.step(optimizer);scaler.update()
        torch.cuda.synchronize();elapsed=time.perf_counter()-began
        cumulative_training+=elapsed
        timings.append({'step':step+1,'seconds':elapsed,'tokens':4096})
        if (step+1)%100==0 or step==start:
            print('PHASE3_TRAIN',phase,name,seed,step+1,'nll',round(loss.item(),4),'tokens/s',round(4096/elapsed),flush=True)
        if (step+1)%50==0:
            metrics=evaluate(model,validation)
            row={'step':step+1,**metrics,'training_seconds':cumulative_training,
                'wall_seconds':previous_wall+time.perf_counter()-wall_start}
            history.append(row)
            if (step+1)%100==0:print('PHASE3_VALIDATION',phase,name,seed,json.dumps(row),flush=True)
        if (step+1)%250==0:save(step+1)
    heldout=None
    if phase=='confirmation':heldout=evaluate(model,token_blocks(HERE/'data/holdout.npy',128))
    crossing=next((r for r in history if r['nll']<=TARGET),None)
    steady=[r for r in timings if r['step']>8]
    result={'candidate':name,'phase':phase,'seed':seed,'steps':1000,'training_tokens':4_096_000,
        'parameters':sum(p.numel() for p in model.parameters()),'development':history[-1],'heldout':heldout,
        'target_nll':TARGET,'first_observed_target_crossing':crossing,
        'median_training_tokens_per_second':statistics.median(4096/r['seconds'] for r in steady),
        'first_step_seconds_including_compilation':timings[0]['seconds'],'training_step_seconds':cumulative_training,
        'active_run_wall_seconds_including_setup_compile_eval_checkpoint_io':previous_wall+time.perf_counter()-wall_start,
        'peak_allocated_gpu_bytes_this_session':torch.cuda.max_memory_allocated(),'resume_step_this_session':start,
        'persistent_checkpoint_contents':'model weights and config; optimizer/scaler only in temporary runtime latest.pt',
        'environment':spec['environment']}
    dump_json(folder/'result.json',result)
    # Completed model-only export conserves Drive storage and cannot resume AdamW exactly.
    weights=folder/'model_weights.pt'
    torch.save({'model':model.state_dict(),'spec':spec,'result':result},weights)
    if DRIVE:
        records=backup_tree(folder,DRIVE/folder.relative_to(ROOT),include_checkpoints=False)
        records.append(verified_copy(weights,DRIVE/weights.relative_to(ROOT)))
        dump_json(folder/'backup_verification.json',records)
        verified_copy(folder/'backup_verification.json',DRIVE/folder.relative_to(ROOT)/'backup_verification.json')
        print('PHASE3_MODEL_BACKUP_VERIFIED',name,seed,weights.stat().st_size,flush=True)
    print('PHASE3_RESULT',json.dumps(result),flush=True)
    del model,objective,optimizer,scaler
    gc.collect();torch.cuda.empty_cache()
    return result


def screen():
    results=[]
    for name in CONFIGS:
        results.append(train(name,42,'screen'))
        dump_json(HERE/'screen_results.json',results)
    baseline=next(r for r in results if r['candidate']=='baseline6')
    candidates=[r for r in results if r['candidate'].startswith('attnres')]
    eligible=[r for r in candidates if r['development']['nll']<=baseline['development']['nll']-.005]
    winner=max(eligible,key=lambda r:r['median_training_tokens_per_second']) if eligible else min(candidates,key=lambda r:r['development']['nll'])
    selection={'winner':winner['candidate'],'configuration':CONFIGS[winner['candidate']],
        'quality_selection_condition_passed':bool(eligible),'development_seed':42,'confirmation_seeds':[17,123,777],
        'target_development_nll':TARGET,'rule':'Among AttnRes models at least .005 development NLL below baseline6, choose highest throughput; otherwise lowest NLL and flag failure',
        'screen_results_sha256':digest(HERE/'screen_results.json'),'protocol_sha256':digest(HERE/'PROTOCOL.md')}
    if (HERE/'selection.json').exists():assert json.loads((HERE/'selection.json').read_text())==selection
    dump_json(HERE/'selection.json',selection)
    if DRIVE:backup_tree(HERE,DRIVE/'phase3',include_checkpoints=False)
    print('PHASE3_SELECTION_LOCKED',json.dumps(selection),flush=True)


def confirmation():
    selection=json.loads((HERE/'selection.json').read_text())
    assert digest(HERE/'PROTOCOL.md')==selection['protocol_sha256']
    assert digest(HERE/'screen_results.json')==selection['screen_results_sha256']
    names=['baseline6','baseline5',selection['winner']]
    results=[]
    for index,seed in enumerate(selection['confirmation_seeds']):
        order=names[index:]+names[:index]
        for name in order:
            results.append(train(name,seed,'confirmation'))
            dump_json(HERE/'confirmation_results.json',results)
    if DRIVE:backup_tree(HERE,DRIVE/'phase3',include_checkpoints=False)
    print('PHASE3_CONFIRMATION_COMPLETE',flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('phase',choices=['screen','confirmation'])
    args=parser.parse_args()
    screen() if args.phase=='screen' else confirmation()
