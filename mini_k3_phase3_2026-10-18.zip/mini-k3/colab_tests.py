# Random-input correctness checks, not model quality results.
def run(command):
    with subprocess.Popen(command, cwd=WORK, stdout=subprocess.PIPE,
                          stderr=subprocess.STDOUT, text=True, bufsize=1) as process:
        for line in process.stdout:
            print(line, end='', flush=True)
        status = process.wait()
    if status:
        raise RuntimeError(f'Experiment command failed with status {status}')

run([sys.executable, str(WORK / 'test_experiment.py')])
