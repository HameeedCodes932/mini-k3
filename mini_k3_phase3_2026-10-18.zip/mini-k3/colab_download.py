# Download after every session. /content disappears when the runtime expires.
# No Google Drive mount is needed. Keep the archive on your laptop.
import shutil
from google.colab import files
archive = shutil.make_archive('/content/mini_k3_session', 'zip', WORK)
files.download(archive)
