"""Correctness checks with random inputs; these are not model quality results."""
import argparse
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
import torch
from attnres import DepthMixer
from experiment import build_model, next_token_loss, run_variant, training_batch
import experiment


class ExperimentTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(2)

    def test_zero_query_means_uniform_depth_weights(self):
        mixer = DepthMixer(8)
        sources = [torch.randn(2, 5, 8) for _ in range(3)]
        torch.testing.assert_close(mixer(sources), torch.stack(sources).mean(0))

    def test_shared_initial_weights_identical(self):
        a = build_model('tiny', 16, 'baseline', 42)
        b = build_model('tiny', 16, 'attnres', 42)
        for key, value in a.state_dict().items():
            torch.testing.assert_close(value, b.state_dict()[key], rtol=0, atol=0)

    def test_causal_outputs_and_gradients(self):
        for block_size in (1, 3, 8):
            model = build_model('tiny', 16, 'attnres', 42, block_size).eval()
            x = torch.randint(10, 6400, (2, 12))
            changed = x.clone()
            changed[:, 7:] = torch.randint(10, 6400, changed[:, 7:].shape)
            with torch.no_grad():
                a, b = model(x).logits, model(changed).logits
            torch.testing.assert_close(a[:, :7], b[:, :7], rtol=1e-5, atol=1e-5)
            loss = next_token_loss(model, x[:, :-1], x[:, 1:])
            self.assertTrue(torch.isfinite(loss))
            loss.backward()
            for name, parameter in model.named_parameters():
                self.assertIsNotNone(parameter.grad, name)
                self.assertTrue(torch.isfinite(parameter.grad).all(), name)
            queries = [p.grad for n, p in model.named_parameters() if n.endswith('query')]
            self.assertTrue(any(g.abs().sum() > 0 for g in queries))

    def test_batches_independent_of_model_rng(self):
        data = torch.arange(20 * 9).reshape(20, 9)
        a = training_batch(data, 42, 9, 2, 3, 'cpu')
        torch.randn(1000)
        b = training_batch(data, 42, 9, 2, 3, 'cpu')
        for x, y in zip(a, b):
            torch.testing.assert_close(x, y, rtol=0, atol=0)

    def test_resuming_completed_run_preserves_result(self):
        # Exercise saving/loading model, optimizer, scaler and RNG state end to end.
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            rng = np.random.default_rng(1)
            for split in ('train', 'validation'):
                np.save(root / f'{split}.npy', rng.integers(0, 6400, 1000, dtype=np.int32))
            (root / 'data_manifest.json').write_text(json.dumps({'synthetic_test': True}))
            args = argparse.Namespace(data=str(root), output=str(root / 'runs'),
                size='tiny', seq=8, batch=2, accum=1, steps=3, lr=1e-4,
                eval_every=3, eval_blocks=4, block_sublayers=3, save_every=1)
            for variant in ('baseline', 'attnres'):
                first = run_variant(args, variant, 42)
                second = run_variant(args, variant, 42)
                self.assertEqual(first['validation_nll'], second['validation_nll'])
                self.assertEqual(first['training_tokens'], 48)
                self.assertEqual(second['resume_step_this_session'], 3)

    def test_interrupted_training_matches_uninterrupted_cpu(self):
        class SimulatedDisconnect(Exception):
            pass
        with tempfile.TemporaryDirectory() as tmp, patch('torch.cuda.is_available', return_value=False):
            root = Path(tmp)
            rng = np.random.default_rng(2)
            for split in ('train', 'validation'):
                np.save(root / f'{split}.npy', rng.integers(0, 6400, 1000, dtype=np.int32))
            (root / 'data_manifest.json').write_text(json.dumps({'synthetic_test': True}))
            for variant in ('baseline', 'attnres'):
                args = argparse.Namespace(data=str(root), output=str(root / 'reference'),
                    size='tiny', seq=8, batch=2, accum=1, steps=3, lr=1e-4,
                    eval_every=3, eval_blocks=4, block_sublayers=3, save_every=1)
                reference = run_variant(args, variant, 42)
                original_dump = experiment.dump_json
                def interrupt_after_checkpoint(path, value):
                    original_dump(path, value)
                    if Path(path).name == 'history.json':
                        raise SimulatedDisconnect()
                args.output = str(root / 'interrupted')
                with patch('experiment.dump_json', side_effect=interrupt_after_checkpoint):
                    with self.assertRaises(SimulatedDisconnect):
                        run_variant(args, variant, 42)
                resumed = run_variant(args, variant, 42)
                self.assertEqual(resumed['resume_step_this_session'], 1)
                self.assertAlmostEqual(reference['validation_nll'], resumed['validation_nll'], places=6)
                a = torch.load(root / 'reference' / f'{variant}_seed42/latest.pt', weights_only=True)
                b = torch.load(root / 'interrupted' / f'{variant}_seed42/latest.pt', weights_only=True)
                for key, value in a['model'].items():
                    torch.testing.assert_close(value, b['model'][key], rtol=0, atol=1e-7)


if __name__ == '__main__':
    unittest.main(verbosity=2)
