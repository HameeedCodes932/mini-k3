# mini-k3: a first experiment on free Colab

This project starts Fazal Hameed's research task with a small MiniMind baseline and
a Block Attention Residuals adaptation from Kimi K3. It is a pilot, not a complete
K3 reproduction or evidence of an improved general-purpose LLM. No gains are
assumed. Inspect and understand the implementation before presenting the work.

The current experiment is in `phase3/`: a compact five-layer Block AttnRes
model, a six-candidate development screen, nine locked confirmation runs,
additional-domain evaluation and repeated timing validation. The selected model
had 3.93% lower heldout perplexity and 12.56% higher throughput than
the six-layer baseline, with 13.51% fewer parameters. These are narrow
small-model results; WikiText performance was mixed across seeds. Read
`phase3/analysis/PHASE3_REPORT.md` and use `phase3/mini_k3_phase3.ipynb` to reproduce.
The sections below describe the preserved first pilot. Current backup status and
limitations are in `START_HERE.md`.

## Start

Open `mini_k3_free_colab_pilot.ipynb` in Google Colab. Select **Runtime > Change
runtime type > T4 GPU**, then run the cells in order. Free GPU access varies.
Setup downloads the pinned MiniMind source and installs only experiment packages.
The first experiment uses a reduced dense MiniMind configuration: hidden size
384, six transformer layers, six query/two KV heads, and 128-token inputs.
The 64M upstream configuration is available as `--size standard` for later runs.

Both variants train from scratch for 200 optimizer updates, 8 sequences per
microbatch, four accumulation steps: **819,200 predicted tokens per variant**.
The same tokenizer, sampled batches, shared initial weights, learning rate,
validation data, FP16 autocast setting and paired seed are used. A later audit
found different residual-accumulation precision: upstream in-place attention
residuals round to FP16, while the original depth mixer promotes to FP32.
The first-pilot quality gain therefore includes this confound. Phase two makes
all residual and block accumulation explicitly FP32 in both models. After the seed-42 pair, the
notebook repeats seeds 17 and 123 in reversed model order and produces an aggregate
report. AttnRes adds a small number of
parameters and uses blocks of four sublayers (two transformer layers).

The data is a pinned prefix of the official TinyStories train split (two million
tokens) and a separate validation prefix (100,000 tokens). Exact duplicate texts
are removed within and across the selected splits. Validation uses the same
first 256 packed blocks, or 32,768 predicted tokens, at each evaluation. This is
an inexpensive English language-modeling pilot, not MiniMind's original broad
training recipe, a full-data benchmark or a test of general reasoning ability.

## Results and interruptions

The trainer records held-out negative log-likelihood and perplexity, synchronized
training-step throughput, parameter counts, environment, data/code hashes and
session peak allocated GPU memory. Throughput excludes evaluation/checkpoint IO
and the first two optimizer steps. GPU memory is a session measurement; a resumed
run must not claim it is the maximum over all previous sessions.

Checkpoints include optimizer, scaler, RNG states, step, history and timing and
are written every 25 steps. Rerunning the same command resumes the same run.
Changing configuration, code, data or hardware requires a new output directory.
An out-of-memory error must be resolved for **both** variants with a fresh paired
run, keeping batch × accumulation fixed where practical.

**Colab `/content` is temporary.** The user authorized a Drive connection on
18 October 2026. Experiment backups are verified by SHA-256 under
`My Drive/mini-k3/2026-10-18`. The initial six model checkpoints, pinned source,
tokenizer and cached tokens were successfully backed up. Phase-two checkpoints
are copied at updates 500 and 1,000 and after each completed run. Model bytes
have not been downloaded to the laptop through the in-app browser; local bundles
contain source, logs and reports. Preserve dataset license notices if
redistributing cached tokens. To resume on a new runtime, restore the matching
experiment files under `/content/mini_k3_work`; the source, settings, environment
and data hashes must match the saved run. No external tracker is used.

## Interpretation and next stages

A single short run only checks feasibility and early learning. Compare final
validation loss at the same token budget; report a speed regression as a
regression. This ordinary PyTorch AttnRes implementation may be slower than the
baseline. It has no optimized depth-attention kernel and no KV cache; the pilot
does not measure cached decoding throughput. Do not describe it as faster or
stronger unless measured results support the specific claim.

After the pilot: inspect learning curves and memory, extend paired training in
a new run with three or more seeds, then consider a second K3 technique or inference
optimization. A report should include unsuccessful runs, budget and limitations.

## Sources and attribution

- MiniMind: https://github.com/jingyaogong/minimind
  pinned commit `f659b55761b754d306bd140573493a6543cafd7f`; Apache-2.0;
  upstream license preserved in `vendor/LICENSE`.
- Kimi K3 report, section 2.2, equations 8–10:
  https://arxiv.org/html/2607.24653v2#S2.SS2
  This project implements its described depth mixing in a smaller dense model.
- TinyStories: https://huggingface.co/datasets/roneneldan/TinyStories
  pinned revision `f54c09fd23315a6f9c86f9dc80f725de7d8f9c64`,
  dataset license CDLA-Sharing-1.0. Original paper: https://arxiv.org/abs/2305.07759
- Colab limits: https://research.google.com/colaboratory/faq.html

Correctness tests use random inputs and do not establish model quality.
Actual experimental results are kept separately from tests.
