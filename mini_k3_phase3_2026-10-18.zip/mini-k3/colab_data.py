# Streams a small pinned subset; no Hugging Face login/token is required.
run([sys.executable, str(WORK / 'experiment.py'), 'prepare',
    '--upstream', str(WORK / 'vendor'), '--data', str(WORK / 'data')])
